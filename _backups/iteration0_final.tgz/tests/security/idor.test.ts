/**
 * SECURITY LENS — Attack class 5: IDOR (cross-member access).
 *
 * The session carries a launch/patient context (getSessionPatient). These tests
 * authenticate a session scoped to MARIA_SD_001 and then request a DIFFERENT
 * member's data (PAT-0042 / PAT-0103). SAFE behavior is that the read is scoped
 * to (or checked against) the session patient.
 *
 * FINDINGS (HIGH, documented via it.fails — the safe assertion currently fails):
 *  - /api/fhir/[...path] resolves the target patient purely from the request
 *    query param; the session patient is never consulted → any authenticated
 *    caller reads any member's Patient/Coverage/Condition PHI.
 *  - /api/evidence/[id] derives the member from the id; no check that it matches
 *    the session patient.
 *  - /api/financial-clearance trusts body.patientId over the session patient.
 *  Fix rec: compare the resolved target member to getSessionPatient() (member
 *  self-access) or gate provider cross-member reads through canReadMemberData
 *  with the caller's real role + treatment-relationship, and 403 on mismatch.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { vi } from 'vitest';
import {
  makeRequest,
  routeParams,
  readJson,
  sessionState,
  resetSessionState,
  resetRouteEnv,
} from '../api/_helpers';

vi.mock('@/lib/server/smartSession', async () => (await import('../api/_helpers')).smartSessionMock());

import { GET as fhirGET } from '@/app/api/fhir/[...path]/route';
import { GET as evidenceGET } from '@/app/api/evidence/[id]/route';
import { POST as clearancePOST } from '@/app/api/financial-clearance/route';

const SESSION_MEMBER = 'MARIA_SD_001';
const OTHER_MEMBER = 'PAT-0042';

beforeEach(() => {
  resetSessionState();
  resetRouteEnv();
  sessionState.authenticated = true;
  sessionState.patient = SESSION_MEMBER; // caller is scoped to Maria
  vi.clearAllMocks();
});

describe('IDOR — a session scoped to member A must not read member B', () => {
  it.fails('SAFE would be: fhir Patient read for another member is denied/empty', async () => {
    const res = await fhirGET(
      makeRequest(`/api/fhir/Patient?subject=Patient/${OTHER_MEMBER}`),
      routeParams({ path: ['Patient'] })
    );
    const body = (await readJson(res)) as { id?: string; resourceType?: string };
    // Currently returns PAT-0042's Patient resource → cross-member disclosure.
    expect(body.id, 'must not return another member id').not.toBe(OTHER_MEMBER);
  });

  it.fails('SAFE would be: evidence read for another member is 403/404', async () => {
    const id = `ev-${OTHER_MEMBER}-75561-1715782920000`;
    const res = await evidenceGET(makeRequest(`/api/evidence/${id}`), routeParams({ id }));
    const body = (await readJson(res)) as { memberId?: string };
    expect(body.memberId, 'must not return another member record').not.toBe(OTHER_MEMBER);
  });

  it.fails('SAFE would be: financial-clearance ignores a body patientId outside session scope', async () => {
    const res = await clearancePOST(
      makeRequest('/api/financial-clearance', { method: 'POST', body: { patientId: OTHER_MEMBER } })
    );
    // A scoped session should get 403 (or its own data), never PAT-0042's clearance.
    expect(res.status, 'cross-member clearance should be forbidden').toBe(403);
  });
});
