/**
 * SECURITY LENS — Attack class 5: IDOR (cross-member access).
 *
 * The session carries a launch/patient context (getSessionPatient). These tests
 * authenticate a session scoped to MARIA_SD_001 and then request a DIFFERENT
 * member's data (PAT-0042 / PAT-0103). SAFE behavior is that the read is scoped
 * to (or checked against) the session patient.
 *
 * STATUS (Iteration 1 wave C):
 *  - FIXED: /api/fhir/[...path] Patient identity read is now scoped to the
 *    session principal — a session scoped to member A that requests member B's
 *    Patient demographics gets a PHI-safe 403 (break-glass excepted, audited).
 *    Asserted below.
 *  - DOCUMENTED (not fixed — needs the session-principal role model, cycle-3
 *    MEDIUM #3): /api/evidence/[id] and /api/financial-clearance are pa-reviewer
 *    ops surfaces whose existing contract asserts LEGITIMATE cross-member reads
 *    (a reviewer works a queue of many members). A behavior-safe session-scope
 *    403 cannot be added without distinguishing a member-scoped session from a
 *    reviewer session, which requires deriving the caller's real role from the
 *    session (not the hardcoded `pa-reviewer`). financial-clearance already wires
 *    targetPatientId into canReadMemberData; only the hardcoded role blocks the
 *    deny. These two remain it.fails — live executable records of the open hole.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { vi } from 'vitest';
import {
  makeRequest,
  routeParams,
  readJson,
  sessionState,
  resetSessionState,
  resetRouteEnv,
} from '../api/_helpers';

vi.mock('@/lib/server/smartSession', async () => (await import('../api/_helpers')).smartSessionMock());

import { GET as fhirGET } from '@/app/api/fhir/[...path]/route';
import { GET as evidenceGET } from '@/app/api/evidence/[id]/route';
import { POST as clearancePOST } from '@/app/api/financial-clearance/route';

const SESSION_MEMBER = 'MARIA_SD_001';
const OTHER_MEMBER = 'PAT-0042';

beforeEach(() => {
  resetSessionState();
  resetRouteEnv();
  sessionState.authenticated = true;
  sessionState.patient = SESSION_MEMBER; // caller is scoped to Maria
  vi.clearAllMocks();
});

describe('IDOR — a session scoped to member A must not read member B', () => {
  it('FIXED: fhir Patient read for another member is 403, not the other member', async () => {
    const res = await fhirGET(
      makeRequest(`/api/fhir/Patient?subject=Patient/${OTHER_MEMBER}`),
      routeParams({ path: ['Patient'] })
    );
    expect(res.status, 'cross-member Patient read must be forbidden').toBe(403);
    const body = (await readJson(res)) as { id?: string; resourceType?: string };
    expect(body.id, 'must not return another member id').not.toBe(OTHER_MEMBER);
    expect(body.resourceType).toBe('OperationOutcome');
  });

  it.fails('SAFE would be: evidence read for another member is 403/404', async () => {
    const id = `ev-${OTHER_MEMBER}-75561-1715782920000`;
    const res = await evidenceGET(makeRequest(`/api/evidence/${id}`), routeParams({ id }));
    const body = (await readJson(res)) as { memberId?: string };
    expect(body.memberId, 'must not return another member record').not.toBe(OTHER_MEMBER);
  });

  it.fails('SAFE would be: financial-clearance ignores a body patientId outside session scope', async () => {
    const res = await clearancePOST(
      makeRequest('/api/financial-clearance', { method: 'POST', body: { patientId: OTHER_MEMBER } })
    );
    // A scoped session should get 403 (or its own data), never PAT-0042's clearance.
    expect(res.status, 'cross-member clearance should be forbidden').toBe(403);
  });
});
