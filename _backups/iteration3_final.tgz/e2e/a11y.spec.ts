/**
 * a11y — axe-core accessibility pass over the key demo routes.
 *
 * Hard gate:  ZERO critical or serious violations on every key route.
 * Baseline:   moderate / minor violations are printed (never fail) so O-9 has a
 *             starting inventory to burn down without blocking the demo.
 *
 * Routes covered (the demo-critical surfaces):
 *   /                          — demo entry / navigator
 *   /whole-person-care-summary — whole-person knowledge-graph summary
 *   /whole-person-intelligence — whole-person intelligence
 *   /care-manager              — care manager cockpit
 *   /signal-disposition-engine — signal disposition engine
 *   /network-adequacy          — network adequacy analyst view
 *   /financial-clearance       — Golden Thread financial clearance
 *   /prior-auth                — prior authorization handoff
 *   /cms                       — CMS-0057-F provision hub
 *
 * Prerequisites (CI): dev stack on port 4029 with ALLOW_DEV_MOCK_AUTH=true
 * (see playwright.config.ts).
 */
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const KEY_ROUTES: Array<{ name: string; path: string }> = [
  { name: 'demo entry / navigator', path: '/' },
  { name: 'whole-person care summary', path: '/whole-person-care-summary' },
  { name: 'whole-person intelligence', path: '/whole-person-intelligence' },
  { name: 'care manager cockpit', path: '/care-manager' },
  { name: 'signal disposition engine', path: '/signal-disposition-engine' },
  { name: 'network adequacy', path: '/network-adequacy' },
  { name: 'financial clearance (Golden Thread)', path: '/financial-clearance' },
  { name: 'prior authorization', path: '/prior-auth' },
  { name: 'CMS-0057-F hub', path: '/cms' },
];

const BLOCKING = new Set(['critical', 'serious']);

for (const route of KEY_ROUTES) {
  test(`a11y: ${route.name} has no critical/serious violations`, async ({ page }, testInfo) => {
    await page.goto(route.path, { waitUntil: 'domcontentloaded' });

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();

    const blocking = results.violations.filter((v) => BLOCKING.has(v.impact ?? ''));
    const baseline = results.violations.filter((v) => !BLOCKING.has(v.impact ?? ''));

    // Print the moderate/minor baseline for O-9 (does not fail the run).
    if (baseline.length > 0) {
      const lines = baseline.map(
        (v) => `  [${v.impact}] ${v.id} (${v.nodes.length}x) — ${v.help}`,
      );
      const report = `a11y baseline (moderate/minor) for ${route.path}:\n${lines.join('\n')}`;
      // eslint-disable-next-line no-console
      console.log(report);
      testInfo.annotations.push({ type: 'a11y-baseline', description: report });
    }

    // Hard gate: no critical / serious violations.
    const detail = blocking
      .map((v) => `[${v.impact}] ${v.id} (${v.nodes.length}x) — ${v.help}`)
      .join('\n');
    expect(blocking, `critical/serious a11y violations on ${route.path}:\n${detail}`).toEqual([]);
  });
}
