/**
 * C5 — "demo stays green" walkthrough.
 *
 * Drives the core demo path end to end and asserts that each key screen renders
 * its signature content with no uncaught page errors / console errors. Selectors
 * are role- and text-based (never brittle CSS) so screen restyling does not break
 * the smoke.
 *
 * The core demo path (per the Cycle plan):
 *   1. /                          — demo entry / navigator
 *   2. /whole-person-care-summary — whole-person knowledge-graph summary
 *   3. /care-manager              — care manager cockpit
 *   4. /signal-disposition-engine — signal disposition engine
 *   5. /network-adequacy          — network adequacy analyst view
 *   6. /financial-clearance       — Golden Thread financial clearance
 *   7. /prior-auth                — prior authorization handoff
 *
 * Prerequisites (CI): dev stack on port 4029 with ALLOW_DEV_MOCK_AUTH=true and
 * the data-mode registry at its `mock` default (see playwright.config.ts).
 */
import { test, expect, type Page, type ConsoleMessage } from '@playwright/test';

/**
 * Console/page-error noise that is not a real defect for a demo smoke: static
 * asset 404s, the well-known ResizeObserver loop notice, and hydration hints.
 * Anything else counts as a console error and fails the screen.
 */
const BENIGN = [
  /favicon/i,
  /ResizeObserver loop/i,
  /Download the React DevTools/i,
  /\/_next\/.*\.(png|jpg|svg|woff2?)/i,
  /net::ERR_/i, // transient asset fetch failures in a headless run
];

function isBenign(text: string): boolean {
  return BENIGN.some((re) => re.test(text));
}

/** Navigate to a path and return a live-updating list of real errors seen. */
async function gotoTracked(page: Page, path: string): Promise<string[]> {
  const errors: string[] = [];
  page.on('console', (msg: ConsoleMessage) => {
    if (msg.type() === 'error' && !isBenign(msg.text())) errors.push(`console: ${msg.text()}`);
  });
  page.on('pageerror', (err) => {
    if (!isBenign(err.message)) errors.push(`pageerror: ${err.message}`);
  });
  await page.goto(path, { waitUntil: 'domcontentloaded' });
  return errors;
}

test.describe('C5 demo walkthrough — every key screen renders clean', () => {
  test('demo entry / navigator', async ({ page }) => {
    const errors = await gotoTracked(page, '/');
    await expect(page.getByText(/Demo Navigator/i).first()).toBeVisible();
    await expect(page.getByText(/Select a demo screen below to begin/i)).toBeVisible();
    expect(errors, errors.join('\n')).toEqual([]);
  });

  test('whole-person care summary', async ({ page }) => {
    const errors = await gotoTracked(page, '/whole-person-care-summary');
    await expect(page.getByText(/Maria Redhawk/i).first()).toBeVisible();
    await expect(page.getByText(/Knowledge Graph Context/i).first()).toBeVisible();
    expect(errors, errors.join('\n')).toEqual([]);
  });

  test('care manager cockpit', async ({ page }) => {
    const errors = await gotoTracked(page, '/care-manager');
    await expect(page.getByText(/Care Plan Status/i).first()).toBeVisible();
    await expect(page.getByText(/Cost by Setting/i).first()).toBeVisible();
    expect(errors, errors.join('\n')).toEqual([]);
  });

  test('signal disposition engine', async ({ page }) => {
    const errors = await gotoTracked(page, '/signal-disposition-engine');
    await expect(page.getByRole('heading', { name: /signal disposition engine/i })).toBeVisible();
    expect(errors, errors.join('\n')).toEqual([]);
  });

  test('network adequacy', async ({ page }) => {
    const errors = await gotoTracked(page, '/network-adequacy');
    await expect(page.getByRole('heading', { name: /network adequacy/i })).toBeVisible();
    expect(errors, errors.join('\n')).toEqual([]);
  });

  test('golden thread — financial clearance', async ({ page }) => {
    const errors = await gotoTracked(page, '/financial-clearance');
    await expect(page.getByRole('heading', { name: /Financial Clearance/i })).toBeVisible();
    // interactive runner still works — the demo's live moment
    await page.getByRole('button', { name: /run clearance/i }).click();
    await expect(page.getByText(/PA required|No PA required|Cleared/i).first()).toBeVisible();
    expect(errors, errors.join('\n')).toEqual([]);
  });

  test('prior authorization handoff', async ({ page }) => {
    const errors = await gotoTracked(page, '/prior-auth');
    await expect(page.getByRole('heading', { name: /Prior Authorization/i })).toBeVisible();
    expect(errors, errors.join('\n')).toEqual([]);
  });
});
