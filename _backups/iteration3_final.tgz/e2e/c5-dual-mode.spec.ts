/**
 * C5 — dual-mode assertion.
 *
 * The plan mandates that the key *seamed* screens (those that resolve data
 * through the Cycle 1 dataMode registry) render correctly in BOTH the mock and
 * the non-mock (Live FHIR) states of the runtime data-mode toggle.
 *
 * How dual-mode is driven here
 * ----------------------------
 * The runtime toggle is a UI control in AppLayout: a button that reads
 * "Mock Data" while `useMockData` is true and "Live FHIR" once flipped. Clicking
 * it calls AppContext.setUseMockData, which useFhirModeSync() propagates into the
 * fhirClient singleton via setFhirMockMode() — i.e. it writes a per-seam SESSION
 * override into the dataMode registry (setSessionDataMode), the top resolution
 * layer above env/config (src/lib/config/dataMode.ts). So a single in-page click
 * flips the seam from mock to production without a reload or a second process.
 *
 * Each screen is checked twice in one page session:
 *   - default load  -> toggle reads "Mock Data", signature content renders
 *   - after a click -> toggle reads "Live FHIR", signature content still renders,
 *     no uncaught page error (the seam must degrade gracefully, never crash).
 *
 * Env-driven alternative (documented for CI, not used by this spec): the same
 * seams can be forced without touching the UI by running the suite twice with
 * DATA_MODE / DATA_MODE_FHIR_STORE (or legacy NEXT_PUBLIC_USE_MOCK_DATA) set —
 * e.g. `DATA_MODE=mock playwright test` then `DATA_MODE=production playwright test`.
 */
import { test, expect, type Page } from '@playwright/test';

const MOCK_TOGGLE = /Mock Data/i;
const LIVE_TOGGLE = /Live FHIR/i;

/** Seamed screens and a resilient signature locator for each. */
const SEAMED_SCREENS: Array<{ name: string; path: string; signature: RegExp }> = [
  { name: 'whole-person care summary', path: '/whole-person-care-summary', signature: /Knowledge Graph Context/i },
  { name: 'whole-person intelligence', path: '/whole-person-intelligence', signature: /Clinical Intelligence/i },
  { name: 'care manager cockpit', path: '/care-manager', signature: /Care Plan Status/i },
  { name: 'patient episode summary', path: '/patient-episode-summary', signature: /Episode Summary/i },
];

/** Attach a page-error collector; returns the accumulating list (crashes only). */
function trackCrashes(page: Page): string[] {
  const crashes: string[] = [];
  page.on('pageerror', (err) => crashes.push(err.message));
  return crashes;
}

for (const screen of SEAMED_SCREENS) {
  test(`${screen.name} renders in mock AND live-FHIR mode`, async ({ page }) => {
    const crashes = trackCrashes(page);
    await page.goto(screen.path, { waitUntil: 'domcontentloaded' });

    // ── Mock mode (registry default) ──
    const mockToggle = page.getByRole('button', { name: MOCK_TOGGLE });
    await expect(mockToggle).toBeVisible();
    await expect(page.getByText(screen.signature).first()).toBeVisible();

    // ── Flip the seam to production via the UI toggle ──
    await mockToggle.click();
    const liveToggle = page.getByRole('button', { name: LIVE_TOGGLE });
    await expect(liveToggle).toBeVisible();

    // Signature content must still render — the seam degrades, never crashes.
    await expect(page.getByText(screen.signature).first()).toBeVisible();
    expect(crashes, `page crashed in live-FHIR mode:\n${crashes.join('\n')}`).toEqual([]);
  });
}
