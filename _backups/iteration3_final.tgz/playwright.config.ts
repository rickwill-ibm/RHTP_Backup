import { defineConfig, devices } from '@playwright/test';

/**
 * Playwright configuration for the Total-Cost-of-Care demo e2e + a11y suite.
 *
 * No config existed prior to Cycle 3; this one was added so the specs under
 * e2e/ are CI-runnable. It is intentionally minimal and mirrors the operating
 * assumptions baked into the original golden-thread.spec.ts:
 *
 *   - the Next.js dev stack serves on port 4029 (see package.json `dev`)
 *   - dev-mock auth is enabled (ALLOW_DEV_MOCK_AUTH=true) so the reviewer /
 *     analyst / member surfaces are reachable without a live WSO2 IdP
 *   - the data-mode registry defaults every seam to `mock` (demo stays green)
 *
 * testDir is pinned to ./e2e so `playwright test --list` never picks up the
 * unit/integration suites under tests/ (which are vitest/newman, not Playwright).
 *
 * CI: set E2E_BASE_URL to point at an already-running deployment, or let the
 * webServer block boot the dev server. Live execution requires a running
 * server; parsing/listing (`--list`) does not.
 */
const BASE_URL = process.env.E2E_BASE_URL ?? 'http://localhost:4029';

export default defineConfig({
  testDir: './e2e',
  testMatch: '**/*.spec.ts',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: process.env.CI ? [['github'], ['list']] : 'list',
  timeout: 30_000,
  expect: { timeout: 10_000 },
  use: {
    baseURL: BASE_URL,
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
  // Boot the dev stack for CI unless E2E_BASE_URL already points at one.
  // Skipped automatically by --list (webServer only starts on an actual run).
  webServer: process.env.E2E_BASE_URL
    ? undefined
    : {
        command: 'npm run dev',
        url: BASE_URL,
        timeout: 120_000,
        reuseExistingServer: !process.env.CI,
        env: { ALLOW_DEV_MOCK_AUTH: 'true', NEXT_PUBLIC_USE_MOCK_DATA: 'true' },
      },
});
