/**
 * Evidence store seam (O-1, ADR-005) — public surface + mode selector.
 *
 * `getEvidenceStore()` resolves the 'evidence' data mode from the registry:
 *   mock / seeded -> the existing in-memory store (demo stays green by default);
 *   production    -> the Postgres append-only ledger, via a registered factory.
 *
 * Callers are NOT changed by this iteration: they still use
 * `defaultEvidenceStore()`. This selector is the flip point — pointing a caller
 * at `getEvidenceStore()` is the one-line production swap. In mock mode it
 * returns the very same default instance, so behavior is byte-identical.
 *
 * The production factory is registered (not hardcoded) so wiring a real pool
 * stays a composition-root concern and pg-mem tests can register their own. Until
 * one is registered, production mode throws EvidenceStoreNotConfiguredError — the
 * BackboneNotConfigured pattern (fail loud, never a silent missing backend).
 */
import { getDataMode } from '@/lib/config/dataMode';
import { defaultEvidenceStore, type EvidenceStore } from '../evidenceStore';

export class EvidenceStoreNotConfiguredError extends Error {
  constructor() {
    super(
      'DATA_MODE evidence=production: no production evidence ledger is wired yet. ' +
        'Register one with setProductionEvidenceStoreFactory(() => createPgEvidenceLedger(pool)) ' +
        '(SEAM: evidence-store) or set DATA_MODE_EVIDENCE=mock.'
    );
    this.name = 'EvidenceStoreNotConfiguredError';
  }
}

let productionFactory: (() => EvidenceStore) | null = null;

/** Register the production ledger factory (composition root / tests). */
export function setProductionEvidenceStoreFactory(factory: (() => EvidenceStore) | null): void {
  productionFactory = factory;
}

/** Resolve the evidence store for the configured 'evidence' data mode. SEAM: evidence-store. */
export function getEvidenceStore(): EvidenceStore {
  const mode = getDataMode('evidence');
  if (mode === 'production') {
    if (!productionFactory) throw new EvidenceStoreNotConfiguredError();
    return productionFactory();
  }
  // 'mock' and 'seeded' both serve the in-memory default (no seed file yet).
  return defaultEvidenceStore();
}

export { applyMigrations, migrationFiles, readMigration } from './schema';
export { createPgEvidenceLedger, type PgEvidenceLedger } from './pgEvidenceLedger';
export type {
  PgLike,
  PgQueryResult,
  LedgerEntry,
  LedgerProvenance,
  PgEvidenceLedgerOptions,
} from './types';
