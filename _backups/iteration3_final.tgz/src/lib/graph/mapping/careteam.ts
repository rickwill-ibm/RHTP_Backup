// CONTRACT: C9  // CONTRACT: C10  // DP-1
/**
 * Care-team mapping spec: care-team assignment events -> the member's care-team
 * subgraph. This is the store-agnostic projection that backs the care-team lens.
 *
 *   (Member)-[:HAS_CARE_TEAM {valid from occurredAt}]->(CareTeamMember)
 *
 * The edge is ASSOCIATIVE (a factual assignment link, not an asserted causal claim)
 * and DATED from the assignment time, so an asOf query can ask "who was on the care
 * team on date X". Care-team members (providers, care managers, community workers)
 * are NPI/identity-anchored (DP-7 O-6) but never carry Part 2 restriction of their
 * own; restriction is still read from the envelope so the rule stays uniform.
 *
 * An `careteam.unassigned` event CLOSES the edge's validity (the member left the
 * team) without deleting the historical link, preserving the dated interval.
 */
import type { C2Event } from '@/lib/outbox';
import type { Mutation, ProjectorDeps } from '../types';
import { MEMBER_KIND, associative, memberNode, resourceNode } from './spec';

const CARE_TEAM_KIND = 'CareTeamMember';

function str(v: unknown, fallback = ''): string {
  return typeof v === 'string' ? v : fallback;
}

export const careteamSpec = {
  domain: 'careteam',
  matches(eventType: string): boolean {
    return eventType.startsWith('careteam.');
  },
  toMutations(event: C2Event, deps: ProjectorDeps): Mutation[] {
    const p = event.payload;
    const providerRef = str(p.providerRef, `Practitioner/${event.memberId}`);
    const start = event.occurredAt || new Date(deps.now()).toISOString();
    const unassigned = event.eventType === 'careteam.unassigned';
    const out: Mutation[] = [memberNode(event)];
    out.push(
      ...resourceNode(event, CARE_TEAM_KIND, providerRef, {
        role: str(p.role, 'care-manager'),
        name: str(p.name),
        npi: str(p.npi),
        organization: str(p.organization),
      }),
    );
    out.push({
      op: 'UpsertEdge',
      type: 'HAS_CARE_TEAM',
      from: { kind: MEMBER_KIND, key: event.memberId },
      to: { kind: CARE_TEAM_KIND, key: providerRef },
      properties: { role: str(p.role, 'care-manager') },
      validity: { start, end: unassigned ? start : null },
      semantics: associative,
    });
    return out;
  },
};
