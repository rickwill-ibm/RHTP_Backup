// CONTRACT: C9  // CONTRACT: C2  // CONTRACT: C10  // SEAM: cdc-relay
/**
 * Pipeline reference architecture (plan §4A) — public surface. Five stages, three
 * representative source adapters (batch / stream / flat-file), lane-agnostic
 * transforms, staging + quarantine, reconciliation gates, and segmentation-at-
 * transform. Stage 5 propagation rides the outbox library (src/lib/outbox).
 */
export type {
  PipelineStage,
  ArrivalMode,
  SourceFormat,
  WpcDomain,
  Tier,
  SourceDescriptor,
  PipelineDeps,
  IdentityResolver,
  LandedBatch,
  RawRecord,
  ValidationIssue,
  ValidationResult,
  ConsentLabel,
  NormalizedRecord,
  QuarantineRecord,
  TransformOutcome,
  ReconciliationReport,
  DomainAdapter,
  StageContract,
} from './types';

export {
  defaultPipelineDeps,
  defaultIdentityResolver,
  landStage,
  stageValidate,
  transformEnrich,
  hash,
  PIPELINE_STAGE_NAMES,
  type LandInput,
  type StageValidateOutput,
} from './stages';

export {
  runTransform,
  batchStep,
  streamConsumer,
  packageBothLanes,
  reconcile,
  assertBalanced,
  buildQuarantineRecord,
  ReconciliationError,
  type BatchStepResult,
} from './transform';

export {
  applySegmentation,
  labelsFromHints,
  readHints,
  SEGMENTATION_RULES,
  type SegmentationRule,
} from './segmentation';

export {
  conformAndLoad,
  projectAndPropagate,
  toIntentInput,
  defaultProfileValidator,
  CONFORM_LOAD_CONTRACT,
  PROJECT_PROPAGATE_CONTRACT,
  type FhirProfileValidator,
  type LoadDeps,
  type ConformLoadResult,
} from './load';

export { runPipeline, type PipelineRunResult } from './pipeline';

export { eligibility834Adapter } from './adapters/eligibility834';
export { adtEncounterAdapter } from './adapters/adtEncounter';
export { cboSdohAdapter } from './adapters/cboSdoh';
