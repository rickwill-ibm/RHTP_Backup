// CONTRACT: C9  // CONTRACT: C10
/**
 * Lane-agnostic transform core + the packaging seam (plan §4A "lane-agnostic
 * transforms", binding). There is exactly ONE transform implementation per
 * domain (the adapter's validate+normalize), run through ONE runTransform. It is
 * packaged TWICE — as a batch DAG step and as a stream consumer — from that one
 * implementation. Divergence between batch and stream logic is a defect class,
 * banned by construction: both lanes call runTransform. The anti-divergence unit
 * test asserts batch and stream produce identical output for identical input.
 */
import { applySegmentation } from './segmentation';
import type {
  DomainAdapter,
  LandedBatch,
  NormalizedRecord,
  PipelineDeps,
  QuarantineRecord,
  RawRecord,
  ReconciliationReport,
  SourceDescriptor,
  TransformOutcome,
} from './types';

function stableHash(input: string): string {
  let h = 5381;
  for (let i = 0; i < input.length; i++) h = ((h << 5) + h + input.charCodeAt(i)) >>> 0;
  return h.toString(16).padStart(8, '0');
}

/** Build a PHI-safe quarantine record: reason codes + field paths only. */
export function buildQuarantineRecord<Raw>(
  raw: RawRecord<Raw>,
  issues: { reasonCode: string; fieldPath: string }[],
  batchId: string,
  source: SourceDescriptor,
  deps: PipelineDeps,
): QuarantineRecord {
  return {
    quarantineId: `q-${stableHash(`${batchId}:${raw.sourceRef}`)}`,
    batchId,
    source,
    sourceRef: raw.sourceRef,
    reasonCodes: issues.map((i) => i.reasonCode),
    fieldPaths: issues.map((i) => i.fieldPath),
    quarantinedAt: new Date(deps.now()).toISOString(),
    status: 'quarantined',
  };
}

/**
 * The transform core: validate -> (quarantine | normalize -> segment). Pure over
 * (adapter, raw, deps). `landed` supplies batch context for quarantine records;
 * when absent (single-record transform stage) the adapter's own source is used.
 */
export function runTransform<Raw>(
  adapter: DomainAdapter<Raw>,
  raw: RawRecord<Raw>,
  deps: PipelineDeps,
  landed?: LandedBatch,
): TransformOutcome {
  const batchId = landed?.batchId ?? adapter.source.batchId ?? `adhoc-${adapter.source.feed}`;
  const source = landed?.source ?? adapter.source;
  const validation = adapter.validate(raw);
  if (!validation.ok) {
    return { ok: false, quarantine: buildQuarantineRecord(raw, validation.issues, batchId, source, deps) };
  }
  const normalized = adapter.normalize(raw, deps);
  return { ok: true, record: applySegmentation(normalized) };
}

export interface BatchStepResult {
  normalized: NormalizedRecord[];
  quarantined: QuarantineRecord[];
  reconciliation: ReconciliationReport;
}

/** Batch lane packaging: a DAG step over a whole landed batch, with a recon gate. */
export function batchStep<Raw>(adapter: DomainAdapter<Raw>) {
  return (landed: LandedBatch, deps: PipelineDeps): BatchStepResult => {
    const raws = adapter.parse(landed.payload);
    const normalized: NormalizedRecord[] = [];
    const quarantined: QuarantineRecord[] = [];
    for (const raw of raws) {
      const outcome = runTransform(adapter, raw, deps, landed);
      if (outcome.ok) normalized.push(outcome.record);
      else quarantined.push(outcome.quarantine);
    }
    return {
      normalized,
      quarantined,
      reconciliation: reconcile(landed.batchId, raws.length, normalized.length, quarantined.length),
    };
  };
}

/** Stream lane packaging: a consumer over one message (one record) of a payload. */
export function streamConsumer<Raw>(adapter: DomainAdapter<Raw>) {
  return (landed: LandedBatch, deps: PipelineDeps): TransformOutcome => {
    const raws = adapter.parse(landed.payload);
    if (raws.length !== 1) {
      throw new Error(
        `stream consumer for feed "${adapter.source.feed}" expects one record per message, got ${raws.length}`,
      );
    }
    return runTransform(adapter, raws[0], deps, landed);
  };
}

/** The explicit packaging seam: one transform, both lanes, side by side. */
export function packageBothLanes<Raw>(adapter: DomainAdapter<Raw>) {
  return { batch: batchStep(adapter), stream: streamConsumer(adapter) };
}

/** Reconciliation gate: counts in = loaded + rejected, per batch (§4A stage 4). */
export function reconcile(
  batchId: string,
  countIn: number,
  loaded: number,
  rejected: number,
): ReconciliationReport {
  return { batchId, countIn, loaded, rejected, balanced: countIn === loaded + rejected };
}

/** Alarmed gate assertion: throws on an unbalanced batch (never load silently). */
export function assertBalanced(report: ReconciliationReport): void {
  if (!report.balanced) {
    throw new ReconciliationError(report);
  }
}

export class ReconciliationError extends Error {
  constructor(public readonly report: ReconciliationReport) {
    super(
      `reconciliation gate failed for batch ${report.batchId}: ` +
        `in=${report.countIn} != loaded=${report.loaded} + rejected=${report.rejected}`,
    );
    this.name = 'ReconciliationError';
  }
}
