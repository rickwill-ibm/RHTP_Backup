// CONTRACT: C9  // CONTRACT: C2  // CONTRACT: C10
/**
 * Pipeline reference-architecture types (plan §4A, binding).
 *
 * Five stages, every feed, both lanes: land -> stage+validate -> transform+enrich
 * -> conform+load -> project+propagate. Stages 2-5 are PURE functions over
 * (input, deps); deps carries the clock/rng seam (src/lib/clock.ts) plus the
 * identity-resolution seam, so nothing reads a global. Adapters are generic over
 * records — no persona is ever hardcoded (plan §1.2 representative-use-case rule).
 */

export type PipelineStage =
  | 'land'
  | 'stage-validate'
  | 'transform-enrich'
  | 'conform-load'
  | 'project-propagate';

/** The three arrival modes §4A names; the transform is identical across them. */
export type ArrivalMode = 'batch' | 'stream' | 'micro-batch';

/** Inbound wire formats (subset built here: X12 834, HL7v2 ADT, flat-file CSV). */
export type SourceFormat = 'x12-834' | 'hl7v2-adt' | 'flat-file-csv';

/** C9 domains this wave delivers. Extend as adapters are added. */
export type WpcDomain = 'coverage' | 'encounter' | 'sdoh';

export type Tier = 'T1' | 'T2' | 'T3';

export interface SourceDescriptor {
  system: string;
  feed: string;
  batchId?: string;
}

/** Injected everywhere. Defaults bind to clock.ts; tests pass fakes. */
export interface PipelineDeps {
  now: () => number;
  rng: () => number;
  /** Attach a raw source id to the anchored member identity (stage 3, never raw). */
  resolveIdentity: IdentityResolver;
}

export type IdentityResolver = (
  sourceMemberId: string,
  traits?: Record<string, unknown>,
) => string;

/** Stage 1 output: immutable, cataloged landing of one payload. Nothing transformed. */
export interface LandedBatch {
  batchId: string;
  source: SourceDescriptor;
  format: SourceFormat;
  receivedAt: string;
  checksum: string;
  /** The raw payload text, retained verbatim for replay (DR source of truth). */
  payload: string;
}

/** A single parsed raw record with a PHI-safe stable reference (no payload values). */
export interface RawRecord<Raw = Record<string, unknown>> {
  /** Stable, PHI-free handle: row index, HL7 control id, 834 member-source id. */
  sourceRef: string;
  data: Raw;
}

export interface ValidationIssue {
  reasonCode: string; // structured + PHI-safe, e.g. 'missing-field', 'bad-segment'
  fieldPath: string;
}

export interface ValidationResult {
  ok: boolean;
  issues: ValidationIssue[];
}

/** Consent + 42 CFR Part 2 labels, applied at TRANSFORM time (§4A stage 3). */
export interface ConsentLabel {
  part2Restricted: boolean;
  segmentLabels: string[];
}

/** Stage 3 output: the canonical, identity-anchored, labeled record. PHI-minimal. */
export interface NormalizedRecord {
  domain: WpcDomain;
  /** Anchored member identity (post match-engine); never a raw source id. */
  memberId: string;
  resourceType: string;
  /** Deterministic FHIR id the stage-4 idempotent PUT targets. */
  fhirResourceId: string;
  eventType: string;
  tier: Tier;
  idempotencyKey: string;
  provenance: string;
  consent: ConsentLabel;
  source: SourceDescriptor;
  occurredAt: string;
  /** Codes + references only; never free-text clinical narrative. */
  payload: Record<string, unknown>;
}

/** PHI-safe rejection record for the quarantine lane (§4A stage 2). */
export interface QuarantineRecord {
  quarantineId: string;
  batchId: string;
  source: SourceDescriptor;
  sourceRef: string;
  reasonCodes: string[];
  fieldPaths: string[];
  quarantinedAt: string;
  status: 'quarantined' | 'remediated' | 'discarded';
}

export type TransformOutcome =
  | { ok: true; record: NormalizedRecord }
  | { ok: false; quarantine: QuarantineRecord };

/** Reconciliation gate output (§4A stage 4): counts in = loaded + rejected. */
export interface ReconciliationReport {
  batchId: string;
  countIn: number;
  loaded: number;
  rejected: number;
  balanced: boolean;
}

/**
 * ONE transform per domain, packaged twice (batch step + stream consumer). An
 * adapter is the whole per-source contract: parse (land->stage), validate
 * (stage 2), normalize (stage 3 core). Segmentation is layered by the shared
 * transform runner, not the adapter, so every source gets it uniformly.
 */
export interface DomainAdapter<Raw = Record<string, unknown>> {
  readonly source: SourceDescriptor;
  readonly domain: WpcDomain;
  readonly format: SourceFormat;
  readonly arrivalMode: ArrivalMode;
  parse(payload: string): RawRecord<Raw>[];
  validate(raw: RawRecord<Raw>): ValidationResult;
  normalize(raw: RawRecord<Raw>, deps: PipelineDeps): NormalizedRecord;
}

/** A stage as a declared contract: named IO plus an idempotency key per §4A. */
export interface StageContract<I, O> {
  readonly stage: PipelineStage;
  readonly declaredInput: string;
  readonly declaredOutput: string;
  idempotencyKeyOf(input: I): string;
  run(input: I, deps: PipelineDeps): O;
}
