/**
 * Minimal ambient types for `node-postgres` (`pg`).
 *
 * `pg` is a runtime dependency but ships no bundled types, and `@types/pg` is
 * not installed in this sandbox. Only the evidence-ledger integration spec
 * imports `pg` directly (real Postgres via testcontainers); the ledger itself
 * depends on the driver-agnostic `PgLike` interface, never on `pg`. This shim
 * covers exactly the surface that spec uses. Replace with `@types/pg` in CI if
 * broader coverage is wanted.
 */
declare module 'pg' {
  export interface QueryResult<Row = Record<string, unknown>> {
    rows: Row[];
    rowCount: number | null;
  }
  export interface PoolConfig {
    connectionString?: string;
  }
  export class Pool {
    constructor(config?: PoolConfig);
    query<Row = Record<string, unknown>>(
      text: string,
      values?: readonly unknown[]
    ): Promise<QueryResult<Row>>;
    end(): Promise<void>;
  }
}
