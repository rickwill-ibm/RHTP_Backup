// CONTRACT: C9  // CONTRACT: C10
/**
 * 834 eligibility BATCH adapter (arrival mode: batch). Proves the X12 batch path.
 * Parses a small realistic 834-ish payload (segment-per-line, `*`-delimited
 * elements) into normalized Coverage records at tier T1. Generic over records:
 * no member is hardcoded; identity is resolved through the injected seam so the
 * Coverage attaches to the anchored member, never the raw subscriber id.
 *
 * C9.2 yield: 834 -> coverage T1 (+ demographics T1, out of this adapter's scope).
 */
import type { DomainAdapter, NormalizedRecord, PipelineDeps, RawRecord, ValidationResult } from '../types';

interface X12Member {
  segments: string[][]; // parsed INS-loop segments
}

const SOURCE = { system: 'state-medicaid', feed: 'x12-834' } as const;

/** Split an 834 payload into INS-loop raw records (one per enrolled member). */
function parse(payload: string): RawRecord<X12Member>[] {
  const segments = payload
    .split(/[~\n]/)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => s.split('*'));
  const loops: string[][][] = [];
  let current: string[][] | null = null;
  for (const seg of segments) {
    if (seg[0] === 'INS') {
      if (current) loops.push(current);
      current = [seg];
    } else if (current) {
      current.push(seg);
    }
  }
  if (current) loops.push(current);
  return loops.map((segs, i) => ({
    sourceRef: subscriberId(segs) ?? `ins-loop-${i + 1}`,
    data: { segments: segs },
  }));
}

function seg(member: X12Member, id: string): string[] | undefined {
  return member.segments.find((s) => s[0] === id);
}
function subscriberId(segs: string[][]): string | undefined {
  const ref = segs.find((s) => s[0] === 'REF' && s[1] === '0F');
  return ref?.[2];
}

/** X12 gender code (DMG-3) -> canonical sex, for probabilistic matching only. */
const X12_SEX: Record<string, 'male' | 'female' | 'other' | 'unknown'> = {
  M: 'male',
  F: 'female',
  U: 'unknown',
};

/**
 * Demographic traits parsed from the INS loop (NM1*IL name + optional DMG
 * dob/sex), carried into identity resolution for probabilistic matching. Used
 * ONLY at the seam — never stored on the record (the subscriber has these, per
 * task; a source without a DMG simply yields name-only, a thinner match).
 */
function demographicsOf(m: X12Member): import('../types').DemographicTraits {
  const nm1 = m.segments.find((s) => s[0] === 'NM1' && s[1] === 'IL');
  const dmg = seg(m, 'DMG');
  return {
    lastName: nm1?.[3],
    firstName: nm1?.[4],
    dob: d8ToIso(dmg?.[1] === 'D8' ? dmg?.[2] : undefined) || undefined,
    sex: dmg ? X12_SEX[(dmg[3] ?? '').toUpperCase()] : undefined,
  };
}

function validate(raw: RawRecord<X12Member>): ValidationResult {
  const issues: ValidationResult['issues'] = [];
  const m = raw.data;
  if (!seg(m, 'INS')) issues.push({ reasonCode: 'missing-ins-segment', fieldPath: 'INS' });
  if (!subscriberId(m.segments)) issues.push({ reasonCode: 'missing-subscriber-id', fieldPath: 'REF*0F' });
  if (!seg(m, 'HD')) issues.push({ reasonCode: 'missing-coverage', fieldPath: 'HD' });
  const dtp = m.segments.find((s) => s[0] === 'DTP' && s[1] === '348');
  if (!dtp) issues.push({ reasonCode: 'missing-coverage-begin', fieldPath: 'DTP*348' });
  return { ok: issues.length === 0, issues };
}

/** D8 (CCYYMMDD) -> ISO date. */
function d8ToIso(d8?: string): string {
  if (!d8 || d8.length < 8) return '';
  return `${d8.slice(0, 4)}-${d8.slice(4, 6)}-${d8.slice(6, 8)}`;
}

function normalize(raw: RawRecord<X12Member>, deps: PipelineDeps): NormalizedRecord {
  const m = raw.data;
  const subId = subscriberId(m.segments)!;
  // Pass the subscriber demographics so a real EMPI resolver can match
  // probabilistically; the deterministic (demo) resolver ignores them.
  const memberId = deps.resolveIdentity(subId, { feed: SOURCE.feed, demographics: demographicsOf(m) });
  const hd = seg(m, 'HD');
  const ins = seg(m, 'INS');
  const dtp = m.segments.find((s) => s[0] === 'DTP' && s[1] === '348');
  const planCode = hd?.[3] ?? 'UNK';
  const maintenanceType = ins?.[3] ?? '';
  const periodStart = d8ToIso(dtp?.[3]);
  const resourceKey = hashKey(`${subId}:${planCode}:${periodStart}`);
  return {
    domain: 'coverage',
    memberId,
    resourceType: 'Coverage',
    fhirResourceId: `Coverage/cov-${resourceKey}`,
    eventType: 'coverage.enrolled',
    tier: 'T1',
    idempotencyKey: `834:cov:${subId}:${planCode}:${periodStart}`,
    provenance: 'payer-authoritative',
    consent: { part2Restricted: false, segmentLabels: [] },
    source: SOURCE,
    occurredAt: periodStart ? `${periodStart}T00:00:00Z` : new Date(deps.now()).toISOString(),
    payload: {
      coverageRef: `Coverage/cov-${resourceKey}`,
      planCode,
      maintenanceTypeCode: maintenanceType,
      periodStart,
      status: 'active',
    },
  };
}

function hashKey(input: string): string {
  let h = 5381;
  for (let i = 0; i < input.length; i++) h = ((h << 5) + h + input.charCodeAt(i)) >>> 0;
  return h.toString(16).padStart(8, '0');
}

/** The 834 eligibility batch adapter. */
export const eligibility834Adapter: DomainAdapter<X12Member> = {
  source: SOURCE,
  domain: 'coverage',
  format: 'x12-834',
  arrivalMode: 'batch',
  parse,
  validate,
  normalize,
};
