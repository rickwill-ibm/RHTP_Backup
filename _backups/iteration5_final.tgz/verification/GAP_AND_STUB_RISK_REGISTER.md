# Gap & Stub Risk Register (retroactive verification of Iterations 0-4)

Produced 2026-08-22 by a three-lens verification panel (healthcare domain-fidelity, negative-space completeness, stub-legitimacy) run against the built code — the new standing verification model (L9), applied retroactively to answer "what else is missing?" This register is cumulative and is updated every iteration going forward.

Source detail: DOMAIN_FIDELITY_FINDINGS.md (26), NEGATIVE_SPACE_FINDINGS.md (31), STUB_LEGITIMACY_FINDINGS.md (26 stubs graded). Totals: ~83 findings. This register ranks the ones that change what we do; the source files carry the full list with failure scenarios.

## Why this register exists

The owner had to personally catch three gaps (identity was a hash stub, no terminology validation, external EMPI protocols missing) that the per-iteration adversarial passes did not. Root cause: those passes verified CONFORMANCE TO PLAN, not CORRECTNESS OF PLAN against healthcare reality, and nobody hunted NEGATIVE SPACE. A labeled stub passed the honesty check even when the stub was load-bearing enough to be a defect. This register is the corrective: verification now attacks three layers (see L9 in the plan).

## RESOLVED THIS SESSION (the 4 Unacceptable stub defects — fixed, not just logged)

These were fail-open / masquerading / dead-wiring defects, worse than the ones the owner caught because they actively mislead. All now fail CLOSED in production, demo still green (873 tests).

| id | defect | fix |
|---|---|---|
| U1 | dev-mock auth defaulted ON; a real-auth production deploy still served a fake "PA approved" from /api/pas/submit | dev-mock auth defaults OFF and is impossible when real auth is configured; explicit opt-in only |
| U2 | structural-only validator masqueraded as the US Core $validate gate and failed OPEN in production | production now fails CLOSED like the terminology gate; renamed so it is not mistaken for real $validate |
| U3 | real EMPI engine scored against 3 mock demo records in production | production throws EmpiCandidateSourceNotConfiguredError; mock source is mock-mode only |
| U4 | evidence "production ledger" seam was dead wiring; DATA_MODE_EVIDENCE=production was a no-op (in-memory) | callers routed through the seam selector; production selects the pg ledger and fails loud if unconfigured |

## CRITICAL — must be owned before any production pilot (open)

| id | area | gap | owning iteration |
|---|---|---|---|
| F1 | X12 834 | maintenance-type codes (INS-3) ignored, status hardcoded active; a termination transaction re-enrolls instead of disenrolling | I5/I6 pipeline hardening |
| F2 | 42 CFR Part 2 | segmentation is a blunt drop on a wrong basis; no consent-directed release, re-disclosure notice, or break-glass | I6 (sensitive domains) + I8A |
| F3 | EMPI | no golden-record survivorship, no cross-reference/link-unlink; id-only records mint a new member per feed, fragmenting the same person across feeds | I8A pillar 1 (external identity) |
| F4 | FHIR conformance | stage-4 gate is 4-field presence; no profile/cardinality/must-support/binding conformance (partly mitigated by U2 fail-closed, but real $validate still absent) | I8A pillar 2 + I9 (HAPI) |
| NS-01 | operability | quarantine, held-identity, and failed-outbox records are return values then dropped; no store, no operator surface, no reviewer UI | NEW BACKLOG: a dead-letter/review subsystem, pull into I5 |
| NS-03 | data lifecycle | no right-to-delete / erasure / retention / purge across the append-only stores (evidence, outbox, graph) | NEW BACKLOG: data-lifecycle iteration |

## HIGH — schedule explicitly (open, selected)

| id | area | gap | owning |
|---|---|---|---|
| F5 | provider identity | no NPI/NPPES resolution; performers/prescribers stay raw strings; breaks attribution, adequacy, referral routing | I8A pillar 1 |
| NS-02 | observability | zero metrics/tracing/correlation-id propagation across all subsystems; runs blind in production | NEW BACKLOG: observability iteration, wire into I9 |
| NS-04 | idempotency | consumer dedupe is in-memory per-call; outbox at-least-once republish can double-produce signals and double-send outreach | I5 convergence (bounded fix) |
| NS-05 | verification | live-integration-executed count is 0; every concurrency/durability guarantee proven only against fakes | I9 (real infra) closes it; until then, honest ceiling |
| R5 | security | sessionSecret defaults to a public constant (cookie forgery if unset) | NEW BACKLOG: quick fail-closed fix, pull into I5 |

## The standing pattern the codebase already has (and where it was skipped)

The repo has a correct safe-stub pattern: production mode throws *NotConfiguredError and fails closed (consent, terminology, dataSources, backbone all do this). Every Unacceptable finding was a place that pattern was skipped, inverted to fail-open, or wired-but-unused. GOING-FORWARD RULE (now L9 + a convention note): a new seam either uses the fail-closed NotConfigured pattern or the verification panel grades it Risky/Unacceptable.

## Disposition summary

- 4 Unacceptable: FIXED this session.
- 6 Critical open: mapped to owning iterations; 2 promoted to NEW BACKLOG (dead-letter/review subsystem; data-lifecycle) because they are cross-cutting subsystems, not domain fill-ins.
- ~15 High: scheduled or backlogged; 2 bounded fixes (NS-04 idempotency, R5 session secret) pulled into Iteration 5 convergence.
- Med + Acceptable: retained in the source files; revisited each iteration.

---

# ITERATION 5 — dead-letter/held-review subsystem, durable idempotency, session-secret fail-closed (Wave C convergence + red-team)

Iteration 5 delivered two subsystems across two waves (A: dead-letter/held-review store for NS-01; B: durable idempotency for NS-04 + the R5 session-secret fix) and converged them in Wave C. This section CLOSES NS-01 / NS-04 / R5, records the Wave-C convergence fix, and appends the mandatory three-persona red-team findings routed against the two new subsystems.

## Closed this iteration

| id | was | closure (verified) |
|---|---|---|
| **NS-01** | quarantine / held-identity / failed-outbox records built then DROPPED; no store, no operator surface | CLOSED. Durable append-only store (`src/lib/deadLetter/`, memory + pg, immutability trigger). Producers PERSIST, verified end-to-end: a held-identity record from `runPipeline` (`persistPipelineDeadLetters`, awaited) and a failed-outbox intent from outbox `failIntent` land in the store and are retrievable via the ops BFF (`/api/ops/dead-letter`, `isOpsPrincipal`-gated, distinct from the clinical work queue). fail-closed-stub seam + governance prober. |
| **NS-04** | consumer dedupe in-memory per-call; at-least-once republish double-produced signals / double-sent outreach | CLOSED. Durable `IdempotencyStore` (`src/lib/idempotency/`, memory + pg PRIMARY-KEY). SDE `intakeSignalsDurable` (`markProcessed('sde-intake',…)`) and both agents (`outreach-agent`, `referral-coordination-agent`) claim-once-before-effect, returning `outcome:'deduped'` on republish. fail-closed-stub seam + governance prober. |
| **R5** | sessionSecret defaulted to a public constant (cookie forgery if unset) | CLOSED. `requireSessionSecret()` throws `SessionSecretNotConfiguredError` in production without `SESSION_SECRET`; a labelled dev secret only under the U1 double-gate (`!tokenUrl && allowDevMockAuth`); static scan bans a public default. |

## Wave-C convergence fix (fail-open drop-path — Unacceptable class, FIXED)

| id | severity | finding | fix |
|---|---|---|---|
| **I5C-1** | Unacceptable (fail-open-under-fault) → FIXED | `failIntent` default seam path built the dead-letter sink and `drain()`ed it but never inspected `sink.errors`; a dead-letter store WRITE failure (store down) was captured out-of-band and swallowed, so the failed-outbox record silently VANISHED — the exact NS-01 drop, re-introduced under fault. The sync-sink-over-async-store fidelity note flagged the out-of-band capture but the default producer path left it unchecked (a cross-wave assumption gap). | `src/lib/outbox/sequencing.ts`: the default path now rethrows `sink.errors[0]` after drain — fail-closed. New test `tests/outbox/failIntent-failclosed.test.ts` (throws on append failure; intent still marked failed first). An explicitly-injected `deps.quarantine` sink retains its own error posture. |

## Red-team panel — R1 Domain-Fidelity (reliability + healthcare data-integrity)

| id | sev | finding | owner |
|---|---|---|---|
| **R1-DL1** | HIGH | **Held-identity review is not adjudicable.** The record carries only a source handle (`system:feed`), a reasonCode, and a `payloadRef` string encoding `tier=/score=`. A steward adjudicating a 60-90 EMPI match needs the CANDIDATE SET (which existing members it might link to, a demographics comparison) and a MERGE / LINK / CREATE-NEW action. `reviewAction` offers only resolve/dismiss/retry (a status transition) — an item can be "resolved" with NO identity decision recorded or applied. Naive vs a real HIE steward workflow. | I8A pillar 1 (EMPI survivorship; dovetails F3) |
| **R1-DL2** | HIGH | **Replay is not idempotent at the producer.** `persistPipelineDeadLetters` appends with deterministic id `dl-{quarantineId}`, but `append` unconditionally pushes a NEW version; a batch replay (at-least-once redelivery / operator re-run) appends a fresh `open` version ON TOP of an already-resolved record, silently RE-OPENING items a reviewer closed. NS-04's idempotency primitive was built but NOT applied to the NS-01 producer path — the cross-wave gap. (Distinct from I5C-1, which is the outbox fault-drop.) | I6 pipeline hardening |
| **R1-DL3** | MED | **Poison-record loop is unbounded.** Pipeline dead-letter records carry no retry-count of their own (failed-outbox only smuggles `attempts` inside `payloadRef`); `reviewAction` retry has no max-retry ceiling or auto-park, so a record that always fails validation can be retried forever. | I6 (dead-letter hardening) |
| **R1-DL4** | MED | **No reconciliation to batch counts.** A resolved dead-letter item does not reconcile against the originating batch's admitted/quarantined/held tallies; an operator cannot prove "batch of N: X admitted, Y held, all Y now resolved." | I9 (observability/reconciliation, NS-02 adjacent) |
| **R1-DL5** | Unacceptable→FIXED | (= I5C-1) `failIntent` swallowed dead-letter write failures. | FIXED Wave C |

## Red-team panel — R2 Negative-Space (absent from THIS iteration that production needs)

Missing-list (owner in brackets):
- **Dead-letter retention / purge / TTL** — the append-only store grows unbounded; NS-03 covers erasure broadly but not a DLQ retention window. [I6/NS-03]
- **Idempotency marker growth / TTL** — one row per (consumer,eventId) forever; no pruning window; unbounded under real event volume. [I6]
- **DLQ depth metrics** — open-count by kind, oldest-open age; zero metrics today. [I9/NS-02]
- **Alerting / SLA on DLQ depth or oldest-open age** — nothing pages when items pile up. [I9/NS-02]
- **Operator notification** when items accumulate (ties to alerting). [I9]
- **Bulk resolve / bulk retry** — `reviewAction` is one-item-at-a-time; a 500-record feed failure is unmanageable click-by-click. [I6]
- **Audit export** — `reviewAction` emits a PHI-safe audit descriptor per action, but there is no export/report of dispositions for compliance. [I6/I8]
- **Ops-role provisioning + separation-of-duties** — `isOpsPrincipal` reuses payer-ops/admin; no provisioning flow and no maker-checker on high-impact merges (same admin creates and resolves). [I8 security]
- **Replay idempotency at the producer** (= R1-DL2). [I6]
- **Retry-lane production binding** — the lane MECHANISM is built + unit-tested with a fake lane, but NO production lane is registered (`setDeadLetterRetryLane` never called with a real lane), so retry is fail-closed-unusable in production. [I6]

## Red-team panel — R3 Stub-Legitimacy (grade the new seams)

| seam / stub | disposition | grade | rationale |
|---|---|---|---|
| **deadLetterStore** | fail-closed-stub | **Acceptable** | Standing safe-stub pattern (mirrors evidence ledger). pg logic real (pg-mem verified + Docker-guarded testcontainer), production factory registerable, throws `DeadLetterStoreNotConfiguredError` until wired. Governance prober present. |
| **idempotencyStore** | fail-closed-stub | **Acceptable** | Same pattern; throws `IdempotencyStoreNotConfiguredError`. Caveat (R3-ID1, MED): the mock/seeded default is a process-global in-memory store that dedupes only within one process — already recorded in FAKE_FIDELITY.md; honest. |
| **retry-lane registry** (`review/lanes.ts`) | (not a dataMode seam) | **Risky** | Mechanism fully built + unit-tested with a fake lane, but NO production lane wired AND it is NOT covered by the seamDispositions governance gate, so retry is silently non-functional in production with only a per-call `retry-lane-not-configured` return. R3-DL2 (MED): register production lanes in I6 OR add it to the disposition manifest / a governance prober so its unwired state is mechanically visible. |

**R3 bootstrapping analysis (the flagged real question — "if the dead-letter store is unconfigured in production, where do dropped records go?").** Because the producers (`persistPipelineDeadLetters`, `failIntent`) route through `getDeadLetterStore()`, a production deploy with `deadLetterStore` UNCONFIGURED makes the producer THROW → the pipeline batch aborts / the outbox drain errors. Records are NOT silently dropped — the operation fails LOUD *before producing them*. That is the correct posture: you must not ingest a feed you cannot durably capture the fallout of; the alternative (fall back to in-memory) is exactly the U4 dead-wiring class. So there is NO bootstrapping hole — the honest answer to "where do dropped records go?" is "nowhere; the operation fails closed and no record is produced." CONSEQUENCE (R3-DL1, MED, doc-only): the dead-letter store is now a HARD production dependency of the pipeline and outbox — deploying `pipeline=production` without `deadLetterStore=production` + `DEAD_LETTER_DATABASE_URL` bricks ingestion. Acceptable, but a DEPLOY-ORDERING CONSTRAINT that must be in the runbook; the demo default masks it (mock serves the in-memory store). Owner: I6/I9 runbook.

## Iteration-5 red-team disposition summary

- **R1 (Domain-Fidelity): 5 findings** — 2 HIGH (held-identity not adjudicable; producer replay not idempotent), 2 MED (poison-loop unbounded; no batch reconciliation), 1 Unacceptable→FIXED (failIntent fault-drop).
- **R2 (Negative-Space): 10-item missing-list** — retention/purge, idempotency TTL, DLQ metrics, alerting/SLA, notification, bulk resolve/retry, audit export, ops-role provisioning + SoD, producer replay idempotency, retry-lane production binding. All owned by I6/I8/I9; none blocks the demo, all block a real payer/HIE data operation.
- **R3 (Stub-Legitimacy): 2 Acceptable seams + 1 Risky stub** — deadLetterStore Acceptable, idempotencyStore Acceptable (1 MED fidelity caveat), retry-lane registry Risky (unwired + ungoverned). Bootstrapping question resolved: fail-closed, no silent drop, but a documented hard production dependency (1 MED doc-only).
- **Unacceptable fixed this wave: 1** (I5C-1 / R1-DL5 — failIntent dead-letter fault-drop).
- No new CRITICAL. New findings are HIGH/MED, owned by I6 (dead-letter/idempotency hardening), I8 (security/SoD), I9 (observability/reconciliation).
