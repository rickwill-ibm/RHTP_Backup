// CONTRACT: C9  // CONTRACT: C10  // DP-1
/**
 * Referrals mapping spec: referral request events -> the member's referral
 * subgraph. ONE new node type, a dated associative link to the member, and (when
 * the referral names a performer) a dated associative link to the RAW performer
 * reference node:
 *
 *   (Member)-[:REFERRED_VIA {valid from authoredOn}]->(ServiceRequest)      associative
 *   (ServiceRequest)-[:REFERRED_TO {valid from authoredOn}]->(Org|Practitioner)  associative
 *
 * REFERRED_VIA is a FACTUAL order link (associative), dated from the authoredOn
 * date so an asOf query can ask "what referrals were open as of X" and the
 * whole-person lens surfaces the ServiceRequest off the member. It mirrors the
 * medications PRESCRIBED_FOR order semantics: a referral is an intent/order the
 * referring provider placed, not an asserted causal claim about the member's
 * state. The referring provenance travels as a node/edge property (PHI-safe).
 *
 * REFERRED_TO links the referral to the performer named in the source. The
 * performer node is a RAW REFERENCE ONLY — its key is the opaque source ref and it
 * carries `providerResolution: 'deferred-I8A'`. We do NOT invent provider identity
 * here: real NPI/NPPES resolution of the performer organization or practitioner is
 * deferred to I8A (see the wave report). The node kind is derived from the ref
 * prefix so it reuses the existing Practitioner / Organization node types.
 *
 * The pinned namespace (L3) is exported so tests/pipeline/domainNamespaceIntegrity
 * can assert every surface (adapter, mapping, registry) agrees (F-C1 lesson).
 */
import type { C2Event } from '@/lib/outbox';
import type { Mutation, ProjectorDeps } from '../types';
import { MEMBER_KIND, associative, memberNode, resourceNode } from './spec';

/** Pinned referrals namespace — the single source of truth the integrity test pins. */
export const REFERRAL_DOMAIN = 'referrals';
export const SERVICE_REQUEST_KIND = 'ServiceRequest';
export const REFERRED_VIA = 'REFERRED_VIA';
/** The associative link to the raw (unresolved) performer reference node. */
export const REFERRED_TO = 'REFERRED_TO';

function str(v: unknown, fallback = ''): string {
  return typeof v === 'string' ? v : fallback;
}
function serviceCode(p: Record<string, unknown>): string {
  const c = (p.serviceCode ?? {}) as Record<string, unknown>;
  return str(c.code);
}
/** The node kind for a raw performer ref: its resource-type prefix, or Organization. */
function performerKind(ref: string): string {
  const prefix = ref.split('/')[0];
  return prefix || 'Organization';
}

export const referralSpec = {
  domain: REFERRAL_DOMAIN,
  matches(eventType: string): boolean {
    return eventType.startsWith('referral.');
  },
  toMutations(event: C2Event, deps: ProjectorDeps): Mutation[] {
    const p = event.payload;
    const referralRef = str(p.referralRef, `ServiceRequest/${event.memberId}`);
    const start = str(p.authoredOn) || event.occurredAt || new Date(deps.now()).toISOString();
    const code = serviceCode(p);
    const out: Mutation[] = [memberNode(event)];
    out.push(
      ...resourceNode(event, SERVICE_REQUEST_KIND, referralRef, {
        serviceCode: code,
        status: str(p.status, 'active'),
        intent: str(p.intent, 'order'),
        authoredOn: str(p.authoredOn),
        provenance: str(p.provenance),
      }),
    );
    // The member was REFERRED_VIA this ServiceRequest — a factual order link
    // (associative), dated from the authoredOn date. Provenance is carried as an
    // edge property, not a causal assertion (a referral is an order, not a claim).
    out.push({
      op: 'UpsertEdge',
      type: REFERRED_VIA,
      from: { kind: MEMBER_KIND, key: event.memberId },
      to: { kind: SERVICE_REQUEST_KIND, key: referralRef },
      properties: { serviceCode: code, provenance: str(p.provenance) },
      validity: { start, end: null },
      semantics: associative,
    });
    // When the source named a performer, link the referral to that RAW reference
    // node. The performer key is the opaque source ref and the node is flagged as
    // an unresolved provider ref: real NPI/NPPES resolution is deferred to I8A.
    // We never invent provider identity (no name, no resolved NPI) here.
    const performerRef = str(p.performerRef);
    if (performerRef) {
      const kind = performerKind(performerRef);
      out.push(
        ...resourceNode(event, kind, performerRef, {
          rawRef: performerRef,
          providerResolution: 'deferred-I8A',
        }),
      );
      out.push({
        op: 'UpsertEdge',
        type: REFERRED_TO,
        from: { kind: SERVICE_REQUEST_KIND, key: referralRef },
        to: { kind, key: performerRef },
        properties: { providerResolution: 'deferred-I8A' },
        validity: { start, end: null },
        semantics: associative,
      });
    }
    return out;
  },
};
