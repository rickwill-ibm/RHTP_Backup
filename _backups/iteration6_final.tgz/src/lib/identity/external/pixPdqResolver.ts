/**
 * PIX/PDQ (HL7v2) external identity resolver — HONEST STUB.
 *
 * Implements the ExternalIdentityResolver seam for the HL7v2 messaging family:
 *   crossReference  -> PIX  QBP^Q23 / RSP^K23 (Patient Identifier Cross-ref)
 *   demographicQuery-> PDQ  QBP^Q22 / RSP^K22 (Patient Demographics Query)
 *
 * Every call throws ExternalEmpiNotConfiguredError naming the HL7v2 config it
 * needs (endpoint, assigning authority OID, sending/receiving app+facility).
 * When wired, replace the throws with MLLP send/receive + HL7v2 QBP/RSP parsing.
 */
import type { IdentityResolver } from '@/lib/pipeline/types';
import {
  ExternalEmpiNotConfiguredError,
  type ExternalIdentityResolver,
  type PdqQuery,
  type PdqResponse,
  type PixPdqConfig,
  type PixQuery,
  type PixResponse,
} from './types';

const PROTOCOL = 'PIX/PDQ' as const;

/** The HL7v2 config keys an operator must supply for this family to go live. */
const NEEDS =
  'PIXPDQ_ENDPOINT (MLLP host:port), PIXPDQ_ASSIGNING_AUTHORITY_OID, ' +
  'PIXPDQ_SENDING_APP, PIXPDQ_SENDING_FACILITY, PIXPDQ_RECEIVING_APP, PIXPDQ_RECEIVING_FACILITY';

function requireConfig(capability: string, config?: PixPdqConfig): PixPdqConfig {
  if (
    !config ||
    !config.endpoint ||
    !config.assigningAuthorityOid ||
    !config.sendingApplication ||
    !config.sendingFacility ||
    !config.receivingApplication ||
    !config.receivingFacility
  ) {
    throw new ExternalEmpiNotConfiguredError(PROTOCOL, capability, NEEDS);
  }
  return config;
}

/**
 * Construct the PIX/PDQ resolver. Config is optional so the seam can be selected
 * before an endpoint exists; every call still throws until config is complete.
 */
export function createPixPdqResolver(config?: PixPdqConfig): ExternalIdentityResolver {
  return {
    id: 'external-pixpdq-hl7v2',
    protocol: PROTOCOL,
    async crossReference(_query: PixQuery): Promise<PixResponse> {
      requireConfig('PIX cross-reference (QBP^Q23 / RSP^K23)', config);
      // Wired impl: build QBP^Q23, MLLP-send to config.endpoint, parse RSP^K23,
      // return the enterprise CX + peer-domain cross references.
      throw new ExternalEmpiNotConfiguredError(PROTOCOL, 'PIX cross-reference', NEEDS);
    },
    async demographicQuery(_query: PdqQuery): Promise<PdqResponse> {
      requireConfig('PDQ demographics query (QBP^Q22 / RSP^K22)', config);
      // Wired impl: build QBP^Q22 from traits, MLLP-send, parse RSP^K22 PID
      // segments into candidates with QRI-1 match confidence.
      throw new ExternalEmpiNotConfiguredError(PROTOCOL, 'PDQ demographics query', NEEDS);
    },
  };
}

/** Default PIX/PDQ resolver with no config (throws until an endpoint is set). */
export const pixPdqResolver: ExternalIdentityResolver = createPixPdqResolver();

/**
 * The PIX/PDQ family as the pipeline's synchronous IdentityResolver seam. A real
 * PIX call is async; this stub throws ExternalEmpiNotConfiguredError immediately
 * (fail loud) before any I/O. Going live requires either a pre-resolution step
 * or making IdentityResolver async — a noted roadmap item (see README).
 */
export const pixPdqIdentityResolver: IdentityResolver = () => {
  throw new ExternalEmpiNotConfiguredError('PIX/PDQ', 'pipeline identity resolution', NEEDS);
};
