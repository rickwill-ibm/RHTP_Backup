/**
 * PIXm/PDQm (FHIR) external identity resolver — HONEST STUB.
 *
 * Implements the ExternalIdentityResolver seam for the FHIR family:
 *   crossReference   -> PIXm  Patient/$ihe-pix (sourceIdentifier -> targetSystem)
 *   demographicQuery -> PDQm  GET Patient?family=&given=&birthdate=... (Bundle)
 *
 * Every call throws ExternalEmpiNotConfiguredError naming the FHIR config it
 * needs (FHIR base URL + auth + assigning authority system). When wired, replace
 * the throws with fetch() to the FHIR server and Bundle/Parameters parsing.
 */
import type { IdentityResolver } from '@/lib/pipeline/types';
import {
  ExternalEmpiNotConfiguredError,
  type ExternalIdentityResolver,
  type PdqQuery,
  type PdqResponse,
  type PixmPdqmConfig,
  type PixQuery,
  type PixResponse,
} from './types';

const PROTOCOL = 'PIXm/PDQm' as const;

/** The FHIR config keys an operator must supply for this family to go live. */
const NEEDS =
  'PIXM_FHIR_BASE_URL, PIXM_ASSIGNING_AUTHORITY_SYSTEM, and auth ' +
  '(PIXM_AUTH_KIND = none|bearer|basic|smart-backend + its credentials)';

function requireConfig(capability: string, config?: PixmPdqmConfig): PixmPdqmConfig {
  if (!config || !config.fhirBaseUrl || !config.assigningAuthoritySystem || !config.auth) {
    throw new ExternalEmpiNotConfiguredError(PROTOCOL, capability, NEEDS);
  }
  return config;
}

/**
 * Construct the PIXm/PDQm resolver. Config is optional so the seam can be
 * selected before a FHIR endpoint exists; every call throws until config is set.
 */
export function createPixmPdqmResolver(config?: PixmPdqmConfig): ExternalIdentityResolver {
  return {
    id: 'external-pixm-pdqm-fhir',
    protocol: PROTOCOL,
    async crossReference(_query: PixQuery): Promise<PixResponse> {
      requireConfig('PIXm $ihe-pix operation', config);
      // Wired impl: GET {base}/Patient/$ihe-pix?sourceIdentifier=..&targetSystem=..,
      // parse the Parameters response into the enterprise id + cross references.
      throw new ExternalEmpiNotConfiguredError(PROTOCOL, 'PIXm $ihe-pix operation', NEEDS);
    },
    async demographicQuery(_query: PdqQuery): Promise<PdqResponse> {
      requireConfig('PDQm Patient search', config);
      // Wired impl: GET {base}/Patient?family=..&given=..&birthdate=.., parse the
      // searchset Bundle entries into candidates with entry.search.score.
      throw new ExternalEmpiNotConfiguredError(PROTOCOL, 'PDQm Patient search', NEEDS);
    },
  };
}

/** Default PIXm/PDQm resolver with no config (throws until a base URL is set). */
export const pixmPdqmResolver: ExternalIdentityResolver = createPixmPdqmResolver();

/**
 * The PIXm/PDQm family as the pipeline's synchronous IdentityResolver seam. A
 * real PIXm call is async; this stub throws ExternalEmpiNotConfiguredError
 * immediately (fail loud). Going live requires a pre-resolution step or an async
 * IdentityResolver — a noted roadmap item (see README).
 */
export const pixmPdqmIdentityResolver: IdentityResolver = () => {
  throw new ExternalEmpiNotConfiguredError('PIXm/PDQm', 'pipeline identity resolution', NEEDS);
};
