'use client';

// ─── fhirCareTeamData.data.ts ─────────────────────────────────────────────────
// CareTeam participants, FHIR Tasks, inbox builder, and UI config data.

import type {
  FHIRCareTeam, FHIRTask, CareTeamInboxTask,
  TaskStatus, TaskPriority, TaskProgramType,
} from './fhirCareTeamData.types';

// ─── FHIR CareTeam for Dorothy Simmons (PAT-0042) ────────────────────────────

export const PATIENT_CARE_TEAM: FHIRCareTeam = {
  resourceType: 'CareTeam',
  id: 'ct-pat-0042',
  status: 'active',
  name: 'Dorothy Simmons — RHTP Integrated Care Team',
  subject: { reference: 'Patient/PAT-0042', display: 'Dorothy Simmons' },
  managingOrganization: 'RHTP Platform — South Dakota DHSS',
  period: { start: '2025-01-01' },
  participants: [
    // ── Clinical ──────────────────────────────────────────────────────────────
    { id: 'ct-p-001', name: 'Dr. James Whitfield', roleCode: '446050000', roleDisplay: 'Primary Care Physician', roleCategory: 'Clinical', organization: 'Bennett County Health Services', organizationId: 'org-001', contact: 'james.whitfield@bennettcountyhealth.org', period: { start: '2025-01-01' }, onBehalfOf: 'Bennett County Health Services — Martin, SD 57551', activeTaskCount: 2, status: 'active', participantType: 'PractitionerRole' },
    { id: 'ct-p-002', name: 'Dr. Amara Osei', roleCode: '17561000', roleDisplay: 'Cardiologist', roleCategory: 'Clinical', organization: 'Monument Health Cardiology', organizationId: 'org-002', contact: 'a.osei@monumenthealth.org', period: { start: '2025-03-15' }, onBehalfOf: 'Monument Health Cardiology — 677 Cathedral Dr, Rapid City, SD 57701', activeTaskCount: 1, status: 'active', participantType: 'PractitionerRole' },
    { id: 'ct-p-003', name: 'Dr. Kenji Nakamura', roleCode: '41672002', roleDisplay: 'Pulmonologist', roleCategory: 'Clinical', organization: 'Avera Sacred Heart CAH', organizationId: 'org-003', contact: 'k.nakamura@averasacredheart.org', period: { start: '2025-06-01' }, onBehalfOf: 'Avera Sacred Heart CAH — 501 Summit St, Winner, SD 57580', activeTaskCount: 0, status: 'active', participantType: 'PractitionerRole' },
    // ── Care Management ───────────────────────────────────────────────────────
    { id: 'ct-p-004', name: 'Sarah Johnson', roleCode: '224571005', roleDisplay: 'Care Manager', roleCategory: 'Care Management', organization: 'RHTP Care Management Team — Bennett County', organizationId: 'org-004', contact: 'sarah.johnson@bennettcountyhealth.org', period: { start: '2025-01-01' }, onBehalfOf: 'RHTP Platform — South Dakota DHSS', activeTaskCount: 4, status: 'active', participantType: 'PractitionerRole' },
    { id: 'ct-p-005', name: 'Angela Torres', roleCode: '768820003', roleDisplay: 'Community Health Worker', roleCategory: 'Care Management', organization: 'Bennett County Action CBO', organizationId: 'org-005', contact: 'a.torres@bennettcountyaction.org', period: { start: '2025-04-01' }, onBehalfOf: 'Bennett County Action CBO — 204 W 3rd St, Martin, SD 57551', activeTaskCount: 2, status: 'active', participantType: 'PractitionerRole' },
    // ── Behavioral Health ─────────────────────────────────────────────────────
    { id: 'ct-p-006', name: 'Dr. Sarah Nakamura', roleCode: '224587008', roleDisplay: 'Behavioral Health Counselor', roleCategory: 'Behavioral Health', organization: 'Avera Behavioral Health — Winner', organizationId: 'org-006', contact: 's.nakamura@avera.org', period: { start: '2025-05-10' }, onBehalfOf: 'Avera Behavioral Health — 501 Summit St, Winner, SD 57580', activeTaskCount: 1, status: 'active', participantType: 'PractitionerRole' },
    { id: 'ct-p-007', name: 'Lisa Fontaine, LCSW', roleCode: '106330007', roleDisplay: 'Social Worker', roleCategory: 'Behavioral Health', organization: 'Bennett County Health Services — BH', organizationId: 'org-007', contact: 'l.fontaine@bennettcountyhealth.org', period: { start: '2025-07-01' }, onBehalfOf: 'Bennett County Health Services — 102 N Van Buren St, Martin, SD 57551', activeTaskCount: 1, status: 'active', participantType: 'PractitionerRole' },
    // ── Community & Social ────────────────────────────────────────────────────
    { id: 'ct-p-008', name: 'James Holloway', roleCode: 'CBO-FOOD', roleDisplay: 'Food Security Case Worker', roleCategory: 'Community & Social', organization: 'Oglala Sioux Tribe Community Services', organizationId: 'org-008', contact: 'j.holloway@ostcs.org', period: { start: '2025-09-01' }, onBehalfOf: 'Oglala Sioux Tribe Community Services — 1 Crazy Horse Dr, Pine Ridge, SD 57770', activeTaskCount: 1, status: 'active', participantType: 'RelatedPerson' },
    { id: 'ct-p-009', name: 'Sandra Kim', roleCode: 'CBO-HOUSING', roleDisplay: 'Housing Navigator', roleCategory: 'Community & Social', organization: 'SD Housing Development Authority', organizationId: 'org-009', contact: 's.kim@sdhda.org', period: { start: '2025-10-15' }, onBehalfOf: 'SD Housing Development Authority — 3060 E Elizabeth St, Pierre, SD 57501', activeTaskCount: 1, status: 'active', participantType: 'RelatedPerson' },
    { id: 'ct-p-010', name: 'Tony Reyes', roleCode: 'CBO-TRANSPORT', roleDisplay: 'Transportation Coordinator', roleCategory: 'Community & Social', organization: 'Medicaid NEMT — Bennett County', organizationId: 'org-010', contact: 't.reyes@sd.gov', period: { start: '2025-11-01' }, onBehalfOf: 'Medicaid NEMT — 102 N Van Buren St, Martin, SD 57551', activeTaskCount: 0, status: 'active', participantType: 'RelatedPerson' },
  ],
};

// ─── FHIR Tasks — Multi-Program Closed-Loop ───────────────────────────────────

export const FHIR_TASKS: FHIRTask[] = [
  { id: 'task-fhir-001', resourceType: 'Task', status: 'in-progress', intent: 'order', priority: 'urgent', programType: 'Clinical', code: 'fulfill-referral', description: 'Cardiology Evaluation — Uncontrolled Hypertension with HFpEF comorbidity', for: { reference: 'Patient/PAT-0042', display: 'Dorothy Simmons' }, requester: { reference: 'Practitioner/whitfield', display: 'Dr. James Whitfield', role: 'PCP' }, owner: { reference: 'Practitioner/osei', display: 'Dr. Amara Osei', role: 'Cardiologist', organization: 'Monument Health Cardiology — Rapid City, SD 57701' }, authoredOn: '2026-04-10T09:00:00Z', lastModified: '2026-04-12T14:30:00Z', dueDate: '2026-06-15', reasonCode: 'I10', reasonDisplay: 'Essential Hypertension — HEDIS CBP-236', gainShareValue: '$195', qualityMeasureImpact: 'HEDIS CBP-236 — Controlling Hypertension', note: 'BP 158/96 on 3 medications. JNC 8 resistant HTN criteria met. 147 miles to Monument Health Rapid City.' },
  { id: 'task-fhir-002', resourceType: 'Task', status: 'requested', intent: 'order', priority: 'routine', programType: 'Clinical', code: 'fulfill-referral', description: 'Diabetic Eye Exam — HEDIS EED gap closure', for: { reference: 'Patient/PAT-0042', display: 'Dorothy Simmons' }, requester: { reference: 'Practitioner/whitfield', display: 'Dr. James Whitfield', role: 'PCP' }, owner: { reference: 'Practitioner/ophth-001', display: 'Dr. Sarah Chen', role: 'Ophthalmologist', organization: 'Avera Sacred Heart CAH — Winner, SD 57580' }, authoredOn: '2026-04-14T10:00:00Z', lastModified: '2026-04-14T10:00:00Z', dueDate: '2026-09-30', reasonCode: 'E11.65', reasonDisplay: 'T2DM — HEDIS EED Diabetic Eye Exam', gainShareValue: '$110', qualityMeasureImpact: 'HEDIS EED — Diabetic Eye Exam' },
  { id: 'task-fhir-003', resourceType: 'Task', status: 'accepted', intent: 'order', priority: 'urgent', programType: 'Behavioral Health', code: 'bh-assessment', description: 'PHQ-9 Depression Screening + Integrated BH Assessment — MDD comorbidity', for: { reference: 'Patient/PAT-0042', display: 'Dorothy Simmons' }, requester: { reference: 'Practitioner/johnson', display: 'Sarah Johnson', role: 'Care Manager' }, owner: { reference: 'Practitioner/nakamura-bh', display: 'Dr. Sarah Nakamura', role: 'BH Counselor', organization: 'Avera Behavioral Health — Winner, SD 57580' }, authoredOn: '2026-04-15T11:00:00Z', lastModified: '2026-04-16T09:00:00Z', dueDate: '2026-05-15', reasonCode: 'F32.1', reasonDisplay: 'Major Depressive Disorder — BH Integration Program', note: 'PHQ-9 score 14 at last visit. Integrated BH assessment needed. 47 miles to Avera Sacred Heart, Winner SD.' },
  { id: 'task-fhir-004', resourceType: 'Task', status: 'in-progress', intent: 'plan', priority: 'routine', programType: 'Behavioral Health', code: 'bh-assessment', description: 'Social Work Assessment — Housing instability and social isolation screening', for: { reference: 'Patient/PAT-0042', display: 'Dorothy Simmons' }, requester: { reference: 'Practitioner/nakamura-bh', display: 'Dr. Sarah Nakamura', role: 'BH Counselor' }, owner: { reference: 'Practitioner/fontaine', display: 'Lisa Fontaine, LCSW', role: 'Social Worker', organization: 'Bennett County Health Services — Martin, SD 57551' }, authoredOn: '2026-04-16T10:00:00Z', lastModified: '2026-04-18T14:00:00Z', dueDate: '2026-05-20', reasonCode: 'Z60.2', reasonDisplay: 'Social isolation — PRAPARE screening positive' },
  { id: 'task-fhir-005', resourceType: 'Task', status: 'in-progress', intent: 'order', priority: 'urgent', programType: 'Food Security', code: 'food-referral', description: 'SNAP Enrollment Assistance + SD Food Bank Referral — AHC-HRSN food insecurity positive', for: { reference: 'Patient/PAT-0042', display: 'Dorothy Simmons' }, requester: { reference: 'Practitioner/torres', display: 'Angela Torres', role: 'Community Health Worker' }, owner: { reference: 'RelatedPerson/holloway', display: 'James Holloway', role: 'Food Security Case Worker', organization: 'Oglala Sioux Tribe Community Services — Pine Ridge, SD 57770' }, authoredOn: '2026-04-18T09:00:00Z', lastModified: '2026-04-20T11:00:00Z', dueDate: '2026-05-10', reasonCode: 'Z59.4', reasonDisplay: 'Food insecurity — AHC-HRSN domain positive', note: 'Patient reports skipping meals 3+ days/week. SNAP renewal at SD DSS Bennett County Office, 102 N Van Buren St, Martin SD 57551.' },
  { id: 'task-fhir-006', resourceType: 'Task', status: 'accepted', intent: 'order', priority: 'asap', programType: 'Housing', code: 'housing-navigation', description: 'Housing Stability Assessment + SDHDA Rental Assistance Navigation', for: { reference: 'Patient/PAT-0042', display: 'Dorothy Simmons' }, requester: { reference: 'Practitioner/fontaine', display: 'Lisa Fontaine, LCSW', role: 'Social Worker' }, owner: { reference: 'RelatedPerson/kim', display: 'Sandra Kim', role: 'Housing Navigator', organization: 'SD Housing Development Authority — Pierre, SD 57501' }, authoredOn: '2026-04-19T10:00:00Z', lastModified: '2026-04-21T09:00:00Z', dueDate: '2026-06-01', reasonCode: 'Z59.0', reasonDisplay: 'Housing instability — PRAPARE positive', note: 'Patient at risk of eviction. SDHDA rental assistance waitlist application initiated. 3060 E Elizabeth St, Pierre SD 57501.' },
  { id: 'task-fhir-007', resourceType: 'Task', status: 'completed', intent: 'order', priority: 'routine', programType: 'Transportation', code: 'transport-arrangement', description: 'NEMT Arrangement — Annual Wellness Visit transport', for: { reference: 'Patient/PAT-0042', display: 'Dorothy Simmons' }, requester: { reference: 'Practitioner/johnson', display: 'Sarah Johnson', role: 'Care Manager' }, owner: { reference: 'RelatedPerson/reyes', display: 'Tony Reyes', role: 'Transportation Coordinator', organization: 'Medicaid NEMT — Martin, SD 57551' }, authoredOn: '2026-04-01T08:00:00Z', lastModified: '2026-04-28T16:00:00Z', dueDate: '2026-04-28', reasonCode: 'Z71.89', reasonDisplay: 'Transportation barrier — AWV attendance', output: { type: 'DocumentReference', valueReference: 'DocumentReference/transport-confirm-001', description: 'NEMT trip confirmed — Round trip to Bennett County Health, Martin SD 57551, 04/28/2026', date: '2026-04-28' }, note: 'Transport completed via Medicaid NEMT. Patient attended AWV at Bennett County Health.' },
  { id: 'task-fhir-008', resourceType: 'Task', status: 'in-progress', intent: 'plan', priority: 'routine', programType: 'Social Isolation', code: 'wellness-check', description: 'Weekly Wellness Check-In + SD Area Agency on Aging Community Connection', for: { reference: 'Patient/PAT-0042', display: 'Dorothy Simmons' }, requester: { reference: 'Practitioner/fontaine', display: 'Lisa Fontaine, LCSW', role: 'Social Worker' }, owner: { reference: 'Practitioner/torres', display: 'Angela Torres', role: 'Community Health Worker', organization: 'Bennett County Action CBO — Martin, SD 57551' }, authoredOn: '2026-04-20T09:00:00Z', lastModified: '2026-04-22T10:00:00Z', dueDate: '2026-05-31', reasonCode: 'Z60.2', reasonDisplay: 'Social isolation — PRAPARE positive', note: 'Patient lives alone in Martin SD 57551. 2 weekly check-in calls completed. SD Area Agency on Aging referral pending.' },
];

// ─── Care Team Inbox Tasks ────────────────────────────────────────────────────

export function buildCareTeamInboxTasks(
  activePatientName: string,
  activePatientId: string,
  activePatientDob: string,
  activePatientRiskTier: string
): CareTeamInboxTask[] {
  return [
    ...FHIR_TASKS.map((t) => ({
      ...t,
      patientName: activePatientName,
      patientId: activePatientId,
      patientDob: activePatientDob,
      patientRiskTier: activePatientRiskTier,
      assignedParticipantId: t.owner.reference,
    })),
    { id: 'task-fhir-009', resourceType: 'Task' as const, status: 'requested' as TaskStatus, intent: 'order' as const, priority: 'urgent' as TaskPriority, programType: 'Clinical' as TaskProgramType, code: 'fulfill-referral', description: 'Nephrology Consult — CKD Stage 3b Monitoring, T2DM comorbidity', for: { reference: 'Patient/PAT-0087', display: 'James Wilson' }, requester: { reference: 'Practitioner/johnson', display: 'Sarah Johnson', role: 'Care Manager' }, owner: { reference: 'Practitioner/nephro-001', display: 'Dr. Priya Venkataraman', role: 'Nephrologist', organization: 'Avera Sacred Heart CAH — Winner, SD 57580' }, authoredOn: '2026-04-20T09:00:00Z', lastModified: '2026-04-20T09:00:00Z', dueDate: '2026-05-30', reasonCode: 'N18.32', reasonDisplay: 'CKD Stage 3b — HEDIS CDC-001', gainShareValue: '$220', qualityMeasureImpact: 'HEDIS CDC-001 — A1C Control', patientName: 'James Wilson', patientId: 'PAT-0087', patientDob: '1948-07-22', patientRiskTier: 'High', assignedParticipantId: 'Practitioner/nephro-001' },
    { id: 'task-fhir-010', resourceType: 'Task' as const, status: 'accepted' as TaskStatus, intent: 'order' as const, priority: 'asap' as TaskPriority, programType: 'Behavioral Health' as TaskProgramType, code: 'bh-assessment', description: 'GAD-7 Anxiety Screening + BH Care Plan Update', for: { reference: 'Patient/PAT-0113', display: 'Robert Chen' }, requester: { reference: 'Practitioner/whitfield', display: 'Dr. James Whitfield', role: 'PCP' }, owner: { reference: 'Practitioner/nakamura-bh', display: 'Dr. Sarah Nakamura', role: 'BH Counselor', organization: 'Avera Behavioral Health — Winner, SD 57580' }, authoredOn: '2026-04-22T10:00:00Z', lastModified: '2026-04-23T09:00:00Z', dueDate: '2026-05-22', reasonCode: 'F41.1', reasonDisplay: 'Generalized Anxiety Disorder — BH Integration', patientName: 'Robert Chen', patientId: 'PAT-0113', patientDob: '1955-11-08', patientRiskTier: 'High', assignedParticipantId: 'Practitioner/nakamura-bh' },
    { id: 'task-fhir-011', resourceType: 'Task' as const, status: 'in-progress' as TaskStatus, intent: 'order' as const, priority: 'urgent' as TaskPriority, programType: 'Food Security' as TaskProgramType, code: 'food-referral', description: 'Emergency Food Box + WIC Enrollment — Pediatric household food insecurity', for: { reference: 'Patient/PAT-0156', display: 'Lisa Thompson' }, requester: { reference: 'Practitioner/torres', display: 'Angela Torres', role: 'Community Health Worker' }, owner: { reference: 'RelatedPerson/holloway', display: 'James Holloway', role: 'Food Security Case Worker', organization: 'Oglala Sioux Tribe Community Services — Pine Ridge, SD 57770' }, authoredOn: '2026-04-25T08:00:00Z', lastModified: '2026-04-26T11:00:00Z', dueDate: '2026-05-05', reasonCode: 'Z59.4', reasonDisplay: 'Food insecurity — AHC-HRSN positive', patientName: 'Lisa Thompson', patientId: 'PAT-0156', patientDob: '1943-05-30', patientRiskTier: 'Moderate', assignedParticipantId: 'RelatedPerson/holloway' },
    { id: 'task-fhir-012', resourceType: 'Task' as const, status: 'requested' as TaskStatus, intent: 'order' as const, priority: 'asap' as TaskPriority, programType: 'Housing' as TaskProgramType, code: 'housing-navigation', description: 'Emergency Housing Placement — SDHDA Rental Assistance referral', for: { reference: 'Patient/PAT-0201', display: 'James Okafor' }, requester: { reference: 'Practitioner/fontaine', display: 'Lisa Fontaine, LCSW', role: 'Social Worker' }, owner: { reference: 'RelatedPerson/kim', display: 'Sandra Kim', role: 'Housing Navigator', organization: 'SD Housing Development Authority — Pierre, SD 57501' }, authoredOn: '2026-04-28T09:00:00Z', lastModified: '2026-04-28T09:00:00Z', dueDate: '2026-05-02', reasonCode: 'Z59.0', reasonDisplay: 'Housing instability — emergency placement needed', patientName: 'James Okafor', patientId: 'PAT-0201', patientDob: '1960-09-17', patientRiskTier: 'Critical', assignedParticipantId: 'RelatedPerson/kim' },
    { id: 'task-fhir-013', resourceType: 'Task' as const, status: 'completed' as TaskStatus, intent: 'order' as const, priority: 'stat' as TaskPriority, programType: 'Clinical' as TaskProgramType, code: 'fulfill-referral', description: 'Pulmonology Follow-up — COPD Exacerbation Risk, 2 ER visits in 90 days', for: { reference: 'Patient/PAT-0201', display: 'James Okafor' }, requester: { reference: 'Practitioner/whitfield', display: 'Dr. James Whitfield', role: 'PCP' }, owner: { reference: 'Practitioner/nakamura', display: 'Dr. Kenji Nakamura', role: 'Pulmonologist', organization: 'Avera Sacred Heart CAH — Winner, SD 57580' }, authoredOn: '2026-04-01T08:00:00Z', lastModified: '2026-04-15T16:00:00Z', dueDate: '2026-04-15', reasonCode: 'J44.1', reasonDisplay: 'COPD — MIPS-398 Management', gainShareValue: '$165', qualityMeasureImpact: 'MIPS-398 — COPD Management', output: { type: 'Procedure', valueReference: 'Procedure/pulm-followup-001', description: 'Spirometry completed at Avera Sacred Heart CAH, Winner SD. Medication adjusted. Pulm rehab referral placed.', date: '2026-04-15' }, patientName: 'James Okafor', patientId: 'PAT-0201', patientDob: '1960-09-17', patientRiskTier: 'Critical', assignedParticipantId: 'Practitioner/nakamura' },
  ];
}

// Legacy static export for backward compatibility — defaults to Maria Redhawk
export const CARE_TEAM_INBOX_TASKS: CareTeamInboxTask[] = buildCareTeamInboxTasks(
  'Maria Redhawk', 'MARIA_SD_001', '1992-03-22', 'Moderate'
);

// ─── UI Config ────────────────────────────────────────────────────────────────

export const PROGRAM_TYPE_CONFIG: Record<TaskProgramType, { color: string; bg: string; border: string; icon: string; label: string }> = {
  'Clinical': { color: 'text-[#0043ce]', bg: 'bg-[#d0e2ff]', border: 'border-[#97c1ff]', icon: 'HeartIcon', label: 'Clinical' },
  'Behavioral Health': { color: 'text-[#6929c4]', bg: 'bg-[#f6f2ff]', border: 'border-[#d4bbff]', icon: 'BrainIcon', label: 'Behavioral Health' },
  'Food Security': { color: 'text-[#b45309]', bg: 'bg-[#fdf6dd]', border: 'border-[#f1c21b]', icon: 'ShoppingCartIcon', label: 'Food Security' },
  'Housing': { color: 'text-[#0e6027]', bg: 'bg-[#defbe6]', border: 'border-[#a7f0ba]', icon: 'HomeIcon', label: 'Housing' },
  'Transportation': { color: 'text-[#005d5d]', bg: 'bg-[#d9fbfb]', border: 'border-[#9ef0f0]', icon: 'TruckIcon', label: 'Transportation' },
  'Social Isolation': { color: 'text-[#da1e28]', bg: 'bg-[#fff1f1]', border: 'border-[#ffb3b8]', icon: 'UserGroupIcon', label: 'Social Isolation' },
};

export const TASK_STATUS_CONFIG: Record<TaskStatus, { color: string; bg: string; label: string }> = {
  'requested': { color: 'text-carbon-gray-70', bg: 'bg-carbon-gray-10', label: 'Requested' },
  'accepted': { color: 'text-[#b45309]', bg: 'bg-[#fdf6dd]', label: 'Accepted' },
  'in-progress': { color: 'text-[#0043ce]', bg: 'bg-[#d0e2ff]', label: 'In Progress' },
  'completed': { color: 'text-[#0e6027]', bg: 'bg-[#defbe6]', label: 'Completed' },
  'rejected': { color: 'text-[#da1e28]', bg: 'bg-[#fff1f1]', label: 'Rejected' },
  'cancelled': { color: 'text-carbon-gray-50', bg: 'bg-carbon-gray-10', label: 'Cancelled' },
};

export const PRIORITY_CONFIG: Record<TaskPriority, { color: string; label: string }> = {
  'routine': { color: 'text-carbon-gray-50', label: 'Routine' },
  'urgent': { color: 'text-[#b45309]', label: 'Urgent' },
  'asap': { color: 'text-[#da1e28]', label: 'ASAP' },
  'stat': { color: 'text-[#da1e28] font-bold', label: 'STAT' },
};
