// Core mock data: contracts, HCC suspects, care gaps, alerts, cost data, trends
import type {
  Contract, HCCSuspect, CareGap, UtilizationAlert, CostEnvelope,
} from './mockData.types';

// ── CONTRACTS ──────────────────────────────────────────────
export const mockContracts: Contract[] = [
  {
    id: 'contract-001',
    name: 'Medicare MSSP Track 3',
    payer: 'CMS / Medicare',
    programType: 'MSSP ACO',
    contractPeriod: 'Jan 2025 – Dec 2025',
    attributedLives: 4872,
    pmpmTarget: 890.00,
    pmpmActual: 847.32,
    gapClosureRate: 0.743,
    gapClosureTarget: 0.80,
    rafCaptureRate: 0.812,
    starsRating: 4.0,
    activeAlerts: 38,
    openHCCSuspects: 214,
    hccRevenueAtRisk: 1284000,
    performanceStatus: 'At Risk',
    expiresInDays: 260,
    lastUpdated: '2026-04-15T08:00:00Z',
  },
  {
    id: 'contract-002',
    name: 'ACO REACH Enhanced Track',
    payer: 'CMS / CMMI',
    programType: 'ACO REACH',
    contractPeriod: 'Jan 2025 – Dec 2025',
    attributedLives: 2341,
    pmpmTarget: 1120.00,
    pmpmActual: 1089.50,
    gapClosureRate: 0.821,
    gapClosureTarget: 0.78,
    rafCaptureRate: 0.891,
    starsRating: 4.5,
    activeAlerts: 12,
    openHCCSuspects: 87,
    hccRevenueAtRisk: 522000,
    performanceStatus: 'On Track',
    expiresInDays: 260,
    lastUpdated: '2026-04-15T07:45:00Z',
  },
  {
    id: 'contract-003',
    name: 'Anthem BlueCross Commercial VBC',
    payer: 'Anthem BlueCross',
    programType: 'Commercial VBC',
    contractPeriod: 'Jul 2025 – Jun 2026',
    attributedLives: 1890,
    pmpmTarget: 680.00,
    pmpmActual: 734.20,
    gapClosureRate: 0.612,
    gapClosureTarget: 0.75,
    rafCaptureRate: 0.703,
    starsRating: 3.5,
    activeAlerts: 61,
    openHCCSuspects: 156,
    hccRevenueAtRisk: 780000,
    performanceStatus: 'Below Target',
    expiresInDays: 447,
    lastUpdated: '2026-04-14T16:30:00Z',
  },
  {
    id: 'contract-004',
    name: 'UnitedHealth Community Plan',
    payer: 'UnitedHealthcare',
    programType: 'Medicaid MCO',
    contractPeriod: 'Apr 2025 – Mar 2026',
    attributedLives: 3210,
    pmpmTarget: 540.00,
    pmpmActual: 518.90,
    gapClosureRate: 0.689,
    gapClosureTarget: 0.70,
    rafCaptureRate: 0.762,
    starsRating: 3.0,
    activeAlerts: 29,
    openHCCSuspects: 132,
    hccRevenueAtRisk: 396000,
    performanceStatus: 'On Track',
    expiresInDays: 365,
    lastUpdated: '2026-04-15T09:15:00Z',
  },
  {
    id: 'contract-005',
    name: 'Humana Medicare Advantage',
    payer: 'Humana',
    programType: 'MSSP ACO',
    contractPeriod: 'Jan 2025 – Dec 2025',
    attributedLives: 1654,
    pmpmTarget: 980.00,
    pmpmActual: 1042.10,
    gapClosureRate: 0.541,
    gapClosureTarget: 0.72,
    rafCaptureRate: 0.634,
    starsRating: 2.5,
    activeAlerts: 74,
    openHCCSuspects: 203,
    hccRevenueAtRisk: 1624000,
    performanceStatus: 'Below Target',
    expiresInDays: 14,
    lastUpdated: '2026-04-15T06:00:00Z',
  },
  {
    id: 'contract-006',
    name: 'Cigna Total Care Partnership',
    payer: 'Cigna',
    programType: 'Commercial VBC',
    contractPeriod: 'Jan 2026 – Dec 2026',
    attributedLives: 987,
    pmpmTarget: 720.00,
    pmpmActual: 698.40,
    gapClosureRate: 0.774,
    gapClosureTarget: 0.75,
    rafCaptureRate: 0.843,
    starsRating: 4.0,
    activeAlerts: 8,
    openHCCSuspects: 44,
    hccRevenueAtRisk: 176000,
    performanceStatus: 'On Track',
    expiresInDays: 260,
    lastUpdated: '2026-04-15T10:00:00Z',
  },
];

// ── HCC SUSPECTS ──────────────────────────────────────────
export const mockHCCSuspects: HCCSuspect[] = [
  { id: 'hcc-001', patientId: 'patient-001', hccCode: 'HCC 85', hccDescription: 'Congestive Heart Failure', icdCode: 'I50.32', icdDescription: 'Chronic diastolic (congestive) heart failure', estimatedRafDelta: 0.331, estimatedRevenueDelta: 7200, status: 'Clinician Review', evidenceSources: ['Echocardiogram 03/12/2026', 'BNP 842 pg/mL 03/28/2026', 'ED visit 02/14/2026'], lastEncounterDate: '2026-04-14', suspectConfidence: 0.91, assignedPhysician: 'Dr. James Chen', submissionDeadline: '2026-06-30', dataSource: 'EMR', freshnessDate: '2026-04-10' },
  { id: 'hcc-002', patientId: 'patient-001', hccCode: 'HCC 18', hccDescription: 'Diabetes with Chronic Complications', icdCode: 'E11.65', icdDescription: 'Type 2 diabetes mellitus with hyperglycemia', estimatedRafDelta: 0.302, estimatedRevenueDelta: 6600, status: 'Evidence Reviewed', evidenceSources: ['HbA1c 9.2% 04/10/2026', 'Labcorp outreach note 04/12/2026'], lastEncounterDate: '2026-04-14', suspectConfidence: 0.87, assignedPhysician: 'Dr. James Chen', submissionDeadline: '2026-06-30', dataSource: 'Claims', freshnessDate: '2026-04-08' },
  { id: 'hcc-003', patientId: 'patient-001', hccCode: 'HCC 111', hccDescription: 'Chronic Obstructive Pulmonary Disease', icdCode: 'J44.1', icdDescription: 'COPD with acute exacerbation', estimatedRafDelta: 0.346, estimatedRevenueDelta: 7560, status: 'Surfaced', evidenceSources: ['Medication reconciliation 04/14/2026', 'Claims overlap Warfarin/Coumadin 04/11/2026'], lastEncounterDate: '2026-04-14', suspectConfidence: 0.78, assignedPhysician: 'Dr. James Chen', submissionDeadline: '2026-06-30', dataSource: 'HIE', freshnessDate: '2026-04-05' },
  { id: 'hcc-004', patientId: 'patient-002', hccCode: 'HCC 85', hccDescription: 'Congestive Heart Failure', icdCode: 'I50.22', icdDescription: 'Chronic systolic (congestive) heart failure', estimatedRafDelta: 0.331, estimatedRevenueDelta: 7200, status: 'Documented', evidenceSources: ['Cardiology consult 04/01/2026', 'Echo 03/22/2026'], lastEncounterDate: '2026-04-01', suspectConfidence: 0.96, assignedPhysician: 'Dr. Sarah Nakamura', submissionDeadline: '2026-06-30', dataSource: 'EMR', freshnessDate: '2026-04-12' },
  { id: 'hcc-005', patientId: 'patient-001', hccCode: 'HCC 22', hccDescription: 'Morbid Obesity', icdCode: 'E66.01', icdDescription: 'Morbid (severe) obesity due to excess calories', estimatedRafDelta: 0.271, estimatedRevenueDelta: 5920, status: 'Surfaced', evidenceSources: ['Transportation screening 04/14/2026', 'Community outreach note 04/13/2026'], lastEncounterDate: '2026-04-14', suspectConfidence: 0.94, assignedPhysician: 'Dr. James Chen', submissionDeadline: '2026-06-30', dataSource: 'EMR', freshnessDate: '2026-04-10' },
];

// ── CARE GAPS ──────────────────────────────────────────────
export const mockCareGaps: CareGap[] = [
  { id: 'gap-001', patientId: 'patient-001', measureId: 'HEDIS-CDC-HbA1c', measureName: 'HbA1c Poor Control (>9%)', program: 'HEDIS', status: 'Open', dueDate: '2026-09-30', daysOpen: 105, lastActionDate: '2026-01-10', assignedTo: 'Care Manager', notes: 'Labcorp home draw requested. Maria needs transportation backup if home draw fails.', closureRequirement: 'HbA1c result < 9.0% documented in measurement year via Labcorp result feed' },
  { id: 'gap-002', patientId: 'patient-001', measureId: 'STARS-C01', measureName: 'Annual Wellness Visit', program: 'STARS', status: 'In Progress', dueDate: '2026-12-31', daysOpen: 45, lastActionDate: '2026-03-01', assignedTo: 'Dr. James Whitfield', notes: 'Annual visit bundled into Dr. Chen follow-up and PCP coordination workflow.', closureRequirement: 'AWV or comprehensive preventive visit billed with G0438/G0439' },
  { id: 'gap-003', patientId: 'patient-001', measureId: 'HEDIS-EED', measureName: 'Eye Exam for Diabetics', program: 'HEDIS', status: 'Open', dueDate: '2026-09-30', daysOpen: 180, lastActionDate: '2025-10-15', assignedTo: 'Care Manager', notes: 'Dr. Chen requested diabetic retinal follow-up after medication reconciliation.', closureRequirement: 'Retinal exam or dilated eye exam by qualified provider' },
  { id: 'gap-004', patientId: 'patient-001', measureId: 'MIPS-PREV-12', measureName: 'Colorectal Cancer Screening', program: 'MIPS', status: 'Open', dueDate: '2026-12-31', daysOpen: 62, lastActionDate: '2026-02-14', assignedTo: 'Dr. James Whitfield', notes: 'Deferred while acute diabetes and medication safety issues are prioritized.', closureRequirement: 'Colonoscopy, FIT, or stool DNA test documented' },
  { id: 'gap-005', patientId: 'patient-001', measureId: 'STARS-D12', measureName: 'Medication Adherence — Diabetes', program: 'STARS', status: 'Open', dueDate: '2026-12-31', daysOpen: 90, lastActionDate: '2026-01-25', assignedTo: 'Pharmacy', notes: 'Medication adherence impacted by duplicate anticoagulant confusion and transportation barriers.', closureRequirement: 'PDC ≥ 0.80 for diabetes medications in measurement year after medication reconciliation' },
  { id: 'gap-006', patientId: 'patient-001', measureId: 'HEDIS-CBP', measureName: 'Controlling Blood Pressure', program: 'HEDIS', status: 'Closed', dueDate: '2026-09-30', daysOpen: 0, lastActionDate: '2026-04-08', assignedTo: 'Dr. James Whitfield', notes: 'BP 128/76 documented at 04/08 visit. Measure closed.', closureRequirement: 'BP < 140/90 mmHg documented at last measurement' },
];

// ── UTILIZATION ALERTS ──────────────────────────────────────
export const mockAlerts: UtilizationAlert[] = [
  { id: 'alert-001', patientId: 'patient-001', tier: 'Critical', type: 'Predicted ER Risk', description: 'Model predicts 81% probability of avoidable ER visit within 30 days based on uncontrolled diabetes, duplicate anticoagulants, and transportation barriers.', riskScore: 0.84, estimatedCost: 3800, createdDate: '2026-04-13', source: 'LPR', status: 'Escalated', freshnessDate: '2026-04-15' },
  { id: 'alert-002', patientId: 'patient-001', tier: 'Important', type: 'Poly-Pharmacy', description: 'Duplicate anticoagulant therapy identified: Warfarin + Coumadin active concurrently. Dr. Chen review required before next fill.', riskScore: 0.62, estimatedCost: 1200, createdDate: '2026-04-10', source: 'Claims', status: 'Active', freshnessDate: '2026-04-10' },
  { id: 'alert-003', patientId: 'patient-001', tier: 'Important', type: 'High-Cost Imaging', description: 'Cardiac MRI ordered ($4,200). Alternative: Stress Echo ($890) may be clinically equivalent per cardiology guidelines.', riskScore: 0.0, estimatedCost: 4200, createdDate: '2026-04-14', source: 'CDS Hooks', status: 'Active', freshnessDate: '2026-04-14' },
  { id: 'alert-004', patientId: 'patient-002', tier: 'Critical', type: 'Avoidable Admission', description: 'Patient admitted 04/12 for CHF exacerbation. Prior authorization for home health not obtained. Readmission risk elevated.', riskScore: 0.71, estimatedCost: 18400, createdDate: '2026-04-12', source: 'LPR', status: 'Intervention Assigned', freshnessDate: '2026-04-15' },
];

// ── COST ENVELOPES ──────────────────────────────────────────
export const mockCostEnvelopes: CostEnvelope[] = [
  { patientId: 'patient-001', contractId: 'contract-001', period: 'YTD 2026', inpatient: 14200, er: 3800, specialty: 8400, pharmacy: 4200, postAcute: 2100, primaryCare: 1680, total: 34380, targetTotal: 10680, pmpm: 2840, pmpmTarget: 890 },
];

// ── PMPM TREND DATA ──────────────────────────────────────────
export const mockPmpmTrend = [
  { month: 'Apr 25', actual: 862, target: 890 },
  { month: 'May 25', actual: 878, target: 890 },
  { month: 'Jun 25', actual: 901, target: 890 },
  { month: 'Jul 25', actual: 923, target: 890 },
  { month: 'Aug 25', actual: 934, target: 890 },
  { month: 'Sep 25', actual: 912, target: 890 },
  { month: 'Oct 25', actual: 887, target: 890 },
  { month: 'Nov 25', actual: 869, target: 890 },
  { month: 'Dec 25', actual: 842, target: 890 },
  { month: 'Jan 26', actual: 831, target: 890 },
  { month: 'Feb 26', actual: 844, target: 890 },
  { month: 'Mar 26', actual: 847, target: 890 },
];

export const mockCostByCategory = [
  { month: 'Oct 25', inpatient: 3800, er: 980, specialty: 2100, pharmacy: 1040, postAcute: 520 },
  { month: 'Nov 25', inpatient: 3200, er: 1120, specialty: 1980, pharmacy: 1060, postAcute: 480 },
  { month: 'Dec 25', inpatient: 2800, er: 840, specialty: 2240, pharmacy: 1080, postAcute: 560 },
  { month: 'Jan 26', inpatient: 2600, er: 760, specialty: 2080, pharmacy: 1020, postAcute: 440 },
  { month: 'Feb 26', inpatient: 3100, er: 920, specialty: 2160, pharmacy: 1100, postAcute: 500 },
  { month: 'Mar 26', inpatient: 3400, er: 1040, specialty: 2280, pharmacy: 1120, postAcute: 580 },
];

export const mockGapClosureTrend = [
  { month: 'Apr 25', rate: 0.58 }, { month: 'May 25', rate: 0.61 }, { month: 'Jun 25', rate: 0.63 },
  { month: 'Jul 25', rate: 0.66 }, { month: 'Aug 25', rate: 0.68 }, { month: 'Sep 25', rate: 0.70 },
  { month: 'Oct 25', rate: 0.71 }, { month: 'Nov 25', rate: 0.69 }, { month: 'Dec 25', rate: 0.72 },
  { month: 'Jan 26', rate: 0.73 }, { month: 'Feb 26', rate: 0.74 }, { month: 'Mar 26', rate: 0.743 },
];
