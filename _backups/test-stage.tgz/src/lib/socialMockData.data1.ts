// ─── socialMockData.data1.ts ──────────────────────────────────────────────────
// Patients, PRAPARE domains, screening history, findhelp results,
// program eligibility, and benefit enrollments.

import type { SocialPatient, ScreeningRecord, FindhelpScreeningResult, Program, Enrollment } from './socialMockData.types';

// ─── Canonical Patients ───────────────────────────────────────────────────────

export const SOCIAL_PATIENTS: SocialPatient[] = [
  { id: 'MARIA_SD_001', patientId: 'MARIA_SD_001', name: 'Maria Redhawk', dob: '1992-03-22', mrn: 'MRN-SD-001', pcp: 'Bennett County Health PCP', age: 34, gender: 'F', riskLevel: 'Medium', unmetNeeds: 5, needs: ['childcare', 'food', 'financial', 'transport', 'housing'], lastScreened: '2026-04-15', address: '412 Main St, Martin, SD 57551', phone: '(605) 555-0122' },
  { id: 'PAT-0042', patientId: 'PAT-0042', name: 'Dorothy Simmons', dob: '1951-03-14', mrn: 'MRN-0042', pcp: 'Dr. Whitfield', age: 75, gender: 'F', riskLevel: 'High', unmetNeeds: 4, needs: ['housing', 'food', 'social_isolation', 'financial'], lastScreened: '2026-01-08', address: '3301 Vine Ave, Martin, SD 57551', phone: '(605) 555-0142' },
  { id: 'PAT-0087', patientId: 'PAT-0087', name: 'James Wilson', dob: '1948-07-22', mrn: 'MRN-0087', pcp: 'Dr. Patel', age: 77, gender: 'M', riskLevel: 'High', unmetNeeds: 3, needs: ['financial', 'transport', 'social_isolation'], lastScreened: '2025-11-14', address: '1842 Oak Street, Winner, SD 57580', phone: '(605) 555-0187' },
  { id: 'PAT-0103', patientId: 'PAT-0103', name: 'Robert Chen', dob: '1955-11-08', mrn: 'MRN-0103', pcp: 'Dr. Whitfield', age: 70, gender: 'M', riskLevel: 'Medium', unmetNeeds: 2, needs: ['food', 'employment'], lastScreened: '2026-03-15', address: '512 Prospect Ave, Pierre, SD 57501', phone: '(605) 555-0113' },
  { id: 'PAT-0156', patientId: 'PAT-0156', name: 'Lisa Thompson', dob: '1943-05-30', mrn: 'MRN-0156', pcp: 'Dr. Kim', age: 82, gender: 'F', riskLevel: 'High', unmetNeeds: 3, needs: ['housing', 'food', 'transport'], lastScreened: '2026-02-20', address: '789 Grand Blvd, Gregory, SD 57533', phone: '(605) 555-0156' },
  { id: 'PAT-0201', patientId: 'PAT-0201', name: 'James Okafor', dob: '1960-09-17', mrn: 'MRN-0201', pcp: 'Dr. Patel', age: 65, gender: 'M', riskLevel: 'High', unmetNeeds: 2, needs: ['financial', 'housing'], lastScreened: null, address: '4400 E Hwy 18, Oglala, SD 57764', phone: '(605) 555-0201' },
];

// ─── PRAPARE / AHC-HRSN Screening Domains ────────────────────────────────────

export const PRAPARE_DOMAINS = [
  { id: 'housing', label: 'Housing Instability', code: '71802-3', question: 'What is your housing situation today?', options: ['I have housing', 'I do not have housing', 'I am worried about losing housing'], riskOption: 2 },
  { id: 'food', label: 'Food Insecurity', code: '88122-7', question: 'Within the past 12 months, did you worry that food would run out?', options: ['Never true', 'Sometimes true', 'Often true'], riskOption: 2 },
  { id: 'transport', label: 'Transportation', code: '93030-5', question: 'In the past 12 months, has lack of transportation kept you from appointments?', options: ['No', 'Yes, some', 'Yes, often'], riskOption: 1 },
  { id: 'social_isolation', label: 'Social Isolation', code: '93029-7', question: 'How often do you feel lonely or isolated?', options: ['Never', 'Rarely', 'Sometimes', 'Often', 'Always'], riskOption: 3 },
  { id: 'financial', label: 'Financial Strain', code: '93031-3', question: 'How hard is it to pay for basics like food, housing, medical care?', options: ['Not hard at all', 'A little hard', 'Somewhat hard', 'Very hard', 'Extremely hard'], riskOption: 3 },
  { id: 'employment', label: 'Employment', code: '67875-5', question: 'What is your current work situation?', options: ['Full-time', 'Part-time', 'Unemployed — looking', 'Unemployed — not looking', 'Retired/Disabled'], riskOption: 2 },
  { id: 'education', label: 'Education', code: '82589-3', question: 'What is the highest level of school you have finished?', options: ['Less than high school', 'High school diploma/GED', 'Some college', 'College degree or more'], riskOption: 0 },
  { id: 'safety', label: 'Personal Safety', code: '93038-8', question: 'Do you feel physically and emotionally safe where you live?', options: ['Yes', 'No'], riskOption: 1 },
];

export const DOMAIN_COLORS: Record<string, string> = {
  housing: '#da1e28', food: '#b45309', transport: '#0043ce',
  social_isolation: '#6929c4', financial: '#da1e28',
  employment: '#007d79', education: '#198038', safety: '#da1e28',
};

// ─── Screening History ────────────────────────────────────────────────────────

export const SCREENING_HISTORY: ScreeningRecord[] = [
  { id: 'sh-000', patientId: 'MARIA_SD_001', date: '2026-05-01', instrument: 'PRAPARE 13-Domain', screener: 'Angela Torres (CHW)', unmetNeeds: 7, tasksCreated: 5, status: 'Completed' },
  { id: 'sh-001', patientId: 'PAT-0042', date: '2026-01-08', instrument: 'findhelp 13-Domain', screener: 'Sarah Johnson (CM)', unmetNeeds: 4, tasksCreated: 4, status: 'Completed' },
  { id: 'sh-002', patientId: 'PAT-0087', date: '2025-04-10', instrument: 'findhelp 13-Domain', screener: 'Sarah Johnson (CM)', unmetNeeds: 3, tasksCreated: 3, status: 'Completed' },
  { id: 'sh-003', patientId: 'PAT-0103', date: '2026-03-15', instrument: 'Unite Us Screening', screener: 'Sarah Johnson (CM)', unmetNeeds: 2, tasksCreated: 2, status: 'Completed' },
  { id: 'sh-004', patientId: 'PAT-0156', date: '2026-02-20', instrument: 'findhelp 13-Domain', screener: 'Robert Chen (CHW)', unmetNeeds: 3, tasksCreated: 3, status: 'Completed' },
  { id: 'sh-005', patientId: 'PAT-0201', date: '2026-05-12', instrument: 'findhelp 13-Domain', screener: 'Sarah Johnson (CM)', unmetNeeds: 2, tasksCreated: 2, status: 'Completed' },
];

// ─── findhelp Screening Results ───────────────────────────────────────────────

export const FINDHELP_RESULTS: FindhelpScreeningResult[] = [
  {
    patientId: 'MARIA_SD_001', screeningDate: '2026-04-15', instrument: 'findhelp', provider: 'findhelp South Dakota',
    domains: [
      { id: 'food', label: 'Food', unmetNeed: true, responses: { f1: 2, f2: 2 }, recommendedCBOs: ['Bennett County WIC Office', 'SD DSS Bennett County — SNAP'] },
      { id: 'financial', label: 'Financial', unmetNeed: true, responses: { fi1: 3, fi2: 1 }, recommendedCBOs: ['SD DSS Bennett County', 'Bennett County Action CBO'] },
      { id: 'housing', label: 'Housing', unmetNeed: true, responses: { h1: 2, h2: 0 }, recommendedCBOs: ['SD Housing Development Authority', 'Bennett County Action CBO'] },
      { id: 'transportation', label: 'Transportation', unmetNeed: true, responses: { t1: 2 }, recommendedCBOs: ['Medicaid NEMT — Bennett County', 'Bennett County Action CBO'] },
      { id: 'support', label: 'Support', unmetNeed: true, responses: { su1: 2, su2: 2 }, recommendedCBOs: ['Bennett County Health Services — Postpartum Support Group'] },
      { id: 'mental_health', label: 'Mental Health', unmetNeed: true, responses: { mh1: 2, mh2: 2, mh3: 3 }, recommendedCBOs: ['Avera Behavioral Health — Winner', 'Bennett County Health CCBHC'] },
    ],
    totalUnmetNeeds: 5, tasksCreated: ['TASK-F-MARIA', 'TASK-FI-MARIA', 'TASK-H-MARIA', 'TASK-T-MARIA', 'TASK-SU-MARIA'], savedToRecord: true,
  },
  {
    patientId: 'PAT-0042', screeningDate: '2026-01-08', instrument: 'findhelp', provider: 'findhelp South Dakota',
    domains: [
      { id: 'housing', label: 'Housing', unmetNeed: true, responses: { h1: 2, h2: 0 }, recommendedCBOs: ['SD Housing Development Authority', 'Bennett County Action CBO'] },
      { id: 'food', label: 'Food', unmetNeed: true, responses: { f1: 2, f2: 1 }, recommendedCBOs: ['Oglala Sioux Tribe Community Services', 'SD DSS Bennett County — SNAP'] },
      { id: 'financial', label: 'Financial', unmetNeed: true, responses: { fi1: 3, fi2: 1 }, recommendedCBOs: ['Bennett County Action CBO', 'SD DSS Bennett County'] },
      { id: 'support', label: 'Support', unmetNeed: true, responses: { su1: 3, su2: 3 }, recommendedCBOs: ['SD Area Agency on Aging', 'Bennett County Health Services'] },
      { id: 'transportation', label: 'Transportation', unmetNeed: false, responses: { t1: 0 }, recommendedCBOs: [] },
      { id: 'mental_health', label: 'Mental Health', unmetNeed: false, responses: { mh1: 0, mh2: 0, mh3: 1 }, recommendedCBOs: [] },
    ],
    totalUnmetNeeds: 4, tasksCreated: ['TASK-H-0042', 'TASK-F-0042', 'TASK-FI-0042', 'TASK-SU-0042'], savedToRecord: true,
  },
  {
    patientId: 'PAT-0087', screeningDate: '2025-11-14', instrument: 'findhelp', provider: 'findhelp South Dakota',
    domains: [
      { id: 'financial', label: 'Financial', unmetNeed: true, responses: { fi1: 3, fi2: 1 }, recommendedCBOs: ['Bennett County Action CBO', 'SD DSS Bennett County'] },
      { id: 'transportation', label: 'Transportation', unmetNeed: true, responses: { t1: 2 }, recommendedCBOs: ['Medicaid NEMT — Bennett County', 'SD Medicaid Transport'] },
      { id: 'support', label: 'Support', unmetNeed: true, responses: { su1: 2, su2: 3 }, recommendedCBOs: ['SD Area Agency on Aging'] },
    ],
    totalUnmetNeeds: 3, tasksCreated: ['TASK-FI-0087', 'TASK-T-0087', 'TASK-SU-0087'], savedToRecord: true,
  },
];

// ─── Program Eligibility ──────────────────────────────────────────────────────

export const PROGRAMS_BY_PATIENT: Record<string, Program[]> = {
  'MARIA_SD_001': [
    { id: 'pm1', name: 'WIC — Women, Infants & Children', domain: 'Food Security', fundingSource: 'USDA', status: 'eligible', actionRequired: 'Eligible — not yet enrolled. Monthly value: $320/mo' },
    { id: 'pm2', name: 'SD Childcare Assistance Program (CCAP)', domain: 'Childcare', fundingSource: 'SD DSS', status: 'eligible', actionRequired: 'Eligible — not yet enrolled. Monthly value: $487/mo' },
    { id: 'pm3', name: 'SNAP Food Assistance', domain: 'Food Security', fundingSource: 'USDA', status: 'expired', expiryDate: '2026-01-31', actionRequired: 'Renewal overdue T+47d — recertify immediately' },
    { id: 'pm4', name: 'TANF — Temporary Assistance for Needy Families', domain: 'Financial', fundingSource: 'SD DSS', status: 'eligible', actionRequired: 'Eligible — not yet enrolled' },
    { id: 'pm5', name: 'LIHEAP — Low Income Home Energy Assistance', domain: 'Utilities', fundingSource: 'Federal LIHEAP', status: 'eligible', actionRequired: 'Income verification required' },
    { id: 'pm6', name: 'SD Housing Development Authority — Rental Assistance', domain: 'Housing', fundingSource: 'SDHDA', status: 'pending', actionRequired: 'Waitlist position 47 — est. 18 months' },
    { id: 'pm7', name: 'Medicaid Non-Emergency Transportation', domain: 'Transportation', fundingSource: 'SD Medicaid', status: 'enrolled', enrolledDate: '2026-01-15' },
    { id: 'pm8', name: 'Postpartum Support Group — Bennett County', domain: 'Behavioral Health', fundingSource: 'CCBHC', status: 'eligible', actionRequired: 'Referred — not yet enrolled' },
    { id: 'pm9', name: 'CHW Outreach — RHTP Program', domain: 'Care Coordination', fundingSource: 'Medicaid 1115 Waiver', status: 'enrolled', enrolledDate: '2026-02-01' },
  ],
  'PAT-0042': [
    { id: 'p1', name: 'Section 8 Housing Voucher', domain: 'Housing', fundingSource: 'HUD', status: 'pending', actionRequired: 'Application submitted 2026-02-10 — awaiting approval' },
    { id: 'p2', name: 'SNAP Food Assistance', domain: 'Food Security', fundingSource: 'USDA', status: 'expired', expiryDate: '2025-12-31', actionRequired: 'Renewal overdue — recertify immediately' },
    { id: 'p3', name: 'Senior Companion Program', domain: 'Social Isolation', fundingSource: 'AmeriCorps', status: 'eligible', actionRequired: 'Referral to Area Agency on Aging' },
    { id: 'p4', name: 'CCBHC Behavioral Health', domain: 'Behavioral Health', fundingSource: 'BH Block Grant', status: 'enrolled', enrolledDate: '2025-06-01' },
    { id: 'p5', name: 'SSI Supplemental Income', domain: 'Financial', fundingSource: 'SSA', status: 'enrolled', enrolledDate: '2020-01-01' },
    { id: 'p6', name: 'Community Health Worker Outreach', domain: 'Care Coordination', fundingSource: 'Medicaid 1115 Waiver', status: 'enrolled', enrolledDate: '2026-01-15' },
    { id: 'p7', name: 'Meals on Wheels', domain: 'Food Security', fundingSource: 'Older Americans Act', status: 'pending', actionRequired: 'Waitlist — position 4 of 12' },
  ],
  'PAT-0087': [
    { id: 'p8', name: 'Medicaid BH Services', domain: 'Behavioral Health', fundingSource: 'Medicaid', status: 'enrolled', enrolledDate: '2025-03-01' },
    { id: 'p9', name: 'Medicaid Non-Emergency Transport', domain: 'Transportation', fundingSource: 'Medicaid', status: 'enrolled', enrolledDate: '2026-01-01' },
    { id: 'p10', name: 'SSI Supplemental Income', domain: 'Financial', fundingSource: 'SSA', status: 'enrolled', enrolledDate: '2018-01-01' },
    { id: 'p11', name: 'Senior Companion Program', domain: 'Social Isolation', fundingSource: 'AmeriCorps', status: 'eligible', actionRequired: 'Referral to Area Agency on Aging' },
    { id: 'p12', name: 'SNAP Food Assistance', domain: 'Food Security', fundingSource: 'USDA', status: 'not-eligible' },
  ],
  'PAT-0103': [
    { id: 'p13', name: 'SNAP Food Assistance', domain: 'Food Security', fundingSource: 'USDA', status: 'enrolled', enrolledDate: '2025-09-01', expiryDate: '2026-08-31' },
    { id: 'p14', name: 'Workforce Development Program', domain: 'Employment', fundingSource: 'WIOA', status: 'eligible', actionRequired: 'Enroll via Workforce Development Center' },
    { id: 'p15', name: 'Utility Assistance (LIHEAP)', domain: 'Financial', fundingSource: 'Federal LIHEAP', status: 'eligible', actionRequired: 'Income verification required' },
    { id: 'p16', name: 'Community Health Worker Outreach', domain: 'Care Coordination', fundingSource: 'Medicaid 1115 Waiver', status: 'enrolled', enrolledDate: '2026-02-01' },
  ],
  'PAT-0156': [
    { id: 'p17', name: 'Emergency Housing Assistance', domain: 'Housing', fundingSource: 'HUD ESG', status: 'enrolled', enrolledDate: '2026-03-01', expiryDate: '2026-08-31' },
    { id: 'p18', name: 'SNAP Food Assistance', domain: 'Food Security', fundingSource: 'USDA', status: 'enrolled', enrolledDate: '2025-09-01', expiryDate: '2026-08-31' },
    { id: 'p19', name: 'Medicaid Non-Emergency Transport', domain: 'Transportation', fundingSource: 'Medicaid', status: 'eligible', actionRequired: 'Enroll via Medicaid portal' },
    { id: 'p20', name: 'Medicaid BH Services', domain: 'Behavioral Health', fundingSource: 'Medicaid', status: 'not-eligible' },
    { id: 'p21', name: 'Community Health Worker Outreach', domain: 'Care Coordination', fundingSource: 'Medicaid 1115 Waiver', status: 'enrolled', enrolledDate: '2026-01-15' },
  ],
  'PAT-0201': [
    { id: 'p22', name: 'CCBHC Behavioral Health', domain: 'Behavioral Health', fundingSource: 'BH Block Grant', status: 'eligible', actionRequired: 'Crisis stabilization enrollment pending' },
    { id: 'p23', name: 'Section 8 Housing Voucher', domain: 'Housing', fundingSource: 'HUD', status: 'eligible', actionRequired: 'Application not yet submitted' },
    { id: 'p24', name: 'SSI Supplemental Income', domain: 'Financial', fundingSource: 'SSA', status: 'pending', actionRequired: 'Disability determination in progress' },
    { id: 'p25', name: 'Medicaid BH Services', domain: 'Behavioral Health', fundingSource: 'Medicaid', status: 'enrolled', enrolledDate: '2025-10-01' },
  ],
};

// ─── Benefit Enrollments ──────────────────────────────────────────────────────

export const ENROLLMENTS: Enrollment[] = [
  { id: 'e-001', patientId: 'PAT-0042', patient: 'Dorothy Simmons', mrn: 'MRN-0042', program: 'SNAP Food Assistance', domain: 'Food Security', fundingSource: 'USDA', status: 'expired', startDate: '2025-01-01', endDate: '2025-12-31', renewalDeadline: '2025-11-30', daysToRenewal: -183, benefitValue: '$234/mo', caseWorker: 'DHS Case Worker', coverageGap: 'Expired Dec 31, 2025 — no food assistance for 5 months' },
  { id: 'e-002', patientId: 'PAT-0042', patient: 'Dorothy Simmons', mrn: 'MRN-0042', program: 'Section 8 Voucher', domain: 'Housing', fundingSource: 'HUD', status: 'pending', startDate: '—', endDate: '—', renewalDeadline: '—', daysToRenewal: 999, benefitValue: 'Est. $850/mo', caseWorker: 'Housing Authority', coverageGap: 'Application pending since Feb 2026 — no housing subsidy active' },
  { id: 'e-003', patientId: 'PAT-0042', patient: 'Dorothy Simmons', mrn: 'MRN-0042', program: 'CCBHC BH Services', domain: 'Behavioral Health', fundingSource: 'BH Block Grant', status: 'active', startDate: '2025-06-01', endDate: '2026-12-31', renewalDeadline: '2026-11-30', daysToRenewal: 181, benefitValue: 'Covered', caseWorker: 'BH Counselor' },
  { id: 'e-004', patientId: 'PAT-0042', patient: 'Dorothy Simmons', mrn: 'MRN-0042', program: 'Meals on Wheels', domain: 'Food Security', fundingSource: 'Older Americans Act', status: 'pending', startDate: '—', endDate: '—', renewalDeadline: '—', daysToRenewal: 999, benefitValue: 'Est. 5 meals/wk', caseWorker: 'Area Agency on Aging', coverageGap: 'Waitlist position 4 — food gap continues' },
  { id: 'e-005', patientId: 'PAT-0042', patient: 'Dorothy Simmons', mrn: 'MRN-0042', program: 'CHW Outreach', domain: 'Care Coordination', fundingSource: 'Medicaid 1115', status: 'active', startDate: '2026-01-15', endDate: '2026-12-31', renewalDeadline: '2026-11-30', daysToRenewal: 181, benefitValue: 'Included', caseWorker: 'Sarah Johnson (CM)' },
  { id: 'e-006', patientId: 'PAT-0087', patient: 'James Wilson', mrn: 'MRN-0087', program: 'Medicaid BH Services', domain: 'Behavioral Health', fundingSource: 'Medicaid', status: 'active', startDate: '2025-03-01', endDate: '2026-12-31', renewalDeadline: '2026-11-30', daysToRenewal: 181, benefitValue: 'Covered', caseWorker: 'BH Counselor' },
  { id: 'e-007', patientId: 'PAT-0087', patient: 'James Wilson', mrn: 'MRN-0087', program: 'Medicaid Transport', domain: 'Transportation', fundingSource: 'Medicaid', status: 'active', startDate: '2026-01-01', endDate: '2026-12-31', renewalDeadline: '2026-11-30', daysToRenewal: 181, benefitValue: 'Covered', caseWorker: 'Transport Coordinator' },
  { id: 'e-008', patientId: 'PAT-0087', patient: 'James Wilson', mrn: 'MRN-0087', program: 'SSI Supplemental Income', domain: 'Financial', fundingSource: 'SSA', status: 'active', startDate: '2018-01-01', endDate: '2026-12-31', renewalDeadline: '2026-11-30', daysToRenewal: 181, benefitValue: '$914/mo', caseWorker: 'SSA Case Worker' },
  { id: 'e-009', patientId: 'PAT-0103', patient: 'Robert Chen', mrn: 'MRN-0103', program: 'SNAP Food Assistance', domain: 'Food Security', fundingSource: 'USDA', status: 'active', startDate: '2025-09-01', endDate: '2026-08-31', renewalDeadline: '2026-07-31', daysToRenewal: 59, benefitValue: '$281/mo', caseWorker: 'DHS Case Worker' },
  { id: 'e-010', patientId: 'PAT-0103', patient: 'Robert Chen', mrn: 'MRN-0103', program: 'Workforce Development', domain: 'Employment', fundingSource: 'WIOA', status: 'pending', startDate: '—', endDate: '—', renewalDeadline: '—', daysToRenewal: 999, benefitValue: 'Job training', caseWorker: 'Workforce Dev Center', coverageGap: 'Enrollment not yet completed — employment gap continues' },
  { id: 'e-011', patientId: 'PAT-0156', patient: 'Lisa Thompson', mrn: 'MRN-0156', program: 'Emergency Housing', domain: 'Housing', fundingSource: 'HUD ESG', status: 'active', startDate: '2026-03-01', endDate: '2026-08-31', renewalDeadline: '2026-07-31', daysToRenewal: 59, benefitValue: '$1,200/mo', caseWorker: 'Housing CBO' },
  { id: 'e-012', patientId: 'PAT-0156', patient: 'Lisa Thompson', mrn: 'MRN-0156', program: 'SNAP Food Assistance', domain: 'Food Security', fundingSource: 'USDA', status: 'active', startDate: '2025-09-01', endDate: '2026-08-31', renewalDeadline: '2026-07-31', daysToRenewal: 59, benefitValue: '$281/mo', caseWorker: 'DHS Case Worker' },
  { id: 'e-013', patientId: 'PAT-0156', patient: 'Lisa Thompson', mrn: 'MRN-0156', program: 'CHW Outreach', domain: 'Care Coordination', fundingSource: 'Medicaid 1115', status: 'active', startDate: '2026-01-15', endDate: '2026-12-31', renewalDeadline: '2026-11-30', daysToRenewal: 181, benefitValue: 'Included', caseWorker: 'Sarah Johnson (CM)' },
  { id: 'e-014', patientId: 'PAT-0201', patient: 'James Okafor', mrn: 'MRN-0201', program: 'Medicaid BH Services', domain: 'Behavioral Health', fundingSource: 'Medicaid', status: 'active', startDate: '2025-10-01', endDate: '2026-12-31', renewalDeadline: '2026-11-30', daysToRenewal: 181, benefitValue: 'Covered', caseWorker: 'BH Counselor' },
  { id: 'e-015', patientId: 'PAT-0201', patient: 'James Okafor', mrn: 'MRN-0201', program: 'SSI Disability (Pending)', domain: 'Financial', fundingSource: 'SSA', status: 'pending', startDate: '—', endDate: '—', renewalDeadline: '—', daysToRenewal: 999, benefitValue: 'Est. $914/mo', caseWorker: 'SSA Case Worker', coverageGap: 'Disability determination pending — no income support active' },
];
