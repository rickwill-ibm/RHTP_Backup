// Whole Person Care Knowledge Graph — Maria Redhawk (PAT-0006)
// 52 nodes · 67 edges · 5 Cypher lens filters

export type NodeType =
  | 'Member' |'Insurance' |'CareGap' |'Episode' |'Medication' |'Provider' |'Dependent' |'SDOHNode' |'BHScreening' |'Consent' |'ChannelHistory' |'WorkScheduleConstraint' |'HouseholdUnit' |'CaregiverBurden' |'PharmacyTouchpoint' |'CriticalAccessHospital' |'ChildDevelopment' |'SeasonalBarrier' |'EligibilityStatus' |'BenefitStatus' |'WICStatus' |'BHProgramStatus' |'HousingStatus' |'LIHEAPStatus' |'ScreeningResult' | 'Agent';

export type LensType = 'all' | 'clinical' | 'behavioral' | 'social' | 'eligibility' | 'agents';

export interface GraphNode {
  id: string;
  nodeNum: number;
  type: NodeType;
  label: string;
  sublabel?: string;
  properties: Record<string, string | number | boolean | string[]>;
  lens: LensType[];
  // Visual
  color: string;
  radius: number;
  pulse?: boolean;
  locked?: boolean; // 42 CFR Part 2
  consentPending?: boolean;
  // Cross-domain (stays visible at 60% opacity in other lenses)
  crossDomain?: boolean;
  // Layout hint
  cluster?: 'maria' | 'elena' | 'sophia' | 'sdoh' | 'eligibility' | 'screening' | 'agents';
  // Temporal validity — days until expiry (for temporal arc)
  validUntilDays?: number;
  // Property richness — how many of the available properties are populated (0–1)
  propertyRichness?: number;
  // Total available properties (for richness indicator)
  totalProperties?: number;
}

export interface EdgeProperties {
  since?: string;
  confidence?: number; // 0–1
  strength?: number;   // 0–1
  touchpoints?: number;
  lastContact?: string;
  status?: string;
  adherence?: number;  // 0–1
  gapDays?: number;
  dose?: string;
  frequency?: string;
  lastAction?: string;
  actionType?: string;
  [key: string]: string | number | boolean | undefined;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  type: string;
  label: string;
  color: string;
  strokeWidth: number;
  dashed?: boolean;
  animated?: boolean;
  lens: LensType[];
  // Edge properties for tooltip panel
  edgeProps?: EdgeProperties;
}

// ── Color palette ──────────────────────────────────────────────────────────────
const C = {
  blue: '#0043ce',
  pink: '#9f1853',
  red: '#da1e28',
  emerald: '#198038',
  orange: '#b45309',
  amber: '#f59e0b',
  purple: '#6929c4',
  teal: '#007d79',
  sky: '#0284c7',
  lime: '#4d7c0f',
  slate: '#64748b',
  indigo: '#4338ca',
  gray: '#525252',
  agent: '#7c3aed',
};

// ── 52 Nodes ──────────────────────────────────────────────────────────────────
export const graphNodes: GraphNode[] = [
  // ── Core member (01)
  {
    id: 'n01', nodeNum: 1, type: 'Member', label: 'Maria Redhawk', sublabel: 'MARIA_SD_001',
    properties: { id: 'MARIA_SD_001', roles: ['PATIENT', 'PARENT', 'CAREGIVER', 'WORKER'], age: 34, location: 'Martin, SD 57551', confidence: '94%' },
    lens: ['all', 'clinical', 'behavioral', 'social', 'eligibility', 'agents'],
    color: C.blue, radius: 28, cluster: 'maria', propertyRichness: 0.94, totalProperties: 8,
  },
  // ── Insurance (02–03)
  {
    id: 'n02', nodeNum: 2, type: 'Insurance', label: 'SD Medicaid', sublabel: 'SD_MBR_MARIA_001',
    properties: { plan: 'SD Medicaid', status: 'ACTIVE', renewalDate: 'T+89d' },
    lens: ['all', 'eligibility'],
    color: C.lime, radius: 16, cluster: 'eligibility', validUntilDays: 89, propertyRichness: 0.6, totalProperties: 5,
  },
  {
    id: 'n03', nodeNum: 3, type: 'Insurance', label: 'SD Medicaid/CHIP', sublabel: 'Sophia',
    properties: { plan: 'SD Medicaid/CHIP', beneficiary: 'Sophia', status: 'ACTIVE' },
    lens: ['all', 'eligibility'],
    color: C.lime, radius: 14, cluster: 'sophia', propertyRichness: 0.5, totalProperties: 4,
  },
  // ── Care Gaps (04–06)
  {
    id: 'n04', nodeNum: 4, type: 'CareGap', label: 'HbA1c Lab', sublabel: '38 days open',
    properties: { id: 'CG_MARIA_001', type: 'HbA1c', daysOpen: 38, hedisWindow: 40, status: 'OPEN' },
    lens: ['all', 'clinical'],
    color: C.red, radius: 20, pulse: true, cluster: 'maria', validUntilDays: 40, propertyRichness: 0.88, totalProperties: 8,
  },
  {
    id: 'n05', nodeNum: 5, type: 'CareGap', label: 'Edinburgh PND', sublabel: '427 days open',
    properties: { id: 'CG_MARIA_002', type: 'EdinburghPND', daysOpen: 427, status: 'OPEN' },
    lens: ['all', 'clinical', 'behavioral'],
    color: C.red, radius: 20, pulse: true, cluster: 'maria', propertyRichness: 0.62, totalProperties: 6,
  },
  {
    id: 'n06', nodeNum: 6, type: 'CareGap', label: 'Well-Child 24mo', sublabel: '21 days overdue',
    properties: { id: 'CG_SOPHIA_001', type: 'WellChild_24mo', daysOpen: 21, status: 'OPEN' },
    lens: ['all', 'clinical'],
    color: C.red, radius: 16, pulse: true, cluster: 'sophia', validUntilDays: 7, propertyRichness: 0.55, totalProperties: 6,
  },
  // ── Episodes (07–10)
  {
    id: 'n07', nodeNum: 7, type: 'Episode', label: 'Pre-Diabetic', sublabel: 'A1C 6.2% ↑',
    properties: { type: 'PreDiabetic', a1c: '6.2%', status: 'ACTIVE', trend: 'RISING' },
    lens: ['all', 'clinical'],
    color: C.emerald, radius: 18, cluster: 'maria', propertyRichness: 0.75, totalProperties: 6,
  },
  {
    id: 'n08', nodeNum: 8, type: 'Episode', label: 'Postpartum Health', sublabel: 'UNMANAGED',
    properties: { type: 'PostpartumHealth', status: 'UNMANAGED', daysPostpartum: 427 },
    lens: ['all', 'clinical', 'behavioral'],
    color: C.emerald, radius: 18, cluster: 'maria', propertyRichness: 0.45, totalProperties: 7,
  },
  {
    id: 'n09', nodeNum: 9, type: 'Episode', label: 'Sophia Pediatric', sublabel: 'ACTIVE',
    properties: { type: 'SophiaPediatric', status: 'ACTIVE' },
    lens: ['all', 'clinical'],
    color: C.emerald, radius: 16, cluster: 'sophia', propertyRichness: 0.38, totalProperties: 5,
  },
  {
    id: 'n10', nodeNum: 10, type: 'Episode', label: 'Elena Cardiac/DM', sublabel: 'Caregiver managed',
    properties: { type: 'ElenaCardiacDM', status: 'CAREGIVER_MANAGED', a1c: '8.1%' },
    lens: ['all', 'clinical'],
    color: C.emerald, radius: 16, cluster: 'elena', propertyRichness: 0.55, totalProperties: 6,
  },
  // ── Medications (11–13)
  {
    id: 'n11', nodeNum: 11, type: 'Medication', label: 'Metformin 1000mg', sublabel: 'Elena · Maria picks up',
    properties: { name: 'Metformin', for: 'Elena', pickup: 'Maria', cadence: '2x/month' },
    lens: ['all', 'clinical'],
    color: C.purple, radius: 14, cluster: 'elena', propertyRichness: 0.7, totalProperties: 7,
  },
  {
    id: 'n12', nodeNum: 12, type: 'Medication', label: 'Lisinopril 10mg', sublabel: 'Elena · Maria picks up',
    properties: { name: 'Lisinopril', for: 'Elena', pickup: 'Maria', cadence: '2x/month' },
    lens: ['all', 'clinical'],
    color: C.purple, radius: 14, cluster: 'elena', propertyRichness: 0.65, totalProperties: 7,
  },
  {
    id: 'n13', nodeNum: 13, type: 'Medication', label: 'Amoxicillin 250mg', sublabel: 'Sophia · 3rd course',
    properties: { name: 'Amoxicillin', for: 'Sophia', recurrenceFlag: true, count: 3 },
    lens: ['all', 'clinical'],
    color: C.purple, radius: 14, pulse: true, cluster: 'sophia', propertyRichness: 0.8, totalProperties: 6,
  },
  // ── Provider (14)
  {
    id: 'n14', nodeNum: 14, type: 'Provider', label: 'Bennett County Health', sublabel: 'PCP · CAH',
    properties: { name: 'Bennett County Health PCP', type: 'CAH', distanceMiles: 0 },
    lens: ['all', 'clinical'],
    color: C.sky, radius: 18, cluster: 'maria', propertyRichness: 0.5, totalProperties: 8,
  },
  // ── Dependent (15)
  {
    id: 'n15', nodeNum: 15, type: 'Dependent', label: 'Sophia Redhawk', sublabel: 'Age 24 months',
    properties: { name: 'Sophia', ageMonths: 24, relationship: 'CHILD' },
    lens: ['all', 'clinical', 'social'],
    color: C.pink, radius: 18, cluster: 'sophia', propertyRichness: 0.6, totalProperties: 5,
  },
  // ── Elena member (16)
  {
    id: 'n16', nodeNum: 16, type: 'Member', label: 'Elena Redhawk', sublabel: 'Consent pending',
    properties: { id: 'ELENA_SD_001', relationship: 'MOTHER', status: 'DEPENDENT_ON_MARIA' },
    lens: ['all', 'clinical', 'social'],
    color: C.blue, radius: 20, consentPending: true, cluster: 'elena', propertyRichness: 0.42, totalProperties: 7,
  },
  // ── SDOH Nodes (17–24)
  {
    id: 'n17', nodeNum: 17, type: 'SDOHNode', label: 'Transportation', sublabel: 'HIGH · 47+ miles',
    properties: { type: 'TransportationBarrier', severity: 'HIGH', confirmedByScreening: true, distanceMiles: 47 },
    lens: ['all', 'social'],
    color: C.orange, radius: 20, crossDomain: true, cluster: 'sdoh', propertyRichness: 0.85, totalProperties: 6,
  },
  {
    id: 'n18', nodeNum: 18, type: 'SDOHNode', label: 'Childcare Barrier', sublabel: 'HIGH · blocks HbA1c',
    properties: { type: 'ChildcareBarrier', severity: 'HIGH', confirmedByScreening: true },
    lens: ['all', 'social'],
    color: C.orange, radius: 20, crossDomain: true, cluster: 'sdoh', propertyRichness: 0.72, totalProperties: 6,
  },
  {
    id: 'n19', nodeNum: 19, type: 'SDOHNode', label: 'Caregiver Burden', sublabel: 'MODERATE-HIGH',
    properties: { type: 'CaregiverBurdenRisk', severity: 'MODERATE-HIGH' },
    lens: ['all', 'social', 'behavioral'],
    color: C.orange, radius: 18, crossDomain: true, cluster: 'sdoh', propertyRichness: 0.5, totalProperties: 5,
  },
  {
    id: 'n20', nodeNum: 20, type: 'SDOHNode', label: 'Food Insecurity', sublabel: 'MODERATE',
    properties: { type: 'FoodInsecurity', severity: 'MODERATE' },
    lens: ['all', 'social'],
    color: C.orange, radius: 16, cluster: 'sdoh', propertyRichness: 0.45, totalProperties: 5,
  },
  {
    id: 'n21', nodeNum: 21, type: 'SDOHNode', label: 'Economic Fragility', sublabel: 'HIGH',
    properties: { type: 'EconomicFragility', severity: 'HIGH' },
    lens: ['all', 'social'],
    color: C.orange, radius: 16, cluster: 'sdoh', propertyRichness: 0.4, totalProperties: 5,
  },
  {
    id: 'n22', nodeNum: 22, type: 'SDOHNode', label: 'Digital Divide', sublabel: 'No broadband · SMS only',
    properties: { type: 'DigitalDivide', broadband: false, portalLiteracy: 'LOW' },
    lens: ['all', 'social'],
    color: C.orange, radius: 14, cluster: 'sdoh', propertyRichness: 0.55, totalProperties: 5,
  },
  {
    id: 'n23', nodeNum: 23, type: 'SDOHNode', label: 'Isolation Risk', sublabel: 'MODERATE',
    properties: { type: 'IsolationRisk', severity: 'MODERATE' },
    lens: ['all', 'social', 'behavioral'],
    color: C.orange, radius: 14, cluster: 'sdoh', propertyRichness: 0.35, totalProperties: 4,
  },
  {
    id: 'n24', nodeNum: 24, type: 'SDOHNode', label: 'Postpartum Depression Risk', sublabel: 'MODERATE · BH gated',
    properties: { type: 'PostpartumDepressionRisk', severity: 'MODERATE', consentGate: '42CFR_PART2' },
    lens: ['all', 'behavioral'],
    color: C.amber, radius: 16, locked: true, cluster: 'sdoh', propertyRichness: 0.65, totalProperties: 6,
  },
  // ── Consent (25–27)
  {
    id: 'n25', nodeNum: 25, type: 'Consent', label: 'Self Consent', sublabel: 'ACTIVE',
    properties: { scope: 'SELF_FULL', status: 'ACTIVE' },
    lens: ['all', 'behavioral'],
    color: C.lime, radius: 12, cluster: 'maria', propertyRichness: 0.9, totalProperties: 4,
  },
  {
    id: 'n26', nodeNum: 26, type: 'Consent', label: 'Parent Proxy', sublabel: 'Sophia · ACTIVE',
    properties: { scope: 'PARENT_PROXY', target: 'Sophia', status: 'ACTIVE' },
    lens: ['all'],
    color: C.lime, radius: 12, cluster: 'sophia', propertyRichness: 0.85, totalProperties: 4,
  },
  {
    id: 'n27', nodeNum: 27, type: 'Consent', label: 'Caregiver Scoped', sublabel: 'Elena · PENDING',
    properties: { scope: 'CAREGIVER_SCOPED', target: 'Elena', status: 'PENDING' },
    lens: ['all'],
    color: C.amber, radius: 12, pulse: true, consentPending: true, cluster: 'elena', propertyRichness: 0.75, totalProperties: 4,
  },
  // ── Channel + household (28–31)
  {
    id: 'n28', nodeNum: 28, type: 'ChannelHistory', label: 'SMS Only', sublabel: '3pm–7pm window',
    properties: { preferred: 'SMS', constraint: 'NO_PORTAL', outreachWindow: '3pm-7pm' },
    lens: ['all', 'social'],
    color: C.slate, radius: 12, cluster: 'maria', propertyRichness: 0.6, totalProperties: 5,
  },
  {
    id: 'n29', nodeNum: 29, type: 'WorkScheduleConstraint', label: 'Early Shift 6am–2pm', sublabel: 'Bennett County Schools',
    properties: { shift: 'EARLY_6AM_2PM', childcareBarrier: true, scheduleConflictRisk: 'HIGH' },
    lens: ['all', 'social'],
    color: C.slate, radius: 14, cluster: 'maria', propertyRichness: 0.55, totalProperties: 5,
  },
  {
    id: 'n30', nodeNum: 30, type: 'HouseholdUnit', label: 'Household Unit', sublabel: '3 members · 2 generations',
    properties: { size: 3, generations: 2, singleParent: true, economicFragility: 'HIGH' },
    lens: ['all', 'social'],
    color: C.slate, radius: 16, cluster: 'sdoh', propertyRichness: 0.7, totalProperties: 6,
  },
  {
    id: 'n31', nodeNum: 31, type: 'CaregiverBurden', label: 'Caregiver Burden', sublabel: 'Score 7.2 · 18hrs/wk',
    properties: { burdenScore: 7.2, hoursPerWeek: 18, impactOnOwnHealth: 'HIGH', supportFlag: 'NONE' },
    lens: ['all', 'behavioral', 'social'],
    color: C.red, radius: 18, crossDomain: true, cluster: 'sdoh', propertyRichness: 0.88, totalProperties: 7,
  },
  // ── SD Rural (32–38)
  {
    id: 'n32', nodeNum: 32, type: 'PharmacyTouchpoint', label: 'Martin Pharmacy', sublabel: '2x/month · family hub',
    properties: { name: 'Martin Pharmacy', frequency: '2x/month', crossFamilyFlag: true, intelligenceScore: 'HIGH' },
    lens: ['all', 'clinical', 'social'],
    color: C.teal, radius: 18, cluster: 'maria', propertyRichness: 0.78, totalProperties: 6,
  },
  {
    id: 'n33', nodeNum: 33, type: 'CriticalAccessHospital', label: 'Bennett County Health', sublabel: '0 miles · CAH',
    properties: { name: 'Bennett County Health', distanceMiles: 0, telemedCapable: 'PARTIAL' },
    lens: ['all', 'clinical'],
    color: C.sky, radius: 16, cluster: 'maria', propertyRichness: 0.5, totalProperties: 7,
  },
  {
    id: 'n34', nodeNum: 34, type: 'CriticalAccessHospital', label: 'Winner Regional', sublabel: '47 miles · ENT/IM',
    properties: { name: 'Winner Regional', distanceMiles: 47, specialties: 'InternalMedicine/ENT' },
    lens: ['all', 'clinical'],
    color: C.sky, radius: 14, cluster: 'sdoh', propertyRichness: 0.45, totalProperties: 6,
  },
  {
    id: 'n35', nodeNum: 35, type: 'ChildDevelopment', label: 'Child Development', sublabel: 'ENT referral flag',
    properties: { ageMonths: 24, milestoneDue: '2yr_WellChild', recurrencePattern: 'OtitisMedia_x3', referralFlag: 'ENT' },
    lens: ['all', 'clinical'],
    color: C.pink, radius: 16, cluster: 'sophia', propertyRichness: 0.82, totalProperties: 6,
  },
  {
    id: 'n36', nodeNum: 36, type: 'SeasonalBarrier', label: 'SD Winter Barrier', sublabel: 'Nov–Mar road closure risk',
    properties: { type: 'SD_WINTER', months: ['11', '12', '1', '2', '3'], impact: 'ROAD_CLOSURE_RISK' },
    lens: ['all', 'social'],
    color: C.slate, radius: 12, cluster: 'sdoh', propertyRichness: 0.55, totalProperties: 5,
  },
  {
    id: 'n37', nodeNum: 37, type: 'WorkScheduleConstraint', label: 'School District Job', sublabel: 'Food service · early shift',
    properties: { employer: 'Bennett County Schools', shift: 'EARLY', childcareBarrier: true },
    lens: ['all', 'social'],
    color: C.slate, radius: 12, cluster: 'maria', propertyRichness: 0.5, totalProperties: 5,
  },
  {
    id: 'n38', nodeNum: 38, type: 'BHScreening', label: 'Edinburgh PND', sublabel: 'Score 11 · Moderate',
    properties: { instrument: 'EdinburghPND', score: 11, risk: 'MODERATE', consentGate: '42CFR_PART2', visibleTo: ['BHCounselor', 'CareManager'] },
    lens: ['all', 'behavioral'],
    color: C.amber, radius: 18, locked: true, cluster: 'sdoh', propertyRichness: 0.9, totalProperties: 7,
  },
  // ── Eligibility + enrollment (39–46)
  {
    id: 'n39', nodeNum: 39, type: 'EligibilityStatus', label: 'SD Medicaid Active', sublabel: 'Renewal T+89d',
    properties: { program: 'SD Medicaid', renewalDate: 'T+89d', status: 'ACTIVE' },
    lens: ['all', 'eligibility'],
    color: C.lime, radius: 14, cluster: 'eligibility', validUntilDays: 89, propertyRichness: 0.65, totalProperties: 5,
  },
  {
    id: 'n40', nodeNum: 40, type: 'EligibilityStatus', label: 'CHIP Active', sublabel: 'Sophia · ACTIVE',
    properties: { program: 'CHIP', beneficiary: 'Sophia', status: 'ACTIVE' },
    lens: ['all', 'eligibility'],
    color: C.lime, radius: 14, cluster: 'eligibility', propertyRichness: 0.55, totalProperties: 5,
  },
  {
    id: 'n41', nodeNum: 41, type: 'BenefitStatus', label: 'Childcare Subsidy', sublabel: '$487/mo · Not enrolled',
    properties: { program: 'ChildcareSubsidy', status: 'ELIGIBLE_NOT_ENROLLED', value: '$487/month', wouldResolve: 'ChildcareBarrier' },
    lens: ['all', 'eligibility', 'social'],
    color: C.amber, radius: 16, pulse: true, cluster: 'eligibility', propertyRichness: 0.78, totalProperties: 6,
  },
  {
    id: 'n42', nodeNum: 42, type: 'BenefitStatus', label: 'TANF', sublabel: 'Eligible · Not enrolled',
    properties: { program: 'TANF', status: 'ELIGIBLE_NOT_ENROLLED' },
    lens: ['all', 'eligibility'],
    color: C.amber, radius: 14, cluster: 'eligibility', propertyRichness: 0.4, totalProperties: 5,
  },
  {
    id: 'n43', nodeNum: 43, type: 'WICStatus', label: 'WIC Lapsed', sublabel: '$320/mo · Eligible',
    properties: { beneficiary: 'Sophia+Maria', status: 'LAPSED_ELIGIBLE', value: '$320/month', nutritionalRisk: 'MODERATE' },
    lens: ['all', 'eligibility', 'social'],
    color: C.amber, radius: 16, pulse: true, cluster: 'eligibility', propertyRichness: 0.75, totalProperties: 6,
  },
  {
    id: 'n44', nodeNum: 44, type: 'BHProgramStatus', label: 'Postpartum Support', sublabel: 'Referred · Not enrolled',
    properties: { program: 'PostpartumSupportGroup', status: 'REFERRED_NOT_ENROLLED', daysOpen: 427 },
    lens: ['all', 'behavioral'],
    color: C.purple, radius: 14, cluster: 'sdoh', propertyRichness: 0.55, totalProperties: 5,
  },
  {
    id: 'n45', nodeNum: 45, type: 'HousingStatus', label: 'Housing Waitlist', sublabel: 'Position 47 · 18mo wait',
    properties: { type: 'RENTAL_ASSISTANCE_WAITLIST', waitlistPosition: 47, estimatedWait: '18months' },
    lens: ['all', 'eligibility', 'social'],
    color: C.slate, radius: 14, cluster: 'eligibility', propertyRichness: 0.6, totalProperties: 5,
  },
  {
    id: 'n46', nodeNum: 46, type: 'LIHEAPStatus', label: 'LIHEAP', sublabel: 'Eligible · Not applied',
    properties: { status: 'ELIGIBLE_NOT_APPLIED', applicationWindow: 'Oct-Dec', winterRisk: 'HIGH' },
    lens: ['all', 'eligibility'],
    color: C.amber, radius: 14, cluster: 'eligibility', propertyRichness: 0.6, totalProperties: 5,
  },
  // ── Screening results (47–52)
  {
    id: 'n47', nodeNum: 47, type: 'ScreeningResult', label: 'PRAPARE', sublabel: '7 domains unmet',
    properties: { instrument: 'PRAPARE', domainsUnmet: 7, date: '2026-05-01' },
    lens: ['all', 'social'],
    color: C.indigo, radius: 16, cluster: 'screening', propertyRichness: 0.8, totalProperties: 5,
  },
  {
    id: 'n48', nodeNum: 48, type: 'ScreeningResult', label: 'AHC-HRSN', sublabel: 'Risk: HIGH',
    properties: { instrument: 'AHC-HRSN', riskScore: 'HIGH', date: '2026-05-01' },
    lens: ['all', 'social'],
    color: C.indigo, radius: 14, cluster: 'screening', propertyRichness: 0.65, totalProperties: 5,
  },
  {
    id: 'n49', nodeNum: 49, type: 'ScreeningResult', label: 'Caregiver Burden SD', sublabel: 'Score: HIGH',
    properties: { instrument: 'CaregiverBurden_SD', score: 'HIGH' },
    lens: ['all', 'social', 'behavioral'],
    color: C.indigo, radius: 14, cluster: 'screening', propertyRichness: 0.5, totalProperties: 4,
  },
  {
    id: 'n50', nodeNum: 50, type: 'ScreeningResult', label: 'Childcare Barrier SD', sublabel: 'Score: HIGH',
    properties: { instrument: 'ChildcareBarrier_SD', score: 'HIGH' },
    lens: ['all', 'social'],
    color: C.indigo, radius: 14, cluster: 'screening', propertyRichness: 0.45, totalProperties: 4,
  },
  {
    id: 'n51', nodeNum: 51, type: 'BHScreening', label: 'Zarit Caregiver Burden', sublabel: 'Score 48 · Mod-High',
    properties: { instrument: 'Zarit_CaregiverBurden', score: 48, risk: 'MODERATE_HIGH', consentGate: '42CFR_PART2' },
    lens: ['all', 'behavioral'],
    color: C.amber, radius: 16, locked: true, cluster: 'screening', propertyRichness: 0.85, totalProperties: 6,
  },
  {
    id: 'n52', nodeNum: 52, type: 'ScreeningResult', label: 'ASQ-3 Sophia', sublabel: 'Language monitor flag',
    properties: { instrument: 'ASQ3_Sophia', ageMonths: 24, developmentalFlag: 'LANGUAGE_MONITOR' },
    lens: ['all', 'clinical'],
    color: C.indigo, radius: 14, cluster: 'sophia', propertyRichness: 0.7, totalProperties: 5,
  },
  // ── Agent Coalition Nodes (a01–a03) ──────────────────────────────────────
  {
    id: 'a01', nodeNum: 53, type: 'Agent', label: 'CHW Agent', sublabel: 'Rosa Martinez · Active',
    properties: {
      name: 'Rosa Martinez', role: 'Community Health Worker', status: 'ACTIVE',
      lastAction: '2026-06-12', actionType: 'SDOH_OUTREACH', touchpoints: 14,
      ownedNodes: 'n17,n18,n20,n21,n22,n23,n30,n41,n43',
      monitoredNodes: 'n04,n07,n47,n48',
    },
    lens: ['all', 'agents'],
    color: C.agent, radius: 22, cluster: 'agents', propertyRichness: 0.92, totalProperties: 9,
  },
  {
    id: 'a02', nodeNum: 54, type: 'Agent', label: 'Care Manager', sublabel: 'Sarah Johnson · Active',
    properties: {
      name: 'Sarah Johnson', role: 'Care Manager', status: 'ACTIVE',
      lastAction: '2026-06-14', actionType: 'CARE_PLAN_UPDATE', touchpoints: 8,
      ownedNodes: 'n04,n05,n07,n08,n14,n33,n38,n51',
      monitoredNodes: 'n01,n16,n31,n44',
    },
    lens: ['all', 'agents'],
    color: '#0ea5e9', radius: 22, cluster: 'agents', propertyRichness: 0.88, totalProperties: 9,
  },
  {
    id: 'a03', nodeNum: 55, type: 'Agent', label: 'Zarit Dispatcher', sublabel: 'BH Coordinator · Active',
    properties: {
      name: 'BH Coordinator', role: 'Zarit Dispatcher', status: 'ACTIVE',
      lastAction: '2026-06-13', actionType: 'BH_SCREENING_DISPATCH', touchpoints: 3,
      ownedNodes: 'n25,n38,n51,n24,n44',
      monitoredNodes: 'n19,n23,n31',
    },
    lens: ['all', 'agents'],
    color: '#a78bfa', radius: 22, cluster: 'agents', propertyRichness: 0.82, totalProperties: 9,
  },
];

// ── 67 Edges ──────────────────────────────────────────────────────────────────
export const graphEdges: GraphEdge[] = [
  // Maria → family
  { id: 'e01', source: 'n01', target: 'n16', type: 'INFORMAL_CAREGIVER_FOR', label: 'CAREGIVER FOR', color: C.teal, strokeWidth: 2, lens: ['all', 'social', 'clinical'],
    edgeProps: { since: '2024-01', confidence: 0.97, touchpoints: 22, lastContact: '2d ago', status: 'ACTIVE' } },
  { id: 'e02', source: 'n01', target: 'n15', type: 'PARENT_OF', label: 'PARENT OF', color: C.pink, strokeWidth: 2, lens: ['all', 'clinical', 'social'],
    edgeProps: { since: '2024-06', confidence: 1.0, touchpoints: 30, lastContact: 'today', status: 'ACTIVE' } },
  // Maria → insurance
  { id: 'e03', source: 'n01', target: 'n02', type: 'COVERED_BY', label: 'COVERED BY', color: C.lime, strokeWidth: 1, lens: ['all', 'eligibility'],
    edgeProps: { since: '2023-01', confidence: 0.99, status: 'ACTIVE', lastContact: '89d renewal' } },
  { id: 'e04', source: 'n15', target: 'n03', type: 'COVERED_BY', label: 'COVERED BY', color: C.lime, strokeWidth: 1, lens: ['all', 'eligibility'],
    edgeProps: { since: '2024-06', confidence: 0.99, status: 'ACTIVE' } },
  // Maria → care gaps
  { id: 'e05', source: 'n01', target: 'n04', type: 'HAS_CARE_GAP', label: 'HAS GAP', color: C.red, strokeWidth: 2, lens: ['all', 'clinical'],
    edgeProps: { since: '2026-04-06', confidence: 0.95, gapDays: 38, status: 'OPEN', lastContact: '38d ago' } },
  { id: 'e06', source: 'n01', target: 'n05', type: 'HAS_CARE_GAP', label: 'HAS GAP', color: C.red, strokeWidth: 2, lens: ['all', 'clinical', 'behavioral'],
    edgeProps: { since: '2025-04-01', confidence: 0.9, gapDays: 427, status: 'OPEN' } },
  { id: 'e07', source: 'n15', target: 'n06', type: 'HAS_CARE_GAP', label: 'HAS GAP', color: C.red, strokeWidth: 1.5, lens: ['all', 'clinical'],
    edgeProps: { since: '2026-05-25', confidence: 0.88, gapDays: 21, status: 'OPEN' } },
  // Maria → episodes
  { id: 'e08', source: 'n01', target: 'n07', type: 'HAS_EPISODE', label: 'HAS EPISODE', color: C.emerald, strokeWidth: 1.5, lens: ['all', 'clinical'],
    edgeProps: { since: '2025-11', confidence: 0.92, status: 'ACTIVE', lastContact: '40d ago' } },
  { id: 'e09', source: 'n01', target: 'n08', type: 'HAS_EPISODE', label: 'HAS EPISODE', color: C.emerald, strokeWidth: 1.5, lens: ['all', 'clinical', 'behavioral'],
    edgeProps: { since: '2025-04', confidence: 0.85, status: 'UNMANAGED', gapDays: 427 } },
  { id: 'e10', source: 'n15', target: 'n09', type: 'HAS_EPISODE', label: 'HAS EPISODE', color: C.emerald, strokeWidth: 1.5, lens: ['all', 'clinical'],
    edgeProps: { since: '2024-06', confidence: 0.9, status: 'ACTIVE' } },
  { id: 'e11', source: 'n16', target: 'n10', type: 'HAS_EPISODE', label: 'HAS EPISODE', color: C.emerald, strokeWidth: 1.5, lens: ['all', 'clinical'],
    edgeProps: { since: '2023-08', confidence: 0.88, status: 'CAREGIVER_MANAGED', lastContact: '7d ago' } },
  // Medications
  { id: 'e12', source: 'n16', target: 'n11', type: 'PRESCRIBED', label: 'PRESCRIBED', color: C.purple, strokeWidth: 1, lens: ['all', 'clinical'],
    edgeProps: { since: '2023-09', confidence: 0.95, dose: '1000mg', frequency: '2x/day', adherence: 0.72 } },
  { id: 'e13', source: 'n16', target: 'n12', type: 'PRESCRIBED', label: 'PRESCRIBED', color: C.purple, strokeWidth: 1, lens: ['all', 'clinical'],
    edgeProps: { since: '2023-09', confidence: 0.95, dose: '10mg', frequency: '1x/day', adherence: 0.68 } },
  { id: 'e14', source: 'n15', target: 'n13', type: 'PRESCRIBED', label: 'PRESCRIBED', color: C.purple, strokeWidth: 1, lens: ['all', 'clinical'],
    edgeProps: { since: '2026-05', confidence: 0.98, dose: '250mg', frequency: '3x/day', adherence: 0.95 } },
  { id: 'e15', source: 'n01', target: 'n11', type: 'PICKS_UP', label: 'PICKS UP', color: C.teal, strokeWidth: 1.5, dashed: true, lens: ['all', 'clinical', 'social'],
    edgeProps: { since: '2023-09', confidence: 0.88, touchpoints: 14, lastContact: '12d ago', status: 'ACTIVE' } },
  { id: 'e16', source: 'n01', target: 'n12', type: 'PICKS_UP', label: 'PICKS UP', color: C.teal, strokeWidth: 1.5, dashed: true, lens: ['all', 'clinical', 'social'],
    edgeProps: { since: '2023-09', confidence: 0.88, touchpoints: 14, lastContact: '12d ago', status: 'ACTIVE' } },
  // Provider
  { id: 'e17', source: 'n01', target: 'n14', type: 'TREATED_BY', label: 'TREATED BY', color: C.sky, strokeWidth: 1.5, lens: ['all', 'clinical'],
    edgeProps: { since: '2022-03', confidence: 0.96, touchpoints: 8, lastContact: '40d ago', status: 'ACTIVE' } },
  { id: 'e18', source: 'n15', target: 'n14', type: 'TREATED_BY', label: 'TREATED BY', color: C.sky, strokeWidth: 1, lens: ['all', 'clinical'],
    edgeProps: { since: '2024-06', confidence: 0.9, touchpoints: 3, lastContact: '21d ago' } },
  // SDOH → care gaps (BLOCKS — the key insight)
  { id: 'e19', source: 'n18', target: 'n04', type: 'BLOCKS', label: 'BLOCKS', color: C.red, strokeWidth: 2.5, dashed: true, animated: true, lens: ['all', 'social', 'clinical'],
    edgeProps: { since: '2026-04-06', confidence: 0.93, status: 'ACTIVE', lastContact: 'ongoing' } },
  { id: 'e20', source: 'n17', target: 'n04', type: 'BLOCKS', label: 'BLOCKS', color: C.red, strokeWidth: 2.5, dashed: true, animated: true, lens: ['all', 'social', 'clinical'],
    edgeProps: { since: '2026-04-06', confidence: 0.91, status: 'ACTIVE', lastContact: 'ongoing' } },
  // Caregiver burden chain
  { id: 'e21', source: 'n31', target: 'n07', type: 'DEPRIORITIZES', label: 'DEPRIORITIZES', color: C.orange, strokeWidth: 1.5, lens: ['all', 'behavioral', 'social', 'clinical'],
    edgeProps: { since: '2025-04', confidence: 0.78, status: 'ACTIVE' } },
  { id: 'e22', source: 'n31', target: 'n05', type: 'DELAYS', label: 'DELAYS', color: C.orange, strokeWidth: 1.5, lens: ['all', 'behavioral', 'social'],
    edgeProps: { since: '2025-04', confidence: 0.75, gapDays: 427 } },
  { id: 'e23', source: 'n29', target: 'n18', type: 'COMPOUNDS', label: 'COMPOUNDS', color: C.orange, strokeWidth: 1.5, dashed: true, lens: ['all', 'social'],
    edgeProps: { since: '2024-09', confidence: 0.82, status: 'ACTIVE' } },
  { id: 'e24', source: 'n19', target: 'n08', type: 'DRIVES', label: 'DRIVES', color: C.orange, strokeWidth: 1.5, lens: ['all', 'behavioral', 'social'],
    edgeProps: { since: '2025-04', confidence: 0.7, status: 'ACTIVE' } },
  // Pharmacy intelligence
  { id: 'e25', source: 'n32', target: 'n30', type: 'REVEALS_FAMILY_PATTERN', label: 'REVEALS PATTERN', color: C.teal, strokeWidth: 1.5, dashed: true, lens: ['all', 'clinical', 'social'],
    edgeProps: { since: '2024-01', confidence: 0.85, touchpoints: 28, lastContact: '12d ago' } },
  { id: 'e26', source: 'n32', target: 'n35', type: 'FLAGS_RECURRENCE', label: 'FLAGS RECURRENCE', color: C.teal, strokeWidth: 1.5, lens: ['all', 'clinical'],
    edgeProps: { since: '2025-12', confidence: 0.92, touchpoints: 3, status: 'FLAGGED' } },
  { id: 'e27', source: 'n32', target: 'n01', type: 'EXPOSES_GAP', label: 'EXPOSES GAP', color: C.red, strokeWidth: 1.5, dashed: true, lens: ['all', 'clinical', 'social'],
    edgeProps: { since: '2026-04', confidence: 0.88, status: 'ACTIVE' } },
  // Eligibility resolution chain
  { id: 'e28', source: 'n41', target: 'n18', type: 'WOULD_RESOLVE', label: 'WOULD RESOLVE', color: C.lime, strokeWidth: 2, animated: true, lens: ['all', 'eligibility', 'social'],
    edgeProps: { confidence: 0.95, status: 'PROJECTED', lastContact: 'pending enrollment' } },
  { id: 'e29', source: 'n43', target: 'n20', type: 'WOULD_REDUCE', label: 'WOULD REDUCE', color: C.lime, strokeWidth: 1.5, lens: ['all', 'eligibility', 'social'],
    edgeProps: { confidence: 0.88, status: 'PROJECTED' } },
  { id: 'e30', source: 'n44', target: 'n19', type: 'WOULD_ADDRESS', label: 'WOULD ADDRESS', color: C.purple, strokeWidth: 1.5, lens: ['all', 'behavioral', 'eligibility'],
    edgeProps: { confidence: 0.72, status: 'PROJECTED' } },
  // Screening confirmations
  { id: 'e31', source: 'n47', target: 'n17', type: 'CONFIRMS', label: 'CONFIRMS', color: C.indigo, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 0.97, status: 'CONFIRMED' } },
  { id: 'e32', source: 'n47', target: 'n20', type: 'CONFIRMS', label: 'CONFIRMS', color: C.indigo, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 0.94, status: 'CONFIRMED' } },
  { id: 'e33', source: 'n48', target: 'n21', type: 'CONFIRMS', label: 'CONFIRMS', color: C.indigo, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 0.91, status: 'CONFIRMED' } },
  { id: 'e34', source: 'n49', target: 'n31', type: 'QUANTIFIES', label: 'QUANTIFIES', color: C.indigo, strokeWidth: 1, lens: ['all', 'social', 'behavioral'],
    edgeProps: { since: '2026-05-01', confidence: 0.89, status: 'CONFIRMED' } },
  { id: 'e35', source: 'n50', target: 'n18', type: 'CONFIRMS', label: 'CONFIRMS', color: C.indigo, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 0.93, status: 'CONFIRMED' } },
  // BH screening
  { id: 'e36', source: 'n38', target: 'n24', type: 'INDICATES', label: 'INDICATES', color: C.amber, strokeWidth: 1.5, lens: ['all', 'behavioral'],
    edgeProps: { since: '2026-05-01', confidence: 0.82, status: 'ACTIVE' } },
  { id: 'e37', source: 'n51', target: 'n31', type: 'QUANTIFIES', label: 'QUANTIFIES', color: C.amber, strokeWidth: 1.5, lens: ['all', 'behavioral'],
    edgeProps: { since: '2026-06-01', confidence: 0.87, status: 'ACTIVE' } },
  { id: 'e38', source: 'n38', target: 'n25', type: 'GATED_BY', label: 'GATED BY', color: C.amber, strokeWidth: 1.5, dashed: true, lens: ['all', 'behavioral'],
    edgeProps: { since: '2026-05-01', confidence: 0.99, status: '42CFR_PART2' } },
  { id: 'e39', source: 'n51', target: 'n25', type: 'GATED_BY', label: 'GATED BY', color: C.amber, strokeWidth: 1.5, dashed: true, lens: ['all', 'behavioral'],
    edgeProps: { since: '2026-06-01', confidence: 0.99, status: '42CFR_PART2' } },
  // Consent
  { id: 'e40', source: 'n01', target: 'n25', type: 'HAS_CONSENT', label: 'HAS CONSENT', color: C.lime, strokeWidth: 1, lens: ['all', 'behavioral'],
    edgeProps: { since: '2026-05-15', confidence: 1.0, status: 'ACTIVE' } },
  { id: 'e41', source: 'n01', target: 'n26', type: 'HAS_CONSENT', label: 'HAS CONSENT', color: C.lime, strokeWidth: 1, lens: ['all'],
    edgeProps: { since: '2024-06', confidence: 1.0, status: 'ACTIVE' } },
  { id: 'e42', source: 'n01', target: 'n27', type: 'HAS_CONSENT', label: 'HAS CONSENT', color: C.amber, strokeWidth: 1, dashed: true, lens: ['all'],
    edgeProps: { since: '2026-06-01', confidence: 0.5, status: 'PENDING' } },
  // Eligibility
  { id: 'e43', source: 'n01', target: 'n39', type: 'CURRENTLY_ELIGIBLE', label: 'ELIGIBLE', color: C.lime, strokeWidth: 1, lens: ['all', 'eligibility'],
    edgeProps: { since: '2023-01', confidence: 0.99, status: 'ACTIVE', lastContact: 'T+89d renewal' } },
  { id: 'e44', source: 'n15', target: 'n40', type: 'CURRENTLY_ELIGIBLE', label: 'ELIGIBLE', color: C.lime, strokeWidth: 1, lens: ['all', 'eligibility'],
    edgeProps: { since: '2024-06', confidence: 0.99, status: 'ACTIVE' } },
  { id: 'e45', source: 'n01', target: 'n41', type: 'CURRENTLY_ELIGIBLE', label: 'ELIGIBLE', color: C.amber, strokeWidth: 1.5, lens: ['all', 'eligibility'],
    edgeProps: { since: '2025-09', confidence: 0.91, status: 'ELIGIBLE_NOT_ENROLLED' } },
  { id: 'e46', source: 'n01', target: 'n42', type: 'CURRENTLY_ELIGIBLE', label: 'ELIGIBLE', color: C.amber, strokeWidth: 1, lens: ['all', 'eligibility'],
    edgeProps: { since: '2025-09', confidence: 0.85, status: 'ELIGIBLE_NOT_ENROLLED' } },
  { id: 'e47', source: 'n01', target: 'n43', type: 'CURRENTLY_ELIGIBLE', label: 'ELIGIBLE', color: C.amber, strokeWidth: 1.5, lens: ['all', 'eligibility'],
    edgeProps: { since: '2024-06', confidence: 0.93, status: 'LAPSED_ELIGIBLE' } },
  { id: 'e48', source: 'n01', target: 'n44', type: 'REFERRED_TO', label: 'REFERRED TO', color: C.purple, strokeWidth: 1, lens: ['all', 'behavioral'],
    edgeProps: { since: '2025-04', confidence: 0.78, status: 'REFERRED_NOT_ENROLLED', gapDays: 427 } },
  { id: 'e49', source: 'n01', target: 'n45', type: 'ON_WAITLIST', label: 'ON WAITLIST', color: C.slate, strokeWidth: 1, lens: ['all', 'eligibility', 'social'],
    edgeProps: { since: '2025-06', confidence: 0.88, status: 'WAITLIST_47' } },
  { id: 'e50', source: 'n01', target: 'n46', type: 'CURRENTLY_ELIGIBLE', label: 'ELIGIBLE', color: C.amber, strokeWidth: 1, lens: ['all', 'eligibility'],
    edgeProps: { since: '2025-10', confidence: 0.87, status: 'ELIGIBLE_NOT_APPLIED' } },
  // Seasonal
  { id: 'e51', source: 'n36', target: 'n17', type: 'COMPOUNDS', label: 'COMPOUNDS', color: C.slate, strokeWidth: 1, dashed: true, lens: ['all', 'social'],
    edgeProps: { since: '2025-11', confidence: 0.75, status: 'SEASONAL' } },
  // Housing → economic
  { id: 'e52', source: 'n45', target: 'n21', type: 'EXACERBATES', label: 'EXACERBATES', color: C.slate, strokeWidth: 1, lens: ['all', 'social', 'eligibility'],
    edgeProps: { since: '2025-06', confidence: 0.72, status: 'ACTIVE' } },
  // LIHEAP → seasonal
  { id: 'e53', source: 'n46', target: 'n36', type: 'SEASONAL_RISK', label: 'SEASONAL RISK', color: C.slate, strokeWidth: 1, lens: ['all', 'eligibility', 'social'],
    edgeProps: { since: '2025-10', confidence: 0.8, status: 'SEASONAL' } },
  // Maria → SDOH
  { id: 'e54', source: 'n01', target: 'n17', type: 'HAS_SDOH', label: 'HAS SDOH', color: C.orange, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2022-01', confidence: 0.96, status: 'CONFIRMED' } },
  { id: 'e55', source: 'n01', target: 'n18', type: 'HAS_SDOH', label: 'HAS SDOH', color: C.orange, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2024-06', confidence: 0.94, status: 'CONFIRMED' } },
  { id: 'e56', source: 'n01', target: 'n19', type: 'HAS_SDOH', label: 'HAS SDOH', color: C.orange, strokeWidth: 1, lens: ['all', 'social', 'behavioral'],
    edgeProps: { since: '2025-04', confidence: 0.88, status: 'CONFIRMED' } },
  { id: 'e57', source: 'n01', target: 'n20', type: 'HAS_SDOH', label: 'HAS SDOH', color: C.orange, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 0.91, status: 'CONFIRMED' } },
  { id: 'e58', source: 'n01', target: 'n21', type: 'HAS_SDOH', label: 'HAS SDOH', color: C.orange, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 0.89, status: 'CONFIRMED' } },
  { id: 'e59', source: 'n01', target: 'n22', type: 'HAS_SDOH', label: 'HAS SDOH', color: C.orange, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 0.85, status: 'CONFIRMED' } },
  { id: 'e60', source: 'n01', target: 'n23', type: 'HAS_SDOH', label: 'HAS SDOH', color: C.orange, strokeWidth: 1, lens: ['all', 'social', 'behavioral'],
    edgeProps: { since: '2026-05-01', confidence: 0.8, status: 'CONFIRMED' } },
  // Screening → Maria
  { id: 'e61', source: 'n01', target: 'n47', type: 'HAS_SCREENING', label: 'SCREENED', color: C.indigo, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 1.0, status: 'COMPLETE' } },
  { id: 'e62', source: 'n01', target: 'n48', type: 'HAS_SCREENING', label: 'SCREENED', color: C.indigo, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 1.0, status: 'COMPLETE' } },
  { id: 'e63', source: 'n01', target: 'n49', type: 'HAS_SCREENING', label: 'SCREENED', color: C.indigo, strokeWidth: 1, lens: ['all', 'social', 'behavioral'],
    edgeProps: { since: '2026-05-01', confidence: 1.0, status: 'COMPLETE' } },
  { id: 'e64', source: 'n01', target: 'n50', type: 'HAS_SCREENING', label: 'SCREENED', color: C.indigo, strokeWidth: 1, lens: ['all', 'social'],
    edgeProps: { since: '2026-05-01', confidence: 1.0, status: 'COMPLETE' } },
  { id: 'e65', source: 'n01', target: 'n38', type: 'HAS_BH_SCREENING', label: 'BH SCREENED', color: C.amber, strokeWidth: 1.5, dashed: true, lens: ['all', 'behavioral'],
    edgeProps: { since: '2026-05-01', confidence: 0.95, status: 'CONSENT_GATED' } },
  { id: 'e66', source: 'n01', target: 'n51', type: 'HAS_BH_SCREENING', label: 'BH SCREENED', color: C.amber, strokeWidth: 1.5, dashed: true, lens: ['all', 'behavioral'],
    edgeProps: { since: '2026-06-01', confidence: 0.92, status: 'CONSENT_GATED' } },
  { id: 'e67', source: 'n15', target: 'n52', type: 'HAS_SCREENING', label: 'SCREENED', color: C.indigo, strokeWidth: 1, lens: ['all', 'clinical'],
    edgeProps: { since: '2026-05-15', confidence: 0.97, status: 'COMPLETE' } },
  // ── Agent Coalition Edges ─────────────────────────────────────────────────
  { id: 'ea01', source: 'a01', target: 'n01', type: 'MANAGES_CARE', label: 'MANAGES CARE', color: C.agent, strokeWidth: 2, lens: ['agents'],
    edgeProps: { since: '2026-01', confidence: 0.95, touchpoints: 14, lastContact: '3d ago', actionType: 'SDOH_OUTREACH' } },
  { id: 'ea02', source: 'a01', target: 'n17', type: 'OWNS_NODE', label: 'OWNS', color: C.agent, strokeWidth: 1.5, lens: ['agents'],
    edgeProps: { since: '2026-01', confidence: 0.92, lastAction: '2026-06-12', actionType: 'BARRIER_ASSESSMENT' } },
  { id: 'ea03', source: 'a01', target: 'n18', type: 'OWNS_NODE', label: 'OWNS', color: C.agent, strokeWidth: 1.5, lens: ['agents'],
    edgeProps: { since: '2026-01', confidence: 0.9, lastAction: '2026-06-12', actionType: 'BARRIER_ASSESSMENT' } },
  { id: 'ea04', source: 'a01', target: 'n41', type: 'ACTIONED', label: 'ACTIONED', color: '#a78bfa', strokeWidth: 1.5, animated: true, lens: ['agents'],
    edgeProps: { since: '2026-06-10', confidence: 0.88, lastAction: '2026-06-10', actionType: 'ENROLLMENT_INITIATED' } },
  { id: 'ea05', source: 'a02', target: 'n01', type: 'MANAGES_CARE', label: 'MANAGES CARE', color: '#0ea5e9', strokeWidth: 2, lens: ['agents'],
    edgeProps: { since: '2025-11', confidence: 0.97, touchpoints: 8, lastContact: '1d ago', actionType: 'CARE_PLAN_UPDATE' } },
  { id: 'ea06', source: 'a02', target: 'n04', type: 'MONITORS', label: 'MONITORS', color: '#0ea5e9', strokeWidth: 1.5, lens: ['agents'],
    edgeProps: { since: '2026-04', confidence: 0.95, lastAction: '2026-06-14', actionType: 'GAP_MONITORING' } },
  { id: 'ea07', source: 'a02', target: 'n07', type: 'OWNS_NODE', label: 'OWNS', color: '#0ea5e9', strokeWidth: 1.5, lens: ['agents'],
    edgeProps: { since: '2025-11', confidence: 0.92, lastAction: '2026-06-14', actionType: 'EPISODE_MANAGEMENT' } },
  { id: 'ea08', source: 'a03', target: 'n01', type: 'DISPATCHED_TO', label: 'DISPATCHED TO', color: '#a78bfa', strokeWidth: 2, lens: ['agents'],
    edgeProps: { since: '2026-06-01', confidence: 0.9, touchpoints: 3, lastContact: '2d ago', actionType: 'BH_SCREENING_DISPATCH' } },
  { id: 'ea09', source: 'a03', target: 'n51', type: 'OWNS_NODE', label: 'OWNS', color: '#a78bfa', strokeWidth: 1.5, lens: ['agents'],
    edgeProps: { since: '2026-06-01', confidence: 0.88, lastAction: '2026-06-13', actionType: 'ZARIT_DISPATCH' } },
  { id: 'ea10', source: 'a03', target: 'n38', type: 'MONITORS', label: 'MONITORS', color: '#a78bfa', strokeWidth: 1.5, dashed: true, lens: ['agents'],
    edgeProps: { since: '2026-05-01', confidence: 0.85, lastAction: '2026-06-13', actionType: 'BH_MONITORING' } },
];

// ── Lens definitions ──────────────────────────────────────────────────────────
export interface LensDefinition {
  id: LensType;
  label: string;
  description: string;
  cypher: string;
  nodeCount: number;
  edgeCount: number;
  color: string;
}

export const lensDefinitions: LensDefinition[] = [
  {
    id: 'all',
    label: 'All 52',
    description: 'Complete whole-person graph — all 52 nodes and 67 edges',
    cypher: `MATCH (m:Member {id: 'MARIA_SD_001'})-[r]->(n)
OPTIONAL MATCH (n)-[r2]->(n2)
RETURN m, r, n, r2, n2`,
    nodeCount: 52,
    edgeCount: 67,
    color: '#0043ce',
  },
  {
    id: 'clinical',
    label: 'Clinical',
    description: 'Episodes, care gaps, medications, providers — with cross-domain SDOH blockers highlighted',
    cypher: `MATCH (m:Member {id: 'MARIA_SD_001'})
-[r:ACTIVE_EPISODE|HAS_CARE_GAP|PRESCRIBED|
   TREATED_BY|PENDING_AUTH|PARENT_OF]->(n)
OPTIONAL MATCH (n)-[r2:BLOCKS|REQUIRES|
   COVERS|FLAGS_RECURRENCE]->(n2)
RETURN m, r, n, r2, n2`,
    nodeCount: 24,
    edgeCount: 28,
    color: '#198038',
  },
  {
    id: 'behavioral',
    label: 'Behavioral Health',
    description: 'BH screenings, postpartum risk, caregiver burden — 42 CFR Part 2 gated nodes shown with lock',
    cypher: `MATCH (m:Member {id: 'MARIA_SD_001'})
-[r:HAS_SDOH|HAS_BH_SCREENING|HAS_EPISODE]->(n)
WHERE n:BHScreening
   OR n:SDOHNode
   OR (n:Episode AND n.type IN
      ['PostpartumHealth','CaregiverBurdenRisk'])
   OR n:BHProgramStatus
OPTIONAL MATCH (n)-[r2:INDICATES|QUANTIFIES|
   DRIVES|WOULD_ADDRESS|GATED_BY]->(n2)
RETURN m, r, n, r2, n2`,
    nodeCount: 14,
    edgeCount: 18,
    color: '#6929c4',
  },
  {
    id: 'social',
    label: 'Social & Equity',
    description: 'SDOH barriers, screening results, benefit gaps — resolution chain shows how one enrollment unblocks a care gap',
    cypher: `MATCH (m:Member {id: 'MARIA_SD_001'})
-[r:HAS_SDOH|HAS_SCREENING|CURRENTLY_ELIGIBLE|
   INFORMAL_CAREGIVER_FOR|HAS_BENEFIT]->(n)
WHERE n:SDOHNode
   OR n:ScreeningResult
   OR n:BenefitStatus
   OR n:EligibilityStatus
   OR n:WICStatus
   OR n:LIHEAPStatus
   OR n:HousingStatus
OPTIONAL MATCH (n)-[r2:BLOCKS|WOULD_RESOLVE|
   WOULD_REDUCE|CONFIRMS|SEASONAL_RISK|
   REVEALS_FAMILY_PATTERN]->(n2)
RETURN m, r, n, r2, n2`,
    nodeCount: 22,
    edgeCount: 26,
    color: '#007d79',
  },
  {
    id: 'eligibility',
    label: 'Eligibility',
    description: 'Real-time program status — eligible-not-enrolled gaps with forward resolution arrows',
    cypher: `MATCH (m:Member {id: 'MARIA_SD_001'})
-[r:CURRENTLY_ELIGIBLE|HAS_BENEFIT|
   HAS_WIC|HAS_HOUSING|HAS_LIHEAP]->(n)
WHERE n:EligibilityStatus
   OR n:BenefitStatus
   OR n:WICStatus
   OR n:LIHEAPStatus
   OR n:HousingStatus
OPTIONAL MATCH (n)-[r2:WOULD_RESOLVE|
   WOULD_REDUCE|WOULD_ADDRESS|
   RESOLVES|SEASONAL_RISK]->(n2)
RETURN m, r, n, r2, n2`,
    nodeCount: 10,
    edgeCount: 12,
    color: '#b45309',
  },
  {
    id: 'agents',
    label: 'Agent Coalition',
    description: 'Multi-agent coordination view — CHW, Care Manager, and Zarit Dispatcher with owned/monitored nodes and last-action timestamps',
    cypher: `MATCH (a:Agent)-[r:MANAGES_CARE|OWNS_NODE|MONITORS|ACTIONED|DISPATCHED_TO]->(n)
WHERE a.patientId = 'MARIA_SD_001'
OPTIONAL MATCH (a)-[r2:COORDINATES_WITH]->(a2:Agent)
RETURN a, r, n, r2, a2`,
    nodeCount: 13,
    edgeCount: 10,
    color: '#7c3aed',
  },
];

// ── Active signals ─────────────────────────────────────────────────────────────
export interface ActiveSignal {
  id: string;
  type: string;
  label: string;
  detail: string;
  urgency: 'critical' | 'warning' | 'info' | 'success';
  relatedNodeIds: string[];
  action: string;
  /** Lens to auto-activate when this signal is clicked */
  targetLens?: LensType;
  /** Ordered chain for multi-hop traversal animation (View Chain) */
  chainNodeIds?: string[];
}

export const activeSignals: ActiveSignal[] = [
  {
    id: 'sig-01',
    type: 'CARE_GAP_DEADLINE_APPROACHING',
    label: 'HbA1c · 40 days remaining',
    detail: 'HEDIS window closing — childcare barrier blocking appointment',
    urgency: 'critical',
    relatedNodeIds: ['n04', 'n07', 'n05', 'n14', 'n33'],
    action: 'View Chain',
    targetLens: 'clinical',
    chainNodeIds: ['n04', 'n07', 'n14', 'n33'],
  },
  {
    id: 'sig-02',
    type: 'BENEFIT_GAP_ACTIONABLE',
    label: 'Childcare Subsidy · $487/mo',
    detail: 'Eligible but not enrolled — resolves HbA1c appointment blocker',
    urgency: 'warning',
    relatedNodeIds: ['n41', 'n42', 'n46', 'n39', 'n40'],
    action: 'Act',
    targetLens: 'eligibility',
  },
  {
    id: 'sig-03',
    type: 'BENEFIT_GAP_ACTIONABLE',
    label: 'WIC Lapsed · $320/mo',
    detail: 'Sophia + Maria both eligible — lapsed post-delivery',
    urgency: 'warning',
    relatedNodeIds: ['n43', 'n20', 'n21', 'n30', 'n18'],
    action: 'Act',
    targetLens: 'social',
  },
  {
    id: 'sig-04',
    type: 'SCREENING_COMPLETE',
    label: 'PRAPARE confirmed · 7 domains',
    detail: 'Social screening complete — SDOHNodes confirmed and dated',
    urgency: 'success',
    relatedNodeIds: ['n47', 'n48', 'n17', 'n22', 'n23'],
    action: 'View',
    targetLens: 'social',
  },
  {
    id: 'sig-05',
    type: 'BH_SCREENING_INDICATED',
    label: 'Consent active · Zarit dispatched',
    detail: 'Edinburgh PND score 11 — BH consent active — Zarit in progress',
    urgency: 'info',
    relatedNodeIds: ['n25', 'n38', 'n51', 'n24', 'n44'],
    action: 'View',
    targetLens: 'behavioral',
  },
];
