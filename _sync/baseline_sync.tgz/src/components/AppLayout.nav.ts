// ─── AppLayout.nav.ts ─────────────────────────────────────────────────────────
// Nav item data and grouping config for AppLayout sidebar.

import type { UserSession } from '@/lib/appContext';

export const DEMO_USERS: UserSession[] = [
  { userId: 'user-001', name: 'Sarah Johnson', initials: 'SJ', role: 'care_manager', email: 'sarah.johnson@rhtp-health.org' },
  { userId: 'user-002', name: 'Dr. James Whitfield', initials: 'JW', role: 'physician', email: 'james.whitfield@tcoc-health.org' },
];

export interface NavItem {
  key: string;
  label: string;
  icon: string;
  href: string;
  badge?: number;
  group?: string;
}

export const navItems: NavItem[] = [
  // RHTP Program
  { key: 'nav-contracts', label: 'RHTP Overview', icon: 'BuildingOffice2Icon', href: '/contract-program-selection', group: 'RHTP Program' },
  { key: 'nav-regions', label: 'Regions', icon: 'MapPinIcon', href: '/region-view', group: 'RHTP Program' },
  { key: 'nav-providers', label: 'Program Networks', icon: 'BuildingOffice2Icon', href: '/provider-level', group: 'RHTP Program' },
  { key: 'nav-panel', label: 'Panel & Cohort', icon: 'UserGroupIcon', href: '/panel-cohort-view', badge: 38, group: 'RHTP Program' },
  { key: 'nav-stars', label: 'Quality Gaps & Attribution', icon: 'StarIcon', href: '/stars-hedis-mips', group: 'RHTP Program' },
  { key: 'nav-social-dashboard-rhtp', label: 'Social Needs Dashboard', icon: 'ChartBarIcon', href: '/social-needs-dashboard', group: 'RHTP Program' },
  { key: 'nav-outcomes-linkage-rhtp', label: 'Outcomes Linkage', icon: 'ArrowTrendingDownIcon', href: '/outcomes-linkage', group: 'RHTP Program' },
  // CMS-0057-F
  { key: 'nav-cms0057f', label: 'CMS-0057-F', icon: 'ShieldCheckIcon', href: '/cms', group: 'CMS-0057-F' },
  // Care Team Workflows
  { key: 'nav-care-team-inbox', label: 'Care Team Inbox', icon: 'InboxIcon', href: '/care-team-inbox', badge: 5, group: 'Care Team Workflows' },
  { key: 'nav-care-manager', label: 'Care Manager Dashboard', icon: 'ClipboardDocumentListIcon', href: '/care-manager', group: 'Care Team Workflows' },
  { key: 'nav-chw-workflow', label: 'CHW Workflow', icon: 'UserIcon', href: '/chw-workflow', group: 'Care Team Workflows' },
  { key: 'nav-specialist-inbox', label: 'Specialist Inbox', icon: 'EnvelopeIcon', href: '/specialist-inbox', group: 'Care Team Workflows' },
  { key: 'nav-md-smart-launch', label: 'MD Smart Launch', icon: 'BoltIcon', href: '/md-smart-launch', group: 'Care Team Workflows' },
  { key: 'nav-care-gap-closure', label: 'Care Gap Closure', icon: 'CheckCircleIcon', href: '/care-gap-closure-verification', group: 'Care Team Workflows' },
  { key: 'nav-referrals', label: 'Referral Tracking', icon: 'ArrowsRightLeftIcon', href: '/referral-tracking', group: 'Care Team Workflows' },
  // Whole Person Care
  { key: 'nav-whole-person-graph', label: 'Whole Person Care View', icon: 'CircleStackIcon', href: '/whole-person-care-summary', group: 'Whole Person Care' },
  { key: 'nav-patient', label: 'Citizen Detail', icon: 'UserIcon', href: '/patient-detail', group: 'Whole Person Care' },
  { key: 'nav-social-screening', label: 'Social Needs Screening', icon: 'ClipboardDocumentCheckIcon', href: '/social-needs-screening', group: 'Whole Person Care' },
  { key: 'nav-physicians', label: 'Care Team Members', icon: 'UserGroupIcon', href: '/physician-view', group: 'Whole Person Care' },
  { key: 'nav-program-eligibility', label: 'Program Eligibility', icon: 'CheckBadgeIcon', href: '/program-eligibility', group: 'Whole Person Care' },
  { key: 'nav-cbo-directory', label: 'CBO Directory', icon: 'BuildingStorefrontIcon', href: '/cbo-directory', group: 'Whole Person Care' },
  { key: 'nav-episodic-management', label: 'Episodic Management Analytics', icon: 'ChartBarIcon', href: '/episodic-management-analytics', group: 'Whole Person Care' },
  // Agentic Orchestrate
  { key: 'uhg-fragmentation', label: 'One Enterprise · Five Entities', icon: 'BuildingOffice2Icon', href: '/uhg-orchestrate/fragmentation-split-system-view', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-cdp-assembly', label: 'CDP Assembly', icon: 'CircleStackIcon', href: '/uhg-orchestrate/cdp-assembly-split', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-whole-person-view', label: 'Whole Person Care View', icon: 'CircleStackIcon', href: '/whole-person-care-summary', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-journey-aware', label: 'Journey-Aware Context', icon: 'MapIcon', href: '/uhg-orchestrate/consumer-360', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-whole-person', label: 'Whole Person Care Intelligence', icon: 'SparklesIcon', href: '/uhg-orchestrate/whole-person-care', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-signal-disposition', label: 'Signal Disposition Engine', icon: 'BoltIcon', href: '/uhg-orchestrate/signal-disposition-engine', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-super-orchestration', label: 'Agentic Super Orchestration', icon: 'CpuChipIcon', href: '/uhg-orchestrate/controller-agentic-super-orchestration-centerpiece', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-super-agent', label: 'Agentic Marketplace', icon: 'CpuChipIcon', href: '/uhg-orchestrate/agent-library', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-family-thread', label: 'Family Thread — Sofia', icon: 'HomeIcon', href: '/uhg-orchestrate/family-sofia', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-caregiver', label: 'Caregiver Intelligence — Elena', icon: 'UserIcon', href: '/uhg-orchestrate/caregiver-elena', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-population-filter', label: 'Live Population Filter', icon: 'UserGroupIcon', href: '/uhg-orchestrate/portfolio-scale', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-agent-impact', label: 'Agent Impact Dashboard', icon: 'ChartBarIcon', href: '/uhg-orchestrate/agent-impact-dashboard', group: 'Agentic_Orchestrate-Screens' },
  { key: 'uhg-reporting', label: 'Agent Impact — Reporting', icon: 'ChartBarIcon', href: '/uhg-orchestrate/reporting-dashboard', group: 'Agentic_Orchestrate-Screens' },
  // Admin Console
  { key: 'nav-ac-home',    label: 'Admin Console',       icon: 'ServerStackIcon',              href: '/admin-console/home',               group: 'Admin Console' },
  { key: 'nav-ac-data',    label: 'Data Connections',     icon: 'ArrowsRightLeftIcon',          href: '/admin-console/data-connections',    group: 'Admin Console' },
  { key: 'nav-ac-consent', label: 'Consent & Governance', icon: 'ShieldCheckIcon',              href: '/admin-console/consent-governance',  group: 'Admin Console' },
  { key: 'nav-ac-health',  label: 'System Health',        icon: 'HeartIcon',                   href: '/admin-console/system-health',       group: 'Admin Console' },
  { key: 'nav-ac-agents',  label: 'Agent Oversight',      icon: 'CpuChipIcon',                 href: '/admin-console/agent-oversight',     group: 'Admin Console' },
  { key: 'nav-ac-iam',     label: 'Identity & Access',    icon: 'UserCircleIcon',              href: '/admin-console/identity-access',     group: 'Admin Console' },
  { key: 'nav-ac-quality', label: 'Data Quality',         icon: 'MagnifyingGlassIcon',         href: '/admin-console/data-quality',        group: 'Admin Console' },
  { key: 'nav-ac-audit',   label: 'Audit & Compliance',   icon: 'DocumentMagnifyingGlassIcon', href: '/admin-console/audit-compliance',    group: 'Admin Console' },
  // System
  { key: 'nav-settings', label: 'EHR Settings', icon: 'Cog6ToothIcon', href: '/settings', group: 'System' },
  { key: 'nav-fhir-tester', label: 'FHIR API Tester', icon: 'BeakerIcon', href: '/settings/fhir-tester', group: 'System' },
  { key: 'nav-demo-onboarding', label: 'Demo Onboarding', icon: 'PlayCircleIcon', href: '/demo-onboarding', group: 'System' },
  { key: 'nav-demo-deck', label: 'Demo Deck (PDF)', icon: 'DocumentArrowDownIcon', href: '/demo-deck', group: 'System' },
  // Backup
  { key: 'nav-exec-dashboard', label: 'Executive Dashboard', icon: 'ChartBarIcon', href: '/executive-outcomes-dashboard', group: 'Backup' },
  { key: 'nav-cdp-assembly-new', label: 'CDP Assembly', icon: 'CircleStackIcon', href: '/cdp-assembly', group: 'Backup' },
  { key: 'nav-journey-aware-context', label: 'Journey-Aware Context', icon: 'MapIcon', href: '/journey-aware-context', group: 'Backup' },
  { key: 'nav-whole-person-intelligence', label: 'Whole Person Intelligence', icon: 'SparklesIcon', href: '/whole-person-intelligence', group: 'Backup' },
  { key: 'nav-signal-disposition-engine', label: 'Signal Disposition Engine', icon: 'BoltIcon', href: '/signal-disposition-engine', group: 'Backup' },
  { key: 'nav-cdp-assembly', label: 'CDP Assembly View', icon: 'CircleStackIcon', href: '/cdp-assembly-view', group: 'Backup' },
  { key: 'nav-consent-sovereignty', label: 'Consent & Sovereignty Panel', icon: 'ShieldCheckIcon', href: '/consent-sovereignty-panel', group: 'Backup' },
  { key: 'nav-household-view', label: 'Household View', icon: 'HomeIcon', href: '/household-view', group: 'Backup' },
  { key: 'nav-agent-coalition', label: 'Agent Coalition Monitor', icon: 'CpuChipIcon', href: '/agent-coalition-monitor', group: 'Backup' },
  { key: 'nav-episode-detail', label: 'Episode Detail', icon: 'FolderOpenIcon', href: '/episode-detail', group: 'Backup' },
  { key: 'nav-financial', label: 'Financial Dashboard', icon: 'CurrencyDollarIcon', href: '/financial-dashboard', group: 'Backup' },
  { key: 'nav-provider-dir', label: 'Provider Directory', icon: 'BuildingOffice2Icon', href: '/provider-selection', group: 'Backup' },
  { key: 'nav-journey', label: 'Referral Journey Tracker', icon: 'MapIcon', href: '/referral-journey-tracker', group: 'Backup' },
  { key: 'nav-submitted-referrals', label: 'Submitted Referrals', icon: 'ClipboardDocumentListIcon', href: '/submitted-referrals', group: 'Backup' },
  { key: 'nav-benefit-enrollment', label: 'Benefit Enrollment Tracker', icon: 'DocumentCheckIcon', href: '/benefit-enrollment', group: 'Backup' },
  { key: 'nav-patient-episode-summary', label: 'Patient Episode Summary', icon: 'DocumentTextIcon', href: '/patient-episode-summary', group: 'Backup' },
];

export const groupOrder = ['RHTP Program', 'CMS-0057-F', 'Care Team Workflows', 'Whole Person Care', 'Agentic_Orchestrate-Screens', 'Admin Console', 'System', 'Backup'];
