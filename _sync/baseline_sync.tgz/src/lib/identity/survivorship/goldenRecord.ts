// F3 survivorship  // DP-7
/**
 * Golden-record BUILDER — derives the golden view from source-attributed facts.
 *
 * The golden record is a PROJECTION: given the durable facts (who asserted what,
 * when) and the ranking rules, it derives, per field, the winning value plus the
 * provenance of WHY it won. Nothing is overwritten — re-running with different
 * rules re-derives a different golden view from the SAME facts (no data loss).
 *
 * Per field:
 *   1. take the field's ranking (its own, else defaultRanking);
 *   2. walk the ranking top-first; the first source that asserted the field wins,
 *      and among that source's facts the most-recent (tiebreak) is chosen;
 *   3. if NO ranked source asserted it, fall back to the globally most-recent fact
 *      (reason 'recency-fallback', rank -1) — a value from an unranked source still
 *      surfaces rather than being dropped.
 *
 * Deterministic: ties on asOf break by source then value, and derivedAt comes from
 * an injected clock, so the projection is reproducible without mocking globals.
 */
import * as clock from '@/lib/clock';
import { DEFAULT_SURVIVORSHIP_RULES, rankingFor } from './rules';
import type { FieldProvenance, GoldenRecord, SourceAttributedFact, SurvivorshipRules } from './types';

export interface BuildGoldenRecordOptions {
  rules?: SurvivorshipRules;
  /** Injected clock for derivedAt (default: clock.nowIso). */
  now?: () => number;
}

/** Stable, deterministic pick among facts of equal precedence: newest, then source, then value. */
function moreRecent(a: SourceAttributedFact, b: SourceAttributedFact): SourceAttributedFact {
  if (a.asOf !== b.asOf) return a.asOf > b.asOf ? a : b;
  if (a.source !== b.source) return a.source < b.source ? a : b;
  return a.value <= b.value ? a : b;
}

function winnerForField(
  field: string,
  facts: SourceAttributedFact[],
  rules: SurvivorshipRules,
): FieldProvenance | null {
  if (facts.length === 0) return null;
  const ranking = rankingFor(rules, field);

  // Walk ranks top-first; first source with any fact wins (most-recent within it).
  for (let rank = 0; rank < ranking.length; rank++) {
    const source = ranking[rank];
    const atSource = facts.filter((f) => f.source === source);
    if (atSource.length === 0) continue;
    const chosen = atSource.reduce(moreRecent);
    return { field, value: chosen.value, source: chosen.source, asOf: chosen.asOf, rank, reason: 'source-ranked' };
  }

  // No ranked source asserted this field: surface the most-recent fact anyway.
  const chosen = facts.reduce(moreRecent);
  return { field, value: chosen.value, source: chosen.source, asOf: chosen.asOf, rank: -1, reason: 'recency-fallback' };
}

/**
 * Build the golden record (projection) from source-attributed facts + rules.
 * Pure aside from the injected clock; the facts argument is never mutated.
 */
export function buildGoldenRecord(
  facts: readonly SourceAttributedFact[],
  opts: BuildGoldenRecordOptions = {},
): GoldenRecord {
  const rules = opts.rules ?? DEFAULT_SURVIVORSHIP_RULES;
  const now = opts.now ?? clock.now;

  const byField = new Map<string, SourceAttributedFact[]>();
  for (const fact of facts) {
    const list = byField.get(fact.field) ?? [];
    list.push(fact);
    byField.set(fact.field, list);
  }

  const fields: Record<string, string> = {};
  const provenance: Record<string, FieldProvenance> = {};
  // Deterministic field order (sorted) so the projection is reproducible.
  for (const field of [...byField.keys()].sort()) {
    const winner = winnerForField(field, byField.get(field)!, rules);
    if (winner) {
      fields[field] = winner.value;
      provenance[field] = winner;
    }
  }

  return { fields, provenance, derivedAt: new Date(now()).toISOString() };
}
