/**
 * Terminology / semantic-validation seam — public surface.
 *
 * validateCode / translate / classify over the governed code systems (RxNorm,
 * LOINC, SNOMED-CT, ICD-10-CM, CPT-HCPCS, HCC). The seeded service answers demo
 * data from an in-repo allowlist; the production service throws until a real FHIR
 * terminology server is wired. The SemanticValidator is the stage-4 gate that
 * runs alongside the structural profile validator.
 */
export {
  TERMINOLOGY_SYSTEMS,
  SYSTEM_URIS,
  systemForUri,
  TerminologyServiceNotConfiguredError,
} from './types';
export type {
  TerminologySystem,
  TerminologyService,
  CodeValidation,
  CodeValidationStatus,
  TranslationResult,
  ClassificationResult,
  ClassificationScheme,
} from './types';
export { seedTerminologyService } from './seedTerminologyService';
export { productionTerminologyService } from './productionTerminologyService';
export {
  makeSemanticValidator,
  selectSemanticValidator,
  selectTerminologyService,
  extractGovernedCodings,
  type SemanticValidator,
  type GovernedCoding,
} from './semanticValidator';
export type { CodeAssetBinding } from './types';

// The terminology-asset management facility (registry): currency, versioning,
// and lifecycle of all governed value sets / code systems / classifications.
export {
  createValueSetRegistry,
  valueSetRegistry,
  validateAgainstAssetVersion,
  TerminologyRefreshNotConfiguredError,
  ASSET_FAMILIES,
  ASSET_STATUSES,
  BINDING_STRENGTHS,
  REFRESH_CADENCES,
  CADENCE_DAYS,
  type ValueSetRegistry,
  type RegistryOptions,
  type Clock,
  type CurrencyCheckedValidation,
  type AssetFamily,
  type AssetStatus,
  type BindingStrength,
  type RefreshCadence,
  type TerminologyAsset,
  type BindingSpec,
  type ResolvedBinding,
  type CurrencyFlag,
  type AssetRegistrySeed,
} from './registry';
