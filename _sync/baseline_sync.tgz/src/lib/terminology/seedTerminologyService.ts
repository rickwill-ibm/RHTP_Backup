/**
 * Seeded TerminologyService — the real-now stub backed by an in-repo allowlist.
 *
 * Answers validateCode / translate / classify from data/terminology-seed.json,
 * which covers exactly the codes the demo pipeline fixtures use. Every answer is
 * flagged `stub: true` so no caller mistakes it for a live terminology server.
 * Selected for the `terminology` seam in mock and seeded modes.
 */
import seed from './data/terminology-seed.json';
import { valueSetRegistry } from './registry/valueSetRegistry';
import {
  SYSTEM_URIS,
  type CodeAssetBinding,
  type ClassificationResult,
  type ClassificationScheme,
  type CodeValidation,
  type TerminologyService,
  type TerminologySystem,
  type TranslationResult,
} from './types';

type SeedShape = {
  codeSystems: Record<string, { uri: string; codes: Record<string, string> }>;
  hccClassification: Record<string, { hcc: string; label: string } | string>;
  conceptMap: Record<string, Record<string, string>>;
  valueSets: Record<string, string[]>;
};

const DATA = seed as unknown as SeedShape;

function systemCodes(system: string): Record<string, string> | undefined {
  const entry = DATA.codeSystems[system];
  return entry && typeof entry === 'object' ? entry.codes : undefined;
}

function isGovernedSystem(system: string): boolean {
  return system in DATA.codeSystems;
}

/**
 * Consult the registry for the ACTIVE version of the asset governing `systemUri`,
 * so a validated/classified code carries WHICH value-set version it was checked
 * against and whether that version is current (currency wiring, Iteration 4).
 */
function bindingForSystem(systemUri: string | undefined): CodeAssetBinding | undefined {
  if (!systemUri) return undefined;
  const active = valueSetRegistry.getActiveBySystem(systemUri);
  if (!active) return undefined;
  return {
    assetId: active.id,
    version: active.version,
    status: active.status,
    current: valueSetRegistry.isCurrent(active.id),
  };
}

export const seedTerminologyService: TerminologyService = {
  id: 'seed-terminology-allowlist',

  validateCode(system, code): CodeValidation {
    if (!isGovernedSystem(system)) {
      return { system, code, valid: false, status: 'unsupported-system', stub: true };
    }
    const binding = bindingForSystem(SYSTEM_URIS[system as TerminologySystem]);
    const codes = systemCodes(system) ?? {};
    const display = codes[code];
    if (display !== undefined) {
      return { system, code, valid: true, status: 'valid', display, stub: true, binding };
    }
    return { system, code, valid: false, status: 'unknown-code', stub: true, binding };
  },

  translate(code, sourceSystem: TerminologySystem, targetSystem: TerminologySystem): TranslationResult {
    const key = `${sourceSystem}->${targetSystem}`;
    const map = DATA.conceptMap[key];
    const target = map ? (map[code] ?? null) : null;
    return {
      sourceSystem,
      sourceCode: code,
      targetSystem,
      targetCode: target,
      matched: target !== null,
      stub: true,
    };
  },

  classify(code, scheme: ClassificationScheme, valueSetId?: string): ClassificationResult {
    if (scheme === 'HCC') {
      const binding = bindingForSystem(SYSTEM_URIS.HCC);
      const raw = DATA.hccClassification[code];
      if (raw && typeof raw === 'object') {
        return { scheme, code, group: raw.hcc, label: raw.label, classified: true, stub: true, binding };
      }
      return { scheme, code, group: null, classified: false, stub: true, binding };
    }
    // value-set membership
    const members = valueSetId ? (DATA.valueSets[valueSetId] ?? null) : null;
    if (members) {
      const inSet = members.includes(code);
      return {
        scheme,
        code,
        group: inSet ? valueSetId! : null,
        label: inSet ? `member of ${valueSetId}` : undefined,
        classified: inSet,
        stub: true,
      };
    }
    return { scheme, code, group: null, classified: false, stub: true };
  },
};
