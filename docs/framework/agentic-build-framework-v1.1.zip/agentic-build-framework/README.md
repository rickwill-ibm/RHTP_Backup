# Agentic Build Framework

A reusable, project-agnostic framework for building software with a coalition of AI agents — verifying it adversarially and enforcing quality mechanically. Extracted from a large healthcare-platform build; written to apply to any project and any team.

Share this folder with your team. Everything needed to adopt the framework is here.

---

## Why this exists (the one problem it solves)

Multi-agent builds fail in a specific, recurring way: the build agents — and even the "cleanup" pass — verify **conformance to the plan**. So a gap the *plan itself* missed (a naive design, a load-bearing stub, an entirely absent capability) ships even though everyone was honest. Only a domain expert or the customer notices, too late.

The framework closes that hole with four layers working together:
1. **Operating model** — how orchestration runs (the wave as the unit of work; rules that make it reliable).
2. **Persona library** — who does the work: build roles plus a **red-team panel** that catches what conformance review cannot.
3. **Enforcement kit** — mechanical gates, because a rule in a document gets skipped under pressure but a rule in CI cannot.
4. **Definition of Done** — the composite gate every increment must pass.

**The single most important habit:** verification attacks three layers, not one — does the code match the spec (conformance), is the spec right against real-world domain practice (domain-fidelity), and what is entirely absent that production needs (negative-space).

---

## What's in this package

```
agentic-build-framework/
  README.md                         <- you are here (team overview + enhancements)
  agentic-build-framework.skill     <- the installable skill (a zip; load it in Claude/Claude Code)
  SKILL.md                          <- the skill's entry document
  ADOPTION_GUIDE.md                 <- step-by-step: install, wire the gates, run the loop
  references/
    operating-model.md              <- the wave, the iteration lifecycle, orchestration rules + build lessons
    personas.md                     <- reusable build + red-team persona cards + the Prompt Composition Standard
    enforcement-kit.md              <- the mechanical gates E1-E10 + the composite Definition of Done
```

---

## How your team uses it (three moves)

1. **Install** — the `.skill` file loads the framework into a Claude / Claude Code session (auto-triggers on "multi-agent build", "red team review", "harden a codebase", etc.). Full install paths (in-app, org-managed, or a repo-scoped `.claude/skills/` drop) are in `ADOPTION_GUIDE.md`. For team-wide use, commit this folder to a shared repo and distribute the `.skill` through your org.
2. **Wire the gates first** (one-time per repo) — the quality ratchet (E2), the fail-closed seam gate (E1), the fail-open lint (E9), and the living risk register (E8). These are cheap and are what prevent recurrence. `ADOPTION_GUIDE.md` Part 2 has the exact setup.
3. **Run each iteration as a wave** — brief with a pre-allocated namespace, probe, spine (decisions + contracts + per-agent context manifests), parallel specialists on disjoint trees, convergence to DRY, then the **mandatory red-team panel**, then your own authoritative gate, then one sync. `operating-model.md` and `ADOPTION_GUIDE.md` Part 3 walk it.

The red-team panel is not optional, and every persona must produce findings — "looks fine" is a failed review. Findings route to the register: fix the Unacceptable now, schedule the Critical/High.

---

## What's new in v1.1 (the enhancements this release adds)

These came from real use — each is a lesson turned into a rule.

- **Prompt Composition Standard** (`personas.md`). Per-agent prompts are now **composed** from six stable blocks — ROLE (the persona card) · BRIEF reference · CONTEXT MANIFEST · SCOPE · DoD reference · OUTPUT CONTRACT — instead of hand-authored per task. Only SCOPE is bespoke; the rest is referenced. This kills boilerplate duplication and structural drift, and makes each prompt's role, reads, and tasks separately reviewable. Result: prompts that are consistent, tighter, and tunable rather than ad-hoc.

- **E9 Fail-open Lint** (`enforcement-kit.md`). Fail-open defaults (a config/mode/auth path returning a plausible value instead of failing closed) were the single most recurring red-team finding — caught by hand three separate times. A class a review keeps catching becomes a gate: E9 flags the shapes (`?? default` on config/auth/status, silent catches, default-on dev flags) in CI. Pairs with E1 (which proves seams throw in production).

- **E10 Verbatim Prompt Provenance** (`enforcement-kit.md`). Every agent prompt is captured **verbatim** at send-time, and the analyzable log references it — never a lossy summary. So the actual instruction that drove each agent can be reviewed and improved, which is the whole point of keeping a prompt log.

- **Context manifests + shared-file partitions** (`operating-model.md`). The spine now publishes each specialist a context manifest (exact reads, what-not-to-touch, its namespace slice) AND pre-declares how parallel agents split any shared file (e.g. per-wave companion test files) — so trees stay disjoint and the split is designed, not improvised.

- **Definition of Done additions** — an increment is not done unless: no fail-open shapes introduced (E9), and every per-agent prompt captured verbatim (E10).

Full mechanical gate list is E1-E10 in `enforcement-kit.md`; the reusable roles (build + red-team) and the composition standard are in `personas.md`.

---

## The 30-second pitch for a skeptical teammate

You already review PRs. This adds two things review misses: a **domain expert who looks for what the plan got wrong** and a **skeptic who lists what is entirely missing** — run every iteration, forced to produce findings — plus **mechanical gates** so the fixes stick (a stub can't masquerade as real, a seam can't fail open, a legacy debt can't grow). It is heavier than a solo build; the payoff is that the expensive, silent gaps get caught by process instead of by your customer.
