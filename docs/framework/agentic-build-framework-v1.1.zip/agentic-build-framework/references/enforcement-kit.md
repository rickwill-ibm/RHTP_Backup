# Enforcement Kit (project-agnostic)

Gates over prose. A rule that lives only in a document gets skipped under pressure; a rule wired into CI or a test cannot be. Each pattern below is the mechanical form of a lesson learned the hard way. Adopt the gate, not just the principle.

## E1 — Fail-closed seam gate (prevents load-bearing stubs from masquerading)
Problem it prevents: a stub that fails OPEN (returns a plausible value in production), masquerades as the real thing, or is dead wiring (a "production" seam no caller actually selects). This class ships silently and is only caught by manual audit.
The gate:
- A seam-disposition manifest declares, for EVERY configurable seam, its production disposition: `real-impl` (a real production implementation is wired), `fail-closed-stub` (production throws a NotConfiguredError until wired), or `mock-only` (a demo-only seam, inert in production).
- A governance test enumerates every seam actually used in the code and asserts each has a manifest entry — so a NEW seam with no declared disposition FAILS CI. This forces every future seam to declare fail-closed vs real.
- For each `fail-closed-stub`: the test drives its production path unconfigured and asserts it THROWS (never returns a value).
- For each `real-impl`: the test asserts production does NOT fall back to the mock/in-memory implementation (the dead-wiring class).
- A companion test asserts no dev/mock/fallback flag defaults to ON, and that such a flag cannot be active when real infrastructure is configured.
Adoption: one manifest file + two test files. The house rule becomes: a new seam either uses the fail-closed NotConfigured pattern or the gate goes red.

## E2 — Quality ratchet (prevents regression on legacy debt without blocking new work)
Problem it prevents: a mid-project standard that would fail thousands of pre-existing lines, so it gets ignored.
The gate: a committed baseline records today's violation set (file sizes, `any` counts, etc.). CI fails only on a NEW violation or GROWTH in a baselined item. The baseline may only shrink, and only in a refactor-only change. New code is always fully compliant; legacy is frozen, not fixed, until deliberately remediated.
Adoption: a size/lint script that reads a `quality-baseline.json`; regenerate only with `--write-baseline` in a refactor-only PR. Verify the gate with a negative test (grow a frozen file, confirm CI fails).

## E3 — Namespace pre-allocation + pinning test (prevents parallel-agent collisions and drift)
Problem it prevents: parallel agents cannot see each other's registrations, so two invent the same id, or one id is spelled differently across the code / a manifest / a routing table and drifts silently.
The gate: the spine reserves ids up front (module paths, seam/flag ids, event/type names) in the iteration context. A pinning test asserts all SURFACES that reference an id agree (the code constant, the manifest entry, the registry, the routing table). Reserving is necessary but not sufficient — the pinning test is what catches the multi-surface drift.
Adoption: a reserved-namespace table in the iteration brief + a `namespaceIntegrity` test updated as each domain/component lands.

## E4 — DRY convergence loop (prevents "cleanup" from being skipped or shallow)
Problem it prevents: treating convergence as optional polish, when it is where the material defects actually surface.
The gate: convergence is a first-class, budgeted wave every iteration, and it repeats until a full re-sweep finds fewer than 3 new material defects AND all gates pass (DRY). Two consecutive clean-enough sweeps end it. Its explicit target is cross-agent assumptions.
Adoption: a convergence wave in every iteration template with a DRY/NOT-DRY verdict as a required output.

## E5 — Authoritative gate owned by the orchestrator (prevents trusting self-reported green)
Problem it prevents: a sub-agent reports "all tests pass" but ran a stale or partial suite; six agents each report green but their merge is red.
The gate: the orchestrator (not any sub-agent) runs the single authoritative type-check + full test suite + size/lint gate after every wave and before every sync. An agent's self-report is a hint, never the truth.
Adoption: an orchestrator checklist; never advance a phase on a sub-agent's word.

## E6 — Artifact-existence verification (prevents phantom completion)
Problem it prevents: an agent reports success while a harness fault meant zero files were written.
The gate: an agent's "done" is accepted only when its named output files exist on disk with plausible content. A cheap harness PROBE runs before every fan-out (one agent exercises read/write/exec); fan-out proceeds only on a clean probe.
Adoption: a probe step + a file-existence check at each phase boundary.

## E7 — Two progress numbers (prevents "tests green" from implying "production-proven")
Problem it prevents: a high passing-test count that is mostly against fakes, read as production-readiness.
The gate: always report BOTH (a) tests passing and (b) count of components whose LIVE-integration spec has actually executed against real infrastructure. When (b) is 0, that is the honest maturity ceiling. Fakes carry a fidelity ledger naming what they do not model, and the live spec is a required (if deferred) CI gate for exactly those properties.
Adoption: a two-number line in every status report + a `FAKE_FIDELITY.md` per fake + Docker-guarded integration specs that skip-with-reason.

## E8 — Living risk register (prevents findings from evaporating)
Problem it prevents: a review finds gaps that are acknowledged and then forgotten.
The gate: one cumulative register (Gap & Stub Risk Register). Every red-team finding lands there with a disposition: Unacceptable = fixed this iteration; Critical/High = owning iteration or backlog; Med = revisit. Every iteration READS it (open Criticals get pulled in) and UPDATES it (new findings, closed items). It is both an input and an exit artifact.
Adoption: a single register file, reviewed at iteration start and updated at iteration end.

## E9 — Fail-open lint (prevents the recurring highest-severity finding class)
Problem it prevents: fail-open defaults — a config/mode/auth path that returns a plausible value instead of failing closed. This class recurred across three separate red-team passes (a validator defaulting open, a dev-auth flag defaulting on, an X12 code defaulting to "active"), each caught by hand. A recurring finding class that a review keeps catching is a candidate for a gate.
The gate: a lint/test that flags the fail-open shapes — a `?? <default>` or `|| <default>` on a config/mode/auth/status value, a `catch` that neither rethrows nor logs, and any dev/mock/fallback flag whose default is on. Each hit must be justified inline or it fails CI. Pairs with E1 (E1 proves seams throw in production; E9 catches the fail-open shape before it reaches a seam).
Adoption: an eslint rule or a grep-based CI check over `src/`, with an allowlist for genuinely-safe defaults. Promote it the moment the red-team catches the same class twice.

## E10 — Verbatim prompt provenance (prevents lossy prompt records)
Problem it prevents: logging a SUMMARY of each agent prompt instead of the prompt itself, so the actual instruction cannot be reviewed or improved. A summary hides exactly the structure a prompt-quality review needs.
The gate: every per-agent prompt is captured VERBATIM at send-time to a provenance store (build-provenance/verbatim/), and the master prompt log references the verbatim file rather than restating a condensed version. The master log carries metadata (seq, iteration, wave, phase, role, domain, depends_on chain); the verbatim store carries the exact text. Never let the analyzable log's prompt field be a lossy summary.
Adoption: a per-iteration verbatim file appended as each agent is invoked; the master CSV's prompt column points to it. Composed prompts (persona standard) make this cheap because the reusable blocks are stable and only SCOPE varies.

## Definition of Done (the composite gate every increment must pass)
- Types clean, full test suite green (orchestrator-run, E5), size/ratchet gate pass (E2).
- Every new file within limits, feature-first, deterministic (clock/rng injected), fail-closed seams declared (E1).
- Namespace pinned (E3); convergence DRY (E4); harness probe was clean and artifacts exist (E6).
- Two progress numbers reported; fakes carry fidelity ledgers (E7).
- Red-team panel ran; register updated; zero new Unacceptable stubs (E8 + panel).
- No fail-open shapes introduced (E9); every per-agent prompt captured verbatim (E10).
- One sync per boundary; recovery point current.
