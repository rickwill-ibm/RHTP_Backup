# Operating Model (project-agnostic)

The orchestration mechanics that make a multi-agent build reliable. These are the rules the orchestrator follows across every iteration. They were learned by hitting each failure once; adopt them to skip the lesson.

## The execution unit: the WAVE
Every iteration is a sequence of waves, and every wave has the same shape:

  probe -> parallel build (2-4 specialists on DISJOINT trees) -> convergence -> red-team panel -> orchestrator authoritative gate -> one sync

Scale by ADDING waves, never by widening a single agent's scope. Disjoint trees are what make parallelism safe; the spine's namespace reservation is what keeps them disjoint.

## Iteration lifecycle
1. BRIEF: the orchestrator writes an iteration context that carries: the binding governance (rules, contracts, direction), the PRE-ALLOCATED namespace, the definition of done, the fidelity/infra reality (what is verified against fakes vs live), and the open register items to pull in.
2. PROBE: a cheap harness health check before any fan-out.
3. SPINE (when decisions are needed): decide, publish contracts, reserve namespace, author the golden path, AND publish a per-agent CONTEXT MANIFEST for each planned specialist (exact reads, what-not-to-touch, the reserved namespace slice INCLUDING shared-file partitions — e.g. per-wave companion test files — so two parallel agents never improvise how they split a shared file).
4. BUILD WAVES: specialists in parallel on disjoint trees. Each agent's prompt is COMPOSED (persona card + brief reference + its context manifest + scope + DoD reference + output contract), not hand-authored, and captured verbatim at send-time (E10).
5. CONVERGENCE: first-class, cross-agent adversarial reconciliation, to DRY.
6. RED-TEAM PANEL: domain-fidelity + negative-space + stub-legitimacy (+ engineering), producing findings into the register; Unacceptable fixed now.
7. AUTHORITATIVE GATE: the orchestrator re-runs types + full tests + size/lint itself.
8. SYNC: one artifact (a single archive) to durable storage at the boundary; update the recovery point and register.

## The operating rules (generalized)
- Trust artifacts, not reports. An agent's "done" holds only when its files exist with plausible content.
- Probe before fan-out. Seconds spent here prevent a whole failed wave.
- Fall back down the orchestration ladder (scripted -> direct parallel calls -> inline) on the FIRST infrastructure failure, rather than retrying the broken layer.
- Durable inputs. Any human-supplied artifact is copied into durable, versioned storage the moment it arrives; conversation context is not storage.
- Checkpoint at boundaries. Each phase's outputs are synced before the next begins; the sync IS the recovery point.
- Keep external dependencies off the critical path. If a sync/commit channel is unreliable, queue it and continue; never block work on it.
- Prose files over rigid schemas for rich agent output. Reserve strict schemas for tiny verdict tuples; rich content forced through a schema fails where a prose file plus a mechanical rule succeeds.
- Pre-allocate AND pin the namespace (E3) — including SHARED-FILE PARTITIONS, not just names: when two parallel agents must both edit one file (a shared registry, a namespace test), the spine pre-declares how they split it (e.g. per-wave companion files), so the partition is designed, not improvised mid-run.
- Compose per-agent prompts from reusable parts and capture them verbatim (persona standard + E10).
- Route cross-cutting findings to a single decisive amendment (the spine reconvened with context intact), not to parallel re-runs.
- One canonical baseline/register; the orchestrator owns the authoritative gate run; agents verify only their own scope.

## The build lessons (generalized, the "do not relearn these")
- Fakes are necessary, not sufficient: they hide concurrency, constraints, and protocol semantics. Fidelity ledger + a required (deferred) live spec (E7).
- Convergence is first-class and finds the real defects; budget it every time (E4).
- Concurrency correctness belongs in the definition of done, not discovered later.
- Templatize the repeatable unit before mass-producing it (build one golden example + checklist, then each instance is a fill-in).
- Verification attacks THREE layers, not one: conformance (does code match spec), domain-fidelity (is the spec right against reality), and negative-space (what is entirely absent). Conformance-only review is how honestly-labeled but load-bearing gaps ship. The red-team panel is this control.
- A labeled stub is not automatically acceptable; grade every stub, fix the load-bearing ones now (E1 + R3).

## When to use this framework
Any build where: work is decomposed across multiple agents; correctness matters more than speed; the domain has real-world standards a generalist engineer would not know; and the cost of a silent gap shipping is high. It is heavier than a single-agent build — the payoff is that the failure modes above are caught structurally rather than by luck or by the customer.

## When NOT to over-apply it
A trivial or throwaway task does not need the full wave unit. Scale the ceremony to the stakes: a one-file fix needs the gate, not a red-team panel. The judgment call is the orchestrator's.
