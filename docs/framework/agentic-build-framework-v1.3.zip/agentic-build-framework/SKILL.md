---
name: agentic-build-framework
description: A project-agnostic framework for reliable multi-agent software builds — the operating model, execution unit (the wave), agent persona library (build roles plus a red-team verification panel), and a mechanical enforcement kit (fail-closed seam gate, quality ratchet, namespace pinning, DRY convergence, living risk register). Use when orchestrating a multi-agent build or hardening/verification pass, when a build must meet real-world domain standards a generalist would miss, or when setting up red-team/adversarial review of agent-produced code. Triggers include: multi-agent build, agent coalition, red team review, adversarial verification, harden a codebase, verification panel, stub audit, "what else is missing", agentic engineering process.
---

# Agentic Build Framework

A reusable operating framework for building software with a coalition of agents, verifying it adversarially, and enforcing quality mechanically. Extracted from a large healthcare-platform build; written to apply to any project.

Version 1.3 — adds R5, the Verification / Cross-Examiner adversary (a fifth red-team persona whose target is the review itself: it hostilely re-reads every prior supported/fixed/closed/green claim and returns an UPHOLD or DEMOTE verdict, the standing form of "we keep finding gaps a normal review missed"), and E12, the claim-vs-evidence gate (every CLOSED/supported item must cite a live passing test, mechanizing what R5 judges). The red-team panel is now five personas and the composite DoD requires E12. Version 1.2 — adds E11 provenance completeness + maintenance: the master prompt log is emitted by ONE generator, covers EVERY agent across ALL phases (planning coalition incl. the use-case and testing agents, build, convergence, red-team), records lineage including dynamic re-prompts, and is regenerated + re-synced every iteration as a DoD step with a mechanical completeness check — so the provenance store cannot silently go stale or partial. Version 1.1 added: the Prompt Composition Standard (per-agent prompts composed from persona cards + brief + a per-agent context manifest, not hand-authored); E9 fail-open lint (promote the recurring fail-open finding class to a gate); E10 verbatim prompt provenance (capture the actual prompt, never a lossy summary); and the L3 refinement (pre-allocate shared-file partitions, not just names).

## The core idea
Multi-agent builds fail in a specific way: the build agents and even the convergence pass verify CONFORMANCE TO THE PLAN, so a gap that the plan itself missed — a naive design, a load-bearing stub, an entirely absent capability — ships even though everyone was honest. The fix is structural, in four layers:

1. **Operating model** — how the orchestration runs (see `references/operating-model.md`): the wave as the execution unit, and the rules that make it reliable (trust artifacts not reports, probe before fan-out, pre-allocate namespace, checkpoint at boundaries, one authoritative gate).
2. **Persona library** — who does the work (see `references/personas.md`): BUILD personas (orchestrator, spine/architect, specialist, convergence) and a RED-TEAM panel (domain-fidelity, negative-space, stub-legitimacy, engineering). The red-team panel is the control that catches what conformance review cannot.
3. **Enforcement kit** — what makes it stick (see `references/enforcement-kit.md`): mechanical gates E1–E12, because a rule in a document gets skipped under pressure but a rule in CI cannot. Fail-closed seam gate, quality ratchet, namespace pinning, DRY convergence, authoritative gate, artifact-existence probe, two progress numbers, living risk register, fail-open lint, verbatim prompt provenance, and provenance completeness + maintenance.
4. **Definition of Done** — the composite gate every increment passes (end of the enforcement kit).

## How to use it on a project
1. Read all three reference files. They are project-agnostic; fill the {DOMAIN} placeholder with your field and pick the R1 domain-fidelity specialty to match.
2. Set up the enforcement gates FIRST (they are cheap and they are what prevents recurrence): the seam-disposition manifest + fail-closed test (E1), the quality ratchet (E2), and the risk register (E8). These are one-time and pay off every iteration.
3. Run each iteration as a wave sequence (operating model): brief with a pre-allocated namespace, probe, spine if decisions are needed, parallel specialists on disjoint trees, convergence to DRY, then the RED-TEAM PANEL, then your own authoritative gate, then the PROVENANCE CLOSE-OUT (append this iteration's rows to the log generator — every agent that ran, including the planning agents if not yet captured — regenerate the master log CSV/XLSX, set lineage, run the completeness check, E11), then one sync. The provenance close-out is not optional and not a manual habit: an iteration that closes without it has a stale log and fails the DoD.
4. The red-team panel is not optional and every persona must produce findings — "looks fine" is a failed review. Route findings to the register: Unacceptable fixed now, Critical/High to an owning iteration or backlog.
5. Run the panel RETROACTIVELY whenever anyone intuits "what else is missing" — it converts intuition into an enumerated list.

## The single most important habit
Verification attacks three layers, not one: does the code match the spec (conformance), is the spec right against real-world domain practice (domain-fidelity), and what is entirely absent that a production version must have (negative-space). A team that only checks conformance will ship honestly-labeled, load-bearing gaps — and only a domain expert or the customer will notice, too late. The red-team panel plus the fail-closed seam gate turn that failure mode from a matter of luck into a matter of process.

## Files
- `references/operating-model.md` — the wave, the lifecycle, the orchestration rules and build lessons.
- `references/personas.md` — the reusable build + red-team persona cards.
- `references/enforcement-kit.md` — the mechanical gates E1-E12 and the composite Definition of Done.
