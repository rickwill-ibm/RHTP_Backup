# Provenance store — how to stand it up (E10 + E11)

The provenance store is the analyzable record of **which agent ran, in what order, with what exact prompt, and why** — the raw material for improving how you generate agents. It is a *review artifact*, not product code, so keep it OUTSIDE `src/` (e.g. `docs/build-provenance/`).

Two layers, one store:
- **E10 — verbatim prompts.** The exact text sent to each agent, captured at send-time under `verbatim/`.
- **E11 — the master log + its maintenance.** One analyzable row per agent invocation, emitted by a single generator, kept complete and current by a mechanical check.

This folder is a **working reference implementation** you can copy into a project and adapt.

---

## Files

- **`build_log.py`** — the single generator. It owns every row and emits `PROMPT_MASTER_LOG.csv` (analyzable) + `PROMPT_MASTER_LOG.xlsx` (readable, phase-colored, with a roster-index sheet). To add agents you **edit this file and re-run it** — never hand-edit the CSV.
- **`check-provenance.sh`** — the E11 gate. Run it at every iteration close and in CI.

> The paths near the top of `build_log.py` (and the `cd` in `check-provenance.sh`) point at the store directory. Change those to your project's provenance path; everything else is project-agnostic structure.

---

## The row schema

Tracking + linkage ids come first, then lineage, then the agent + its work:

| column | meaning |
|---|---|
| `seq` | integer row number (used by `depends_on`) |
| `step_id` | monotonic step-in-sequence key, zero-padded (`0001`…) |
| `trace_id` | unique, self-describing invocation handle, e.g. `TRC-<iter>-<wave>-<seq>` |
| `ts` | ISO-8601 timestamp — real send-time for live rows; deterministic synthetic-monotonic for historical rows |
| `iteration`, `wave`, `phase` | where in the build this invocation sits (`phase` ∈ plan/probe/build/convergence/red-team/fix) |
| `depends_on`, `builds_on` | lineage: what this row followed; cross-iteration functional links |
| `agent_role`, `agent_label` | who ran |
| `workstream_domain` | what it worked on |
| `prompt_summary` | one-line summary **plus a pointer** to the verbatim file (never a lossy stand-in for it) |
| `key_inputs`, `output_summary`, `gate_result`, `findings` | what it consumed / produced / how it gated |
| `fidelity` | `live` (captured as it ran) · `recon` (faithfully reconstructed) · `pending` (scheduled, not yet run) |
| `review_note` | prompt-quality / lineage observations for improving future generation |

**Timestamps must be deterministic in the generator** (never `now()`), or the E11 regeneration check can never be byte-stable. Historical rows use a fixed synthetic anchor; live rows pass a real send-time via `ts_override=` on the `add(...)` call, which wins.

---

## The four E11 rules (what the check enforces)

1. **Single generator, one source of truth** — regenerating reproduces the committed CSV exactly. A hand-edit or an un-generated iteration makes the diff red.
2. **Every agent, every phase** — planning coalition included (evidence, spine, specialists, the use-case/acceptance agent, the planning adversarial reviewer, data/spec authors, finalizer), plus build, testing, convergence, and red-team. A phase that ran with no rows is a failed gate.
3. **Lineage set, including dynamic re-prompts** — a re-prompt is its own row pointing at the row that triggered it.
4. **Regenerate + re-sync every iteration** — part of the Definition of Done, like updating the risk register.

---

## Iteration close-out (the habit that keeps it alive)

At the end of each wave/iteration:

```bash
# 1. add this iteration's rows to the generator (edit build_log.py: one add(...) per agent,
#    with depends_on set; pass ts_override= for live send-times)
# 2. regenerate
python3 build_log.py
# 3. run the gate (optionally pass the repo root to also check wave-report coverage)
bash check-provenance.sh /path/to/repo
# 4. commit CSV + XLSX + generator + any new verbatim/ files
```

A `PASS` line means the log is complete and current. Treat any `FAIL` exactly like a failing test: fix before the iteration is declared closed. A `pending` note is fine mid-iteration but must be resolved (run it, or drop the row) before close.
