import csv
# ============================================================================
# PROMPT MASTER LOG - single source of truth for every build-time agent.
# One row per agent invocation, across BOTH phases:
#   Phase P  = Planning coalition (produced the D1-D7 plan, the 70-use-case
#              corpus, the ADRs/contracts). Recon fidelity - these ran before
#              E10 verbatim capture existed; metadata is exact, prompts condensed.
#   Phase B  = Build iterations 0..8A-i. Live fidelity from I1 on; I0/V recon.
# fidelity: "live"=logged as it ran (verbatim file exists from I7+); "recon"=
#   reconstructed faithfully from summaries/wave reports; "pending"=scheduled,
#   not yet executed.
# ============================================================================
COLS = ["seq","iteration","wave","phase","agent_role","agent_label","workstream_domain",
        "prompt_summary","key_inputs","output_summary","gate_result","findings","fidelity","review_note"]

R = []
def add(**k):
    row = {c: k.get(c,"") for c in COLS}
    row["seq"] = len(R)+1
    # optional explicit lineage (used by the planning phase, which has bespoke deps)
    row["depends_on"] = k.get("depends_on","")
    row["builds_on"]  = k.get("builds_on","")
    row["ts_override"] = k.get("ts_override","")  # real send-time for live rows; blank -> synthetic monotonic ts
    R.append(row)

# ===========================================================================
# PHASE P - PLANNING COALITION (genesis; produced the plan package + corpus)
# Dependencies are set EXPLICITLY here because planning is a DAG, not the
# probe->build->converge cadence of the build iterations.
# ===========================================================================
add(iteration="P",wave="0",phase="probe",agent_role="evidence",agent_label="P1-repo-gate-evidence",workstream_domain="planning/evidence",
    prompt_summary="Phase-0 probe of the sibling repos; assemble the evidence pack + use-case steps that ground the plan.",
    key_inputs="sibling repos; owner intent",output_summary="phase0_repo_gate.md, evidence.md, use_case_steps.md",gate_result="grounded",fidelity="recon",
    depends_on="",builds_on="genesis: grounds the whole plan in real repo evidence",
    review_note="P-phase agents were not captured verbatim (pre-E10); metadata exact, prompt condensed. This roster row makes them visible in the log.")
add(iteration="P",wave="spine",phase="plan",agent_role="spine",agent_label="P2-spine",workstream_domain="planning/architecture",
    prompt_summary="Author ADR-001..006, contracts C1..C10, the golden path, the 16-step trace matrix, and a per-specialist context manifest.",
    key_inputs="P1 evidence; owner constraints",output_summary="load-model, adrs, contracts, golden-path, trace-matrix, manifests",gate_result="authored",fidelity="recon",
    depends_on="1",builds_on="the architectural spine every specialist inherits",
    review_note="The spine is the shared context the 5 specialists branch from - the planning analogue of an iteration probe.")
add(iteration="P",wave="spec",phase="plan",agent_role="specialist",agent_label="P3-graph-context-G1",workstream_domain="planning/graph",
    prompt_summary="Design the graph projector, mapping specs, and lens queries (G1).",
    key_inputs="P2 spine",output_summary="g1-graph.md",gate_result="authored",fidelity="recon",depends_on="2",builds_on="feeds the iter2 graph build",
    review_note="One of 5 parallel design specialists on disjoint concerns.")
add(iteration="P",wave="spec",phase="plan",agent_role="specialist",agent_label="P4-pipeline-fhir-G3X2",workstream_domain="planning/pipeline",
    prompt_summary="Design the 5-stage pipeline, adapters, outbox, and validation (G3/X2).",
    key_inputs="P2 spine",output_summary="g3-pipelines.md",gate_result="authored",fidelity="recon",depends_on="2",builds_on="feeds the iter1 pipeline+outbox build",
    review_note="Parallel design specialist.")
add(iteration="P",wave="spec",phase="plan",agent_role="specialist",agent_label="P5-agentic-G2G4",workstream_domain="planning/agentic",
    prompt_summary="Design the SDE and the agent runtime (G2/G4).",
    key_inputs="P2 spine",output_summary="g2g4-agentic.md",gate_result="authored",fidelity="recon",depends_on="2",builds_on="feeds the iter2 SDE + iter3 runtime builds",
    review_note="Parallel design specialist.")
add(iteration="P",wave="spec",phase="plan",agent_role="specialist",agent_label="P6-careplan-G5",workstream_domain="planning/care-plan",
    prompt_summary="Design care-plan hardening + the DP-4 acceptance oracle (G5).",
    key_inputs="P2 spine",output_summary="g5-careplan.md",gate_result="authored",fidelity="recon",depends_on="2",builds_on="feeds the iter0 care-plan hardening",
    review_note="Parallel design specialist.")
add(iteration="P",wave="spec",phase="plan",agent_role="specialist",agent_label="P7-documentation-X4",workstream_domain="planning/docs",
    prompt_summary="Design the D7 doc pack + the honesty ledger (X4).",
    key_inputs="P2 spine",output_summary="x4-documentation.md",gate_result="authored",fidelity="recon",depends_on="2",builds_on="feeds the D7 doc pack",
    review_note="Parallel design specialist.")
add(iteration="P",wave="use-case",phase="plan",agent_role="use-case-expert",agent_label="P8-TCOC-70-use-case-expert",workstream_domain="planning/verification-corpus",
    prompt_summary="ACT AS TCOC SME PANEL (10 specialty lenses): devise the 70-use-case verification corpus that the platform must satisfy - families A-O, each with actor, trigger, expected orchestration, and TCOC lever. THIS IS THE 70-USE-CASE AGENT.",
    key_inputs="P1 evidence; P2 golden path; 10 SME lenses",output_summary="use_case_corpus.md - 70 cases, families A-O",gate_result="authored",fidelity="recon",
    depends_on="2",builds_on="the corpus later becomes executable scenario tests at I0 wave 3B",
    review_note="<< The 70-use-case agent you asked about. Its OUTPUT (use_case_corpus.md) is committed; its prompt lives in the transcript. Downstream: seq for I0/3B corpus-scenario turns it into runnable tests.")
add(iteration="P",wave="adversarial",phase="red-team",agent_role="red-team",agent_label="P9-adversarial-rubric-panel",workstream_domain="planning/review",
    prompt_summary="Adversarially score all 5 design specialists against a rubric; surface cross-cutting findings the specialists missed on their own.",
    key_inputs="P3-P7 specialist designs; P8 corpus",output_summary="adversarial-verdict.md - 3 cross-cutting findings (C1 orphan, ADR-006 atomicity, compliance orphans)",gate_result="findings",fidelity="recon",
    depends_on="3,4,5,6,7,8",builds_on="the FIRST adversarial pass - the ancestor of the R1-R4 red-team personas",
    review_note="The planning-phase red team. Its 3 findings triggered a DYNAMIC RE-PROMPT of the spine (next row).")
add(iteration="P",wave="amend",phase="fix",agent_role="spine",agent_label="P10-spine-amendment-REPROMPT",workstream_domain="planning/architecture",
    prompt_summary="RECONVENE the spine agent WITH CONTEXT INTACT (SendMessage): resolve the 3 adversarial findings - C1 orphan, ADR-006 atomicity, compliance orphans.",
    key_inputs="P9 findings; P2 spine (same agent, context retained)",output_summary="amendment-001.md",gate_result="resolved",fidelity="recon",
    depends_on="9",builds_on="<< DYNAMIC RE-PROMPT LINEAGE: P2 spine -> P9 adversarial findings -> P10 same-agent re-prompt -> amendment. The clearest multi-turn lineage in the whole build.",
    review_note="THIS is the lineage you asked about: an agent re-prompted with updated context (its own prior output + the red-team findings), not a one-shot. Chain: seq2 -> seq10.")
add(iteration="P",wave="data",phase="plan",agent_role="data",agent_label="P11-data-extractor-D1",workstream_domain="planning/datasets",
    prompt_summary="Build the D1 workbook datasets (5 sheets incl. the 70-case trace matrix) from the resolved plan.",
    key_inputs="P8 corpus; P10 amended spine",output_summary="sheet1-5.json -> D1_Gap_Matrix.xlsx",gate_result="authored",fidelity="recon",depends_on="8,10",builds_on="materializes the 70-case corpus as the D1 trace sheet",
    review_note="")
add(iteration="P",wave="data",phase="plan",agent_role="spec-author",agent_label="P12-spec-author-D4D5",workstream_domain="planning/specs",
    prompt_summary="Author the D4 load-test spec + the D5 deployment-config spec.",
    key_inputs="P10 amended spine",output_summary="D4_load_test_spec.md, D5_deployment_config_spec.md",gate_result="authored",fidelity="recon",depends_on="10",builds_on="the specs iterations 9-10 will execute",
    review_note="")
add(iteration="P",wave="final",phase="fix",agent_role="orchestrator",agent_label="P13-finalizer",workstream_domain="planning/assembly",
    prompt_summary="Assemble + QA the D1-D7 plan package; commit. Hand the plan to the build phase.",
    key_inputs="all P outputs",output_summary="docs/production-plan/D1-D7 committed",gate_result="committed",fidelity="recon",depends_on="10,11,12",builds_on="the plan package that the build phase (I0) inherits",
    review_note="Bridge from planning to build: I0's probe depends on this row.")

# ===========================================================================
# PHASE B - BUILD ITERATIONS
# ===========================================================================
# ---------- Iteration 0 - Hardening (cycles 1-3) ----------
add(iteration="0",wave="probe",phase="probe",agent_role="probe",agent_label="cycle1-probe",workstream_domain="harness",
    prompt_summary="Harness health probe: echo, write, edit a file; confirm tool access before fan-out.",
    key_inputs="baseline tree",output_summary="tools working",gate_result="clean->fanout",fidelity="live",
    review_note="E6 probe standard; cheap insurance before parallel build.")
add(iteration="0",wave="1A",phase="build",agent_role="specialist",agent_label="mechanical-sweeper",workstream_domain="persona/determinism/logging",
    prompt_summary="Four sweeps: purge persona-in-logic, inject clock/rng in engines, structured PHI-safe logger over console.log, silent-catch audit.",
    key_inputs="conventions v2; evidence.md",output_summary="2 logic fixes; 31 files determinism seam; logger; 0 console.log",gate_result="tsc0; ratchet ok",fidelity="recon",
    review_note="Grep-driven cleanup framed as defect classes worked; classify data-vs-logic to avoid touching legit demo data.")
add(iteration="0",wave="1B",phase="build",agent_role="specialist",agent_label="route-test-author",workstream_domain="bff-routes",
    prompt_summary="TESTING AGENT: cover all 21 API routes: 401/403/400/422/200 + PHI-safe body; skip infra-bound with reason.",
    key_inputs="route handlers; _helpers pattern",output_summary="107 route tests, 9 named skips",gate_result="green",fidelity="recon",
    review_note="<< Testing agent (route). Test-file-only (no src edits) kept it disjoint from the sweeper.")
add(iteration="0",wave="1-conv",phase="convergence",agent_role="convergence",agent_label="cycle1-convergence-x2",workstream_domain="cross-cutting",
    prompt_summary="Re-sweep determinism/console/persona; review mode-registry; converge to DRY (2 passes).",
    key_inputs="cycle1 reports",output_summary="determinism stragglers + demoDefaults; DRY on 2nd pass",gate_result="DRY",fidelity="recon",
    review_note="Two passes needed; convergence found what build waves missed.")
add(iteration="0",wave="1-2",phase="build",agent_role="specialist",agent_label="mode-registry",workstream_domain="config/dataMode",
    prompt_summary="Consolidate scattered mock toggles into one config-driven dataMode registry (mock|seeded|production per seam).",
    key_inputs="runtimeConfig; consent seam",output_summary="dataMode.ts + session override; consent+fhir wired",gate_result="green",fidelity="recon",
    review_note="This became the mock->production switch mechanism the owner later relied on.")
add(iteration="0",wave="2A",phase="build",agent_role="specialist",agent_label="property-test-author",workstream_domain="engines",
    prompt_summary="TESTING AGENT: property tests for match/policy/adequacy/goldenThread/consent engines; ~3000 generated cases via seeded PRNG.",
    key_inputs="engine source",output_summary="found REAL match bug: blank/whitespace fields -> false matches",gate_result="green (2 it.fails)",fidelity="recon",
    review_note="<< Testing agent (property). Earned its place immediately; caught a patient-safety defect.")
add(iteration="0",wave="2B",phase="build",agent_role="specialist",agent_label="careplan-hardening",workstream_domain="care-plan",
    prompt_summary="Extract 1262-line frozen generator into carePlan/ modules; DP-4 acceptance oracle (fixtures+invariants).",
    key_inputs="carePlanGenerator*; g5 design",output_summary="14 modules; frozen files 1269->66 lines; 47 tests; 9 findings",gate_result="green",fidelity="recon",
    review_note="Ratchet moved forward: legacy files shrank via extraction, not edits.")
add(iteration="0",wave="2-conv",phase="convergence",agent_role="convergence",agent_label="cycle2-convergence",workstream_domain="identity",
    prompt_summary="Fix the blank-field match bug family across deterministic + probabilistic tiers; flip it.fails.",
    key_inputs="cycle2a findings",output_summary="guard non-empty both sides; regression tests",gate_result="DRY",fidelity="recon",
    review_note="Fixed a real correctness bug found by property tests, not weakened the test.")
add(iteration="0",wave="3A",phase="red-team",agent_role="red-team",agent_label="security-lens",workstream_domain="api-security",
    prompt_summary="Attack all routes: authz bypass, consent scoping, PHI in errors, IDOR, input validation, AI-guardrail.",
    key_inputs="api routes; authz",output_summary="2 HIGH (consent-read bypass, IDOR); fixed match consent gate",gate_result="green",fidelity="recon",
    review_note="First real adversarial security pass; found the IDOR class later fully closed in I3.")
add(iteration="0",wave="3B",phase="build",agent_role="specialist",agent_label="corpus-scenario",workstream_domain="verification",
    prompt_summary="TESTING AGENT: turn the 70-case corpus (P8 output) into executable scenario tests where code exists; register the rest as pending.",
    key_inputs="use_case_corpus.md (P8)",output_summary="15 runnable, 55 pending, all 70 accounted",gate_result="green",fidelity="recon",
    depends_on="",builds_on="consumes P8's 70-use-case corpus - the planning->build link for the use cases",
    review_note="<< Testing agent (corpus). This is where P8's 70 use cases become a living regression asset.")
add(iteration="0",wave="3C",phase="build",agent_role="specialist",agent_label="e2e-a11y-specs",workstream_domain="e2e",
    prompt_summary="TESTING AGENT: author C5 demo walkthrough + dual-mode + axe specs (CI-runnable; live run sandbox-blocked).",
    key_inputs="playwright config; routes",output_summary="20 specs; found + fixed a Next illegal-export bug",gate_result="tsc0",fidelity="recon",
    review_note="<< Testing agent (e2e/a11y). Honest CI-pending labeling; build compiled but dev server would not boot in sandbox.")

# ---------- Iteration 1 - Foundation ----------
add(iteration="1",wave="probe",phase="probe",agent_role="probe",agent_label="iter1-probe",workstream_domain="harness/pg-mem",
    prompt_summary="Probe pg-mem + confirm dataMode/clock/log seams exist.",key_inputs="baseline",output_summary="pg-mem ok",gate_result="clean",fidelity="live",
    review_note="Added infra probe (pg-mem) to the harness check since this iteration needs SQL.")
add(iteration="1",wave="A",phase="build",agent_role="specialist",agent_label="pipeline+outbox",workstream_domain="pipeline/outbox",
    prompt_summary="Five-stage pipeline + 3 adapters (834/ADT/CBO); lane-agnostic transforms; ADR-006 outbox-intent propagation.",
    key_inputs="plan 4A; C2/C10; ADR-006",output_summary="17 modules; outbox intent->confirm->event; 36 tests",gate_result="green",fidelity="live",
    review_note="Adapters generic over records; identity via injected resolver seam (later found to be a stub).")
add(iteration="1",wave="B",phase="build",agent_role="specialist",agent_label="persistence+adapters",workstream_domain="evidence/dataSources",
    prompt_summary="O-1 append-only pg evidence ledger behind seam; O-2 gold-card/denial/provider loaders.",
    key_inputs="ADR-005; evidence interface",output_summary="ledger + immutability trigger; 3 adapters; 31 tests",gate_result="green",fidelity="live",
    review_note="Reused the existing EvidenceStore interface verbatim; no caller changed.")
add(iteration="1",wave="C",phase="convergence",agent_role="convergence",agent_label="security+convergence",workstream_domain="security/outbox",
    prompt_summary="Fix 2 HIGH IDOR/consent; adversarial review of A+B; DRY.",
    key_inputs="cycle3 security report",output_summary="consent-read fixed; flagged multi-writer outbox gaps for I2",gate_result="DRY",fidelity="live",
    review_note="Documented the real-Postgres outbox concurrency gap rather than hiding it (L1 in action).")

# ---------- Iteration 2 - Graph + SDE ----------
add(iteration="2",wave="A",phase="build",agent_role="specialist",agent_label="graph-projector+backends",workstream_domain="graph",
    prompt_summary="Harden outbox (UNIQUE+CAS); store-agnostic projector; Postgres + Neo4j adapters on one interface; shared contract test.",
    key_inputs="ADR-001 v12.3; C10; iter1 outbox",output_summary="projector + both backends; parity proven; 30 tests",gate_result="green",fidelity="live",
    review_note="Step-0 outbox hardening carried the I1 concurrency gap forward (L4 lesson: should have been in I1 DoD).")
add(iteration="2",wave="B1",phase="build",agent_role="specialist",agent_label="lens-suite+replay",workstream_domain="graph/lens",
    prompt_summary="5 lens queries passing on BOTH backends; Part 2 restriction; rebuild-from-replay; merge/unmerge rekey.",
    key_inputs="wave A graph; DP-1",output_summary="dual-backend parity on all 5 lenses + replay + merge",gate_result="green",fidelity="live",
    review_note="Co-equal backend guarantee proven in code, not asserted.")
add(iteration="2",wave="B2",phase="build",agent_role="specialist",agent_label="sde-disposition",workstream_domain="sde",
    prompt_summary="Disposition service: signal taxonomy, act/suppress/delay/bundle, policy-as-data, consent-gated, explainable.",
    key_inputs="DP-2; demo SDE shape",output_summary="5/3/1 shape EMERGES from policy; 26 tests; flagged seam-id collision",gate_result="green",fidelity="live",
    review_note="Agent flagged the sde seam-id collision itself (good), fixed in convergence.")
add(iteration="2",wave="C",phase="convergence",agent_role="convergence",agent_label="iter2-convergence",workstream_domain="graph/sde",
    prompt_summary="Fix seam-id collision; verify projector purity (no SQL/Cypher in core); Part 2 both backends; DRY.",
    key_inputs="B1/B2 reports",output_summary="signalDisposition seam; purity confirmed; DRY",gate_result="DRY",fidelity="live",
    review_note="Seam-id collision is the L3 lesson origin.")

# ---------- Iteration 3 - Agent runtime + IDOR ----------
add(iteration="3",wave="probe",phase="probe",agent_role="probe",agent_label="iter3-probe",workstream_domain="harness",
    prompt_summary="Probe; locate the work-queue store to reuse (no second inbox).",key_inputs="baseline",output_summary="workQueueView found",gate_result="clean",fidelity="live",review_note="Probe located the HITL surface to reuse.")
add(iteration="3",wave="A",phase="build",agent_role="specialist",agent_label="agent-runtime+registry",workstream_domain="agentRuntime/agents",
    prompt_summary="Journey-lane WorkflowEngine + in-memory fake + Temporal seam; manifest registry (data); escalation-as-data; HITL proposeAndWait via work queue.",
    key_inputs="g2g4 design; conventions s10",output_summary="runtime + manifests; FAKE_FIDELITY.md; 26 tests",gate_result="green",fidelity="live",
    review_note="L1 fake-fidelity ledger shipped as a required deliverable for the workflow fake.")
add(iteration="3",wave="A2",phase="build",agent_role="specialist",agent_label="idor-role-model",workstream_domain="authz/principal",
    prompt_summary="Session-principal role model; close evidence + financial-clearance IDOR; remove hardcoded pa-reviewer.",
    key_inputs="cycle3 security; match-route pattern",output_summary="principal model; 2 IDOR it.fails flipped; 24 tests",gate_result="green",fidelity="live",
    review_note="Ran parallel to A on a disjoint tree (authz vs runtime).")
add(iteration="3",wave="B",phase="build",agent_role="specialist",agent_label="three-agents",workstream_domain="agents",
    prompt_summary="Outreach/referral/PA-doc agent behaviors on the runtime; HITL; PA-doc never sets authoritative state.",
    key_inputs="wave A runtime; sde output",output_summary="decide->act->HITL->execute loop reproduced; PA guardrail asserted; 18 tests",gate_result="green",fidelity="live",
    review_note="The AI-guardrail (agent never sets PA state) is tested, not just claimed.")
add(iteration="3",wave="C",phase="convergence",agent_role="convergence",agent_label="iter3-convergence",workstream_domain="agents",
    prompt_summary="Cross-agent namespace integrity; confirm 1 expected-fail is legit; determinism; HITL genuinely suspends.",
    key_inputs="A/A2/B reports",output_summary="found F-C1 namespace drift across 3 surfaces; pinned by test; DRY",gate_result="DRY",fidelity="live",
    review_note="L3 refinement origin: pre-allocate AND pin names across all surfaces.")

# ---------- Iteration 4 - Template + clinical domains + stubs ----------
add(iteration="4",wave="A",phase="build",agent_role="specialist",agent_label="template+medications",workstream_domain="pipeline/medications",
    prompt_summary="Author the L7 domain template + checklist; build medications (prescribed+dispensed) through it.",
    key_inputs="existing adapters; medication FHIR",output_summary="_TEMPLATE.md + medications T1; pinning test; 14 tests",gate_result="green",fidelity="live",
    review_note="Templatize-before-mass-produce (L7); medications stress-tested the two-node shape.")
add(iteration="4",wave="EMPI",phase="build",agent_role="specialist",agent_label="empi-resolver",workstream_domain="identity",
    prompt_summary="OWNER LITMUS: wire the REAL match engine as identity resolver; possible-match 60-90 HELD not auto-linked; demographics-carrying seam.",
    key_inputs="matchEngine; owner directive",output_summary="EMPI resolver; HELD path; 14 tests",gate_result="green",fidelity="live",
    review_note="Owner caught the hash-stub. Prompt folded the fix in-iteration rather than deferring.")
add(iteration="4",wave="B",phase="build",agent_role="specialist",agent_label="labs+allergies",workstream_domain="pipeline/labs/allergies",
    prompt_summary="Build labs-vitals + allergies through the template.",key_inputs="_TEMPLATE.md",output_summary="2 domains T1; 26 tests",gate_result="green",fidelity="live",review_note="First proof the template makes domains a fill-in.")
add(iteration="4",wave="EXT",phase="build",agent_role="specialist",agent_label="external-seams",workstream_domain="identity/terminology",
    prompt_summary="OWNER DIRECTIVE: stub external EMPI (PIX/PDQ, PIXm/PDQm) + terminology/semantic-validation seam (RxNorm/LOINC/HCC) fail-closed.",
    key_inputs="owner directive; NotConfigured pattern",output_summary="external identity + terminology seams; stage-4 semantic gate; 28 tests",gate_result="green",fidelity="live",
    review_note="Stubs now, real later; honest fail-closed stubs, roadmap I8A created. << external EMPI stubs here become REAL at I8A-i wave B.")
add(iteration="4",wave="C",phase="build",agent_role="specialist",agent_label="procedures",workstream_domain="pipeline/procedures",
    prompt_summary="Build procedures through the template.",key_inputs="_TEMPLATE.md",output_summary="procedures T1; 14 tests; record 7/20",gate_result="green",fidelity="live",review_note="")
add(iteration="4",wave="VSM",phase="build",agent_role="specialist",agent_label="value-set-registry",workstream_domain="terminology/registry",
    prompt_summary="OWNER DIRECTIVE: value-set/ontology lifecycle registry across 6 classification families (HCC is one of several).",
    key_inputs="owner directive; terminology seam",output_summary="registry facility; 26 assets/6 families; 16 tests",gate_result="green",fidelity="live",
    review_note="Owner: HCC is only one; behavioral+social families added. Governance-console scoped to I8A.")
add(iteration="4",wave="C-conv",phase="convergence",agent_role="convergence",agent_label="iter4-convergence",workstream_domain="pipeline/identity/terminology",
    prompt_summary="Cross-agent: namespace pin all 4 domains; double gate order; seed covers all demo codes; DRY.",
    key_inputs="6 wave reports",output_summary="1 doc-only finding; DRY; record 7/20",gate_result="DRY",fidelity="live",review_note="Six parallel agents; convergence reconciled cleanly.")

# ---------- Verification round (standing red-team, retroactive on I0-4) ----------
add(iteration="V",wave="panel",phase="red-team",agent_role="red-team",agent_label="domain-fidelity-adversary",workstream_domain="healthcare-standards",
    prompt_summary="[verbatim: verbatim/red-team-and-adversarial-prompts.md R1] Audit I0-4 for naive/stubbed/missing healthcare-standard mechanisms (X12, EMPI survivorship, terminology, Part2, FHIR conformance).",
    key_inputs="summaries + code",output_summary="26 findings (4 Critical incl 834-term, Part2, EMPI survivorship, $validate stub)",gate_result="registered",fidelity="live",
    review_note="R1 persona. Found what conformance review missed; validates L9. Prompt now captured verbatim.")
add(iteration="V",wave="panel",phase="red-team",agent_role="red-team",agent_label="negative-space-adversary",workstream_domain="operability",
    prompt_summary="[verbatim: red-team-and-adversarial-prompts.md R2] Find what is ABSENT that production needs; must produce a missing-list not a pass.",
    key_inputs="summaries + code",output_summary="31 findings (dead-letter drop, right-to-delete, observability, idempotency)",gate_result="registered",fidelity="live",
    review_note="R2 persona. NS-01 (records vanish) drove Iteration 5. Prompt now captured verbatim.")
add(iteration="V",wave="panel",phase="red-team",agent_role="red-team",agent_label="stub-legitimacy-adversary",workstream_domain="stubs",
    prompt_summary="[verbatim: red-team-and-adversarial-prompts.md R3] Grade every seam/stub Acceptable/Risky/Unacceptable; find fail-open/masquerade/dead-wiring.",
    key_inputs="seam code",output_summary="26 graded; 4 Unacceptable (dev-auth fail-open, validator fail-open, EMPI mock-in-prod, evidence dead-wiring)",gate_result="registered",fidelity="live",
    review_note="R3 persona. The 4 Unacceptable were worse than what the owner caught (they mislead). Prompt now captured verbatim.")
add(iteration="V",wave="fix",phase="fix",agent_role="specialist",agent_label="unacceptable-fixes",workstream_domain="seams",
    prompt_summary="Fix the 4 Unacceptable: make each fail CLOSED in production, demo green.",
    key_inputs="stub findings; NotConfigured pattern",output_summary="U1-U4 fixed fail-closed; 22 tests",gate_result="green",fidelity="live",review_note="High-integrity: spotted AND fixed the worst, not just logged.")
add(iteration="V",wave="gate",phase="fix",agent_role="specialist",agent_label="governance-seam-gate",workstream_domain="config/governance",
    prompt_summary="Build mechanical fail-closed gate: seam-disposition manifest + test forcing every seam to declare + prove fail-closed.",
    key_inputs="seam registry",output_summary="17 seams declared; 29 governance tests; new seam with no disposition fails CI",gate_result="green",fidelity="live",
    review_note="E1 enforcement: the durable prevention (gate over prose).")

# ---------- Iteration 5 - Reliability ----------
add(iteration="5",wave="probe",phase="probe",agent_role="probe",agent_label="iter5-probe",workstream_domain="harness",
    prompt_summary="Probe pg-mem; locate quarantine/held-identity producers.",key_inputs="baseline",output_summary="heldIdentity.ts found",gate_result="clean",fidelity="live",review_note="")
add(iteration="5",wave="A",phase="build",agent_role="specialist",agent_label="dead-letter-subsystem",workstream_domain="deadLetter",
    prompt_summary="Durable dead-letter/held-review store (quarantine|held-identity|failed-outbox); wire at call sites so nothing vanishes; ops reviewer surface.",
    key_inputs="NS-01; producers",output_summary="store + ops routes; producers persist; 44 tests; seam declared",gate_result="green",fidelity="live",
    review_note="Closed the Critical operability gap; ops surface distinct from clinical work queue.")
add(iteration="5",wave="B",phase="build",agent_role="specialist",agent_label="idempotency+session-secret",workstream_domain="idempotency/authz",
    prompt_summary="Durable idempotency store (per-consumer CAS); wire SDE+agents; R5 session-secret fail-closed.",
    key_inputs="NS-04; R5",output_summary="idempotency store; SDE+agents dedupe on republish; secret fails closed; 29 tests",gate_result="green",fidelity="live",review_note="")
add(iteration="5",wave="C",phase="red-team",agent_role="convergence+red-team",agent_label="iter5-convergence+panel",workstream_domain="deadLetter/idempotency",
    prompt_summary="[RECONSTRUCTED in red-team-and-adversarial-prompts.md] Converge; then mandatory red-team panel (R1 reliability/data-integrity, R2 negative-space, R3 stub-legitimacy).",
    key_inputs="A/B reports; register",output_summary="found+fixed a re-introduced fail-open drop-path; R1 5/R2 10/R3 3 findings; DRY",gate_result="DRY",fidelity="live",
    findings="R1:5 R2:10 R3:3",
    review_note="Panel caught a re-introduced NS-01 fail-open the build missed. I5 lens=reliability. Prompt reconstructed (pre-E10).")

# ---------- Iteration 6 - Care-team + workflow domains ----------
add(iteration="6",wave="probe",phase="probe",agent_role="probe",agent_label="iter6-probe",workstream_domain="harness",
    prompt_summary="Probe; enumerate current C9 domains; find 834 adapter.",key_inputs="baseline",output_summary="8 domains found (care-team already a graph node)",gate_result="clean",fidelity="live",
    review_note="Probe+scope-enum prevented a duplicate-domain assumption.")
add(iteration="6",wave="A",phase="build",agent_role="specialist",agent_label="careteam+goalstasks",workstream_domain="pipeline/care-team/goals-tasks",
    prompt_summary="Build care-team + goals-tasks through template; EXTEND existing careteam mapping without breaking the I2 lens.",
    key_inputs="_TEMPLATE.md; careteam.ts",output_summary="2 domains T1; lens preserved; 28 tests; namespace split to companion file",gate_result="green",fidelity="live",
    review_note="Shared-file (namespace test) split improvised mid-run; future briefs should pre-declare the partition (L3 refinement).")
add(iteration="6",wave="B",phase="build",agent_role="specialist",agent_label="referrals+immunizations",workstream_domain="pipeline/referrals/immunizations",
    prompt_summary="Build referrals + immunizations through template; keep provider refs RAW + flag deferred-I8A (no invented NPI).",
    key_inputs="_TEMPLATE.md",output_summary="2 domains T1; provider deferred-I8A; 27 tests",gate_result="green",fidelity="live",
    review_note="Keep-unresolved-entity-raw-and-flagged is the durable anti-masquerade clause. << the deferred-I8A provider refs get resolved at I8A-i wave C.")
add(iteration="6",wave="C",phase="red-team",agent_role="convergence+red-team",agent_label="iter6-foldins+panel",workstream_domain="pipeline/deadLetter/834",
    prompt_summary="[RECONSTRUCTED] Fold-ins: idempotency reuse in dead-letter; 834 INS-3 termination fix. Then converge + mandatory red-team panel.",
    key_inputs="register F1+HIGH; wave reports",output_summary="both fold-ins fixed; found+fixed latent 834 fail-open; R1 5/R2 7/R3 3; DRY; record 11/20",gate_result="DRY",fidelity="live",
    findings="R1:5 R2:7 R3:3",
    review_note="Red-team caught a fail-open AGAIN (834 default-to-active). Fail-open is the recurring top class -> candidate mechanical lint E9. I6 lens=care-coordination.")

# ---------- Iteration 7 - Behavioral health + F2 Part 2 + claims/pa + assessments ----------
add(iteration="7",wave="probe",phase="probe",agent_role="probe",agent_label="iter7-probe",workstream_domain="harness",
    prompt_summary="[verbatim: verbatim/iteration-7-verbatim.md] probe; locate Part2 handling + PA state machine.",
    key_inputs="baseline",output_summary="Part2 thin; paMachine found",gate_result="clean",fidelity="live",
    review_note="Probe confirmed Part 2 handling thin (F2).")
add(iteration="7",wave="A",phase="build",agent_role="specialist",agent_label="behavioralHealth+part2",workstream_domain="pipeline/behavioral-health",
    prompt_summary="[verbatim: iteration-7-verbatim.md waveA] BH+SUD domain + real Part2 segmentation (basis, consent-directed, re-disclosure, break-glass).",
    key_inputs="iteration7_context F2 spec",output_summary="BH T1; SUD restricted; break-glass audited; 21 tests",gate_result="green",fidelity="live",
    review_note="HIGH CARE wave; two-factor Part2 basis + over-restriction guard.")
add(iteration="7",wave="B",phase="build",agent_role="specialist",agent_label="claims+paLifecycle",workstream_domain="pipeline/claims/pa-lifecycle",
    prompt_summary="[verbatim: iteration-7-verbatim.md waveB] claims-financial (Claim/ClaimResponse/EOB chain, CARC/RARC) + pa-lifecycle (status lifecycle, non-authoritative).",
    key_inputs="paMachine",output_summary="2 domains T1; PA capture non-authoritative asserted; 34 tests",gate_result="green",fidelity="live",
    review_note="pa-lifecycle references but never drives paMachine (guardrail).")
add(iteration="7",wave="C",phase="build",agent_role="specialist",agent_label="assessments+caregiver+documents",workstream_domain="pipeline/assessments/caregiver/documents",
    prompt_summary="[verbatim: iteration-7-verbatim.md waveC] assessments (QuestionnaireResponse T1) + caregiver (RelatedPerson T1) + documents (DocumentReference T2, honest).",
    key_inputs="_TEMPLATE.md",output_summary="3 domains; documents honestly T2; 39 tests",gate_result="green",fidelity="live",
    review_note="documents T2 not a hidden T1 claim.")
add(iteration="7",wave="D",phase="red-team",agent_role="convergence+red-team",agent_label="iter7-convergence+panel",workstream_domain="pipeline/part2/claims",
    prompt_summary="[verbatim: iteration-7-verbatim.md waveD - FIRST COMPOSED v1.1 PROMPT] convergence + E9 fail-open sweep + red-team (R1=Part2/privacy+financial, R2 negative-space, R3 stub-legitimacy).",
    key_inputs="wave reports; register; framework v1.1",output_summary="E9 found+fixed 2 Unacceptable Part2 fail-opens; R1 8/R2 9/R3 findings; F2 advanced; DRY; record 17/20",gate_result="DRY",fidelity="live",
    findings="R1:8 R2:9 R3:fixed2",
    review_note="First composed-prompt agent (v1.1). E9 standing sweep caught top-severity class on top-stakes surface.")

# ---------- Iteration 8A-i - External identity + EMPI (F3, F5; PIX/PDQ real) ----------
add(iteration="8A-i",wave="probe",phase="probe",agent_role="probe",agent_label="iter8ai-probe",workstream_domain="harness/identity",
    prompt_summary="[verbatim: verbatim/iteration-8ai-verbatim.md] probe pg-mem; locate I4 external-EMPI stubs + deferred-I8A provider refs.",
    key_inputs="baseline",output_summary="pgmem ok; external stubs found; deferred-I8A refs present",gate_result="clean",fidelity="live",
    review_note="Probe confirmed the I4 stubs to make real + the deferred provider refs to resolve.")
add(iteration="8A-i",wave="A",phase="build",agent_role="specialist",agent_label="survivorship+crossReference",workstream_domain="identity/survivorship/crossReference",
    prompt_summary="[verbatim: iteration-8ai-verbatim.md waveA - COMPOSED v1.1] F3: member<->source xref (link/unlink/merge/unmerge, replay-rekey) + source-ranked survivorship rules-as-data, golden record as PROJECTION. Fix fragmentation.",
    key_inputs="iteration8ai_context F3; DP-7",output_summary="xref+survivorship built; two feeds->one member; golden-record projection; seam declared; tests green",gate_result="green",fidelity="live",
    findings="",
    review_note="F3 core fix: id-only second-feed record LINKS to existing member, not a new mint.")
add(iteration="8A-i",wave="B",phase="build",agent_role="specialist",agent_label="external-empi-real",workstream_domain="identity/external",
    prompt_summary="[verbatim: iteration-8ai-verbatim.md waveB - COMPOSED v1.1] Make PIX/PDQ (HL7v2 QBP^Q23/Q22) + PIXm/PDQm (FHIR $ihe-pix / Patient search) REAL query+parse vs a fake MPI; fail-closed without live endpoint; external results respect HELD.",
    key_inputs="iteration8ai_context; I4 external stubs",output_summary="PIX/PDQ + PIXm/PDQm real logic; fail-closed w/o MPI; HELD on low-confidence; tests green",gate_result="green",fidelity="live",
    review_note="Advances the I4 labeled-stubs to real adapter logic; live endpoint CI-pending.")
add(iteration="8A-i",wave="C",phase="build",agent_role="specialist",agent_label="provider-identity-npi",workstream_domain="identity/provider",
    prompt_summary="[verbatim: iteration-8ai-verbatim.md waveC - COMPOSED v1.1] F5: NPI Luhn validation + provider resolver (seeded dir for tests, NPPES fail-closed in prod); ProviderIdentity graph node; deferred-I8A refs now resolve; no invented NPI.",
    key_inputs="iteration8ai_context F5; deferred-I8A refs",output_summary="NPI validation; provider resolves to node; fail-closed w/o NPPES; deferred refs resolved; tests green",gate_result="green",fidelity="live",
    review_note="F5 fix. Anti-masquerade: unresolvable provider stays raw+flagged, never a fabricated NPI.")
add(iteration="8A-i",wave="D",phase="red-team",agent_role="convergence+red-team",agent_label="iter8ai-convergence+panel",workstream_domain="identity/interoperability",
    prompt_summary="[COMPOSED v1.1 - captured verbatim at send-time] convergence to DRY + E9 fail-open sweep (identity: ambiguous match -> HELD not wrong link) + red-team panel (R1=IHE PIX/PDQ+EMPI survivorship+NPPES lens, R2 negative-space, R3 stub-legitimacy on new external seams) + authoritative gate + register update (close F3/F5).",
    key_inputs="wave A/B/C reports; register F3/F5; framework v1.1",output_summary="",gate_result="PENDING",fidelity="pending",
    review_note="NOT YET RUN. Waves A/B/C landed with transient cross-wave shared-file failures; the orchestrator authoritative gate on the merged tree + this Wave D panel are the remaining steps to close 8A-i. Prompt will be captured verbatim at send-time.")

# ===========================================================================
# WRITE CSV (pass 1: base columns) then compute the longitudinal chain
# ===========================================================================
with open("/home/claude/build-provenance/PROMPT_MASTER_LOG.csv","w",newline="") as f:
    w = csv.DictWriter(f, fieldnames=COLS, quoting=csv.QUOTE_ALL, extrasaction="ignore")
    w.writeheader()
    for r in R: w.writerow(r)
print("rows:", len(R))

# ---- Longitudinal chain: compute depends_on for BUILD iterations ----
# Planning-phase (iteration "P") rows carry EXPLICIT depends_on set at add() time; skip them here.
# Rule: probe depends on the PRIOR iteration's closer (spine of the build);
# build waves depend on their iteration's probe; closers depend on that iteration's build waves.
by_iter = {}
for r in R:
    by_iter.setdefault(r["iteration"], []).append(r)

# seed prev_iter_last with the planning finalizer (P13) so I0 chains back to the plan
p13 = next((r for r in R if r["agent_label"]=="P13-finalizer"), None)
prev_iter_last = p13["seq"] if p13 else None

for it in ["0","1","2","3","4","V","5","6","7","8A-i"]:
    rows = [r for r in R if r["iteration"]==it]
    if not rows: continue
    probe = next((r for r in rows if r["phase"]=="probe"), None)
    builds = [r for r in rows if r["phase"]=="build"]
    closers = [r for r in rows if r["phase"] in ("convergence","red-team","fix")]
    if probe and prev_iter_last and probe["depends_on"]=="":
        probe["depends_on"] = str(prev_iter_last)
    anchor = probe["seq"] if probe else (prev_iter_last or "")
    for b in builds:
        if b is not probe and b["depends_on"]=="":
            b["depends_on"] = str(anchor)
    build_seqs = ",".join(str(b["seq"]) for b in builds)
    for c in closers:
        if c["depends_on"]=="":
            c["depends_on"] = build_seqs if build_seqs else str(anchor)
    last = closers[-1] if closers else rows[-1]
    prev_iter_last = last["seq"]

# ---- cross-iteration builds_on notes (do NOT clobber rows that already have one) ----
cross = {
 "graph-projector+backends":"builds on iter1 outbox (event source)",
 "sde-disposition":"consumes graph/pipeline signals",
 "three-agents":"consumes SDE dispositions via iter3 runtime",
 "template+medications":"establishes template reused by all later domains",
 "labs+allergies":"fills the iter4 template","procedures":"fills the iter4 template",
 "careteam+goalstasks":"fills the template; extends iter2 careteam lens",
 "referrals+immunizations":"fills the template",
 "dead-letter-subsystem":"persists records the pipeline/EMPI/outbox previously dropped",
 "idempotency+session-secret":"guards iter2 SDE + iter3 agents against outbox republish",
 "empi-resolver":"replaces the iter1 identity stub",
 "iter6-foldins+panel":"reuses iter5 idempotency; fixes iter1 834 adapter",
 "behavioralHealth+part2":"closes F2 (Part 2 segmentation)",
 "iter7-convergence+panel":"advances F2; first composed prompt; E9 standing sweep",
 "survivorship+crossReference":"closes F3; uses DP-7 replay-rekey from iter2 graph",
 "external-empi-real":"makes the iter4 external-EMPI stubs real",
 "provider-identity-npi":"closes F5; resolves the iter6 deferred-I8A provider refs",
 "iter8ai-convergence+panel":"closes/advances F3+F5; identity/interoperability red-team lens",
}
for r in R:
    if r["agent_label"] in cross:
        r["builds_on"] = cross[r["agent_label"]]

# ---- tracking + linkage ids: trace_id, step_id, timestamp ----
# DETERMINISTIC by design so regeneration is byte-identical (E11.1 diff stays green).
# - step_id : global monotonic step-in-sequence key (zero-padded), sortable, stable.
# - trace_id: unique, self-describing agent-invocation handle (encodes iter+wave+seq)
#             for cross-system linkage; depends_on references step_id/seq, so the two align.
# - ts      : ISO-8601. HISTORICAL rows carry a SYNTHETIC monotonic timestamp anchored to a
#             FIXED base (never now()) - it encodes ORDER, not wall-clock. From this point on,
#             capture each agent's REAL send-time into ts_override at invocation and it wins.
import re as _re
from datetime import datetime, timedelta
BASE_TS = datetime(2026,1,5,9,0,0)   # fixed synthetic anchor - do NOT use now() (keeps E11 diff stable)
TS_STEP = timedelta(minutes=7)
for r in R:
    s = int(r["seq"])
    r["step_id"]  = f"{s:04d}"
    it = _re.sub(r"[^A-Za-z0-9]+","-",str(r["iteration"])).strip("-")
    wv = _re.sub(r"[^A-Za-z0-9]+","-",str(r["wave"])).strip("-")
    r["trace_id"] = f"TRC-{it}-{wv}-{s:04d}"
    r["ts"] = r.get("ts_override") or (BASE_TS + TS_STEP*s).isoformat()+"Z"

# ===========================================================================
# WRITE CSV (pass 2: full columns incl. chain + tracking ids)
# ===========================================================================
COLS2 = ["seq","step_id","trace_id","ts","iteration","wave","phase","depends_on","builds_on",
         "agent_role","agent_label","workstream_domain","prompt_summary","key_inputs",
         "output_summary","gate_result","findings","fidelity","review_note"]
with open("/home/claude/build-provenance/PROMPT_MASTER_LOG.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=COLS2,quoting=csv.QUOTE_ALL,extrasaction="ignore")
    w.writeheader()
    for r in R:
        w.writerow({c:r.get(c,"") for c in COLS2})
print("rewrote CSV with chain; cols:",len(COLS2),"rows:",len(R))

# ===========================================================================
# XLSX view (readable + analyzable): phase-colored, frozen header, auto-filter,
# plus a second sheet that is a compact agent roster index.
# ===========================================================================
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    wb=Workbook(); ws=wb.active; ws.title="Prompt Chain"
    hdr=Font(bold=True,color="FFFFFF",size=10,name="Arial"); hf=PatternFill("solid",fgColor="0B5C53")
    cell=Font(size=9,name="Arial"); wrap=Alignment(wrap_text=True,vertical="top")
    thin=Border(*[Side(style="thin",color="D7E3E0")]*4)
    widths={"seq":5,"step_id":7,"trace_id":22,"ts":22,"iteration":8,"wave":9,"phase":11,"depends_on":11,"builds_on":32,"agent_role":16,
            "agent_label":26,"workstream_domain":24,"prompt_summary":54,"key_inputs":20,"output_summary":34,
            "gate_result":12,"findings":11,"fidelity":9,"review_note":48}
    ws.append(COLS2)
    for i,c in enumerate(COLS2,1):
        cl=ws.cell(1,i); cl.font=hdr; cl.fill=hf; cl.border=thin; cl.alignment=wrap
        ws.column_dimensions[get_column_letter(i)].width=widths.get(c,16)
    # phase colors; planning phase gets its own tint; pending gets a warn tint
    fills={"red-team":"FBF6EA","convergence":"EEF4F3","fix":"FBEAEA","probe":"F2F7F6","plan":"EAF3FB"}
    for r in R:
        ws.append([r.get(c,"") for c in COLS2])
        rr=ws.max_row; ph=r["phase"]
        base = fills.get(ph)
        if r.get("fidelity")=="pending": base="FFF3D6"
        for i in range(1,len(COLS2)+1):
            c=ws.cell(rr,i); c.font=cell; c.border=thin; c.alignment=wrap
            if base: c.fill=PatternFill("solid",fgColor=base)
    ws.freeze_panes="A2"; ws.auto_filter.ref=f"A1:{get_column_letter(len(COLS2))}{ws.max_row}"

    # ---- Sheet 2: Agent roster index (one line per agent, quick "where is X") ----
    ws2=wb.create_sheet("Roster Index")
    r2cols=["step_id","trace_id","phase-group","agent_label","what it is / where its output lives"]
    ws2.append(r2cols)
    for i,c in enumerate(r2cols,1):
        cl=ws2.cell(1,i); cl.font=hdr; cl.fill=hf; cl.border=thin; cl.alignment=wrap
    ws2.column_dimensions["A"].width=8; ws2.column_dimensions["B"].width=22
    ws2.column_dimensions["C"].width=14; ws2.column_dimensions["D"].width=28; ws2.column_dimensions["E"].width=78
    group = lambda it: "PLANNING" if it=="P" else ("VERIFY" if it=="V" else f"BUILD I{it}")
    for r in R:
        note = r["output_summary"] or r["review_note"]
        ws2.append([r["step_id"], r["trace_id"], group(r["iteration"]), r["agent_label"], note])
        for i in range(1,6):
            c=ws2.cell(ws2.max_row,i); c.font=cell; c.border=thin; c.alignment=wrap
    ws2.freeze_panes="A2"

    wb.save("/home/claude/build-provenance/PROMPT_MASTER_LOG.xlsx")
    print("xlsx written (2 sheets)")
except Exception as e:
    print("xlsx skipped:",e)
